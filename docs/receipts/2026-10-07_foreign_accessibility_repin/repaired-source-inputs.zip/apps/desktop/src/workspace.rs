// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

use crate::appearance::{Appearance, Measure, SourceFace};
use crate::collapse::CollapsePreferences;
use crate::documents::{DocIdentity, DocKey, DocumentWorkspace, ReadingKind, SiteKey, TileRole};
use crate::graph::{GraphState, OpenNode};
use crate::preferences::PreferencesStore;
use crate::recovery::{RecoveryId, RecoveryRecord, RecoveryRetention};
use crate::recovery_runtime::RecoveryRuntime;
#[path = "workspace_commands.rs"]
mod commands;
use cambium::{
    AnyView, CommandEvent, CommandMenuBarState, CommandState, GenetCtx, GenetElement, Keyed,
    Popover, PopoverEvent, PopoverPlacement, PopoverState, Slot, TextInput, WorkspaceModel, button,
    el, lens, map_action, on_click, on_key, popover, span, text_field_typed,
    workspace_view_presented_with_marks,
};
use cambium_genet_winit_host::{
    AppCtx, CloseDisposition, CloseRequest, FocusedTextSlot, HostWake, Key, KeyPress, Runner,
    ScrollAlign, WindowCommands,
};
use genet_scripted_dom::NodeId;
use knot_capture::{KnotRetainError, KnotRetainPort, KnotRetainReceiptV1, KnotRetainTargetV1};
use knot_document::{
    KnotDiskComparisonV1, KnotDocumentIntentErrorV1, KnotDocumentIntentV1, KnotDocumentRefusalV1,
    KnotDocumentSession, KnotDocumentStatus, KnotDocumentSurfaceState, KnotOutlineItemV1,
    KnotOutlineSnapshotV1, knot_document_refusal_label, knot_document_view_with_status,
};
use knot_file_catalog::{KnotFileCatalog, KnotFileCatalogAvailability, KnotFileRevisionV1};
use knot_readings::{ReadingBudget, ReadingError, ReadingInput, ReadingResult, ReadingScript};
use layout_dom_api::{LayoutDom, LocalName, Namespace};
use std::collections::HashMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::{
    Arc,
    mpsc::{self, Receiver, TryRecvError},
};
use workbench::{TileEvent, WorkspaceEvent};

const SCRATCH_ADDRESS: &str = "scratch:untitled";

pub(crate) fn hex32(bytes: &[u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn abbreviated_id(value: &[u8; 32], other_ids: impl Iterator<Item = [u8; 32]>) -> String {
    let full = hex32(value);
    let mut length = 8;
    let others = other_ids
        .filter(|other| other != value)
        .map(|other| hex32(&other))
        .collect::<Vec<_>>();
    while length < full.len()
        && others
            .iter()
            .any(|other| other.starts_with(&full[..length]))
    {
        length += 1;
    }
    full[..length].to_owned()
}

fn retention_target_label(
    target: &KnotRetainTargetV1,
    targets: &[Arc<dyn KnotRetainPort>],
) -> String {
    let space = abbreviated_id(
        &target.space_id,
        targets.iter().map(|port| port.target().space_id),
    );
    let same_space_writers = targets.iter().filter_map(|port| {
        let other = port.target();
        (other.persona.stable_id == target.persona.stable_id && other.space_id == target.space_id)
            .then_some(other.writer)
    });
    let writer = abbreviated_id(&target.writer, same_space_writers);
    let writer_needed = targets.iter().any(|port| {
        let other = port.target();
        other.persona.stable_id == target.persona.stable_id
            && other.space_id == target.space_id
            && other.writer != target.writer
    });
    if writer_needed {
        format!(
            "{} · space {} · writer {}",
            target.persona.label, space, writer
        )
    } else {
        format!("{} · space {}", target.persona.label, space)
    }
}

fn encryption_label(profile: knot_capture::KnotRetainEncryptionV1) -> &'static str {
    match profile {
        knot_capture::KnotRetainEncryptionV1::PersonalVaultV1 => "Personal vault encryption",
        knot_capture::KnotRetainEncryptionV1::CommonsDataV1 => "Shared space encryption",
    }
}

fn recovery_format(format: knot_document::DocumentFormat) -> Option<&'static str> {
    use knot_document::DocumentFormat;
    match format {
        DocumentFormat::Knot => Some("Knot"),
        DocumentFormat::Djot => Some("Djot"),
        DocumentFormat::Scroll => Some("Scroll"),
        DocumentFormat::Gemtext => Some("Gemtext"),
        DocumentFormat::Micron => Some("Micron"),
        _ => None,
    }
}

fn parse_recovery_format(format: &str) -> Option<knot_document::DocumentFormat> {
    use knot_document::DocumentFormat;
    match format {
        "Knot" => Some(DocumentFormat::Knot),
        "Djot" => Some(DocumentFormat::Djot),
        "Scroll" => Some(DocumentFormat::Scroll),
        "Gemtext" => Some(DocumentFormat::Gemtext),
        "Micron" => Some(DocumentFormat::Micron),
        _ => None,
    }
}

fn read_recovery_original(path: &Path) -> Result<String, String> {
    let limit = RecoveryRetention::default().max_item_bytes;
    let metadata = std::fs::metadata(path)
        .map_err(|error| format!("could not inspect original {}: {error}", path.display()))?;
    if !metadata.is_file() {
        return Err(format!("original {} is not a regular file", path.display()));
    }
    if metadata.len() > limit {
        return Err(format!(
            "original {} is too large to compare",
            path.display()
        ));
    }
    let mut bytes = Vec::new();
    std::fs::File::open(path)
        .and_then(|file| file.take(limit + 1).read_to_end(&mut bytes))
        .map_err(|error| format!("could not read original {}: {error}", path.display()))?;
    if bytes.len() as u64 > limit {
        return Err(format!(
            "original {} grew too large to compare",
            path.display()
        ));
    }
    String::from_utf8(bytes)
        .map_err(|error| format!("original {} is not UTF-8: {error}", path.display()))
}
pub const DEFAULT_CAPTURE_MAX_BYTES: usize = 1_048_576;
/// Ceilings on the readings folder listing: enough for a working set, small
/// enough that a stuffed directory cannot become a startup cost.
const MAX_READING_SCRIPTS: usize = 64;
const MAX_READING_SOURCE_BYTES: usize = 64 * 1024;

pub type DesktopView = Box<dyn AnyView<DesktopState, (), GenetCtx, GenetElement>>;
pub type DesktopRunner = Runner<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>;

/// The platform command chrome, overridable by a headless receipt.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CommandChrome {
    PlainRow,
    ClientTitlebar,
}

impl Default for CommandChrome {
    fn default() -> Self {
        if cfg!(target_os = "macos") {
            Self::PlainRow
        } else {
            Self::ClientTitlebar
        }
    }
}

/// The commands that take a path, each from its own popover field.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum PathCommand {
    Open,
    SaveAs,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum PendingAction {
    /// Closing the window while documents have unsaved changes: one prompt
    /// for all of them.
    Quit,
    /// Closing one document's tab over its unsaved changes.
    CloseDocument(DocKey),
    /// Closing a metadata tile over its unsaved edits.
    CloseMetadata(workbench::TileId),
    /// Closing a site over its unsaved pages and metadata: one prompt for
    /// all of them.
    CloseSite(SiteKey),
    /// Reloading the focused document over its unsaved changes.
    Reload,
}

/// What the desktop keeps per open document: its surface and every reading
/// and binding derived from it. The window's own state stays on
/// [`DesktopState`].
pub struct DocumentEntry {
    pub document: KnotDocumentSurfaceState,
    recovery_id: Option<RecoveryId>,
    /// Restored copies have no original write authority, even if their text
    /// happens to match the recovered source exactly.
    pub(crate) recovery_candidate: bool,
    recovery_origin: Option<PathBuf>,
    recovery_origin_address: Option<String>,
    recovery_fingerprint: Option<[u8; 32]>,
    catalog_source_path: Option<PathBuf>,
    catalog_sync_attempted: bool,
    pub(crate) catalog_id: Option<String>,
    catalog_error: Option<String>,
    pub(crate) prepared_capture: Option<KnotFileRevisionV1>,
    pub(crate) prepared_capture_source_path: Option<PathBuf>,
    pub(crate) prepared_capture_error: Option<String>,
    pub(crate) comparison: Option<KnotDiskComparisonV1>,
    pub(crate) comparison_error: Option<String>,
    pub(crate) fold_snapshot: Option<knot_document::KnotFoldSnapshotV1>,
    pub(crate) collapsed_folds: std::collections::BTreeSet<usize>,
    pub(crate) fold_error: Option<String>,
    outline_snapshot: Option<KnotOutlineSnapshotV1>,
    outline_error: Option<String>,
    pub(crate) reading_result: Option<ReadingResult>,
    pub(crate) reading_error: Option<ReadingError>,
    /// The exact text the retained reading ran against. A reading is host-side
    /// derived state with no snapshot type of its own, so the text it was bound
    /// to is kept here and handed back to the document when a row is selected.
    reading_source: Option<String>,
    pub(crate) focus_source_requested: bool,
    /// Reader fold state of the Micron preview, reconciled after each dispatch.
    pub(crate) micron_folds: crate::scroll_site::MicronPreviewFolds,
    /// The site page this document is, with its metadata draft, and its Micron
    /// form and Titan or Spartan composer.
    pub(crate) site: crate::scroll_site::DocumentSite,
}

impl DocumentEntry {
    pub fn new(session: KnotDocumentSession) -> Self {
        Self {
            document: KnotDocumentSurfaceState::new(session),
            recovery_id: None,
            recovery_candidate: false,
            recovery_origin: None,
            recovery_origin_address: None,
            recovery_fingerprint: None,
            catalog_source_path: None,
            catalog_sync_attempted: false,
            catalog_id: None,
            catalog_error: None,
            prepared_capture: None,
            prepared_capture_source_path: None,
            prepared_capture_error: None,
            comparison: None,
            comparison_error: None,
            fold_snapshot: None,
            collapsed_folds: std::collections::BTreeSet::new(),
            fold_error: None,
            outline_snapshot: None,
            outline_error: None,
            reading_result: None,
            reading_error: None,
            reading_source: None,
            focus_source_requested: false,
            micron_folds: Default::default(),
            site: Default::default(),
        }
    }

    /// The tab title and duplicate-open identity of this entry's source.
    fn tab(&self) -> (String, DocIdentity) {
        let session = self.document.session();
        let title = self.document.snapshot().display_label;
        match session.source_path() {
            Some(path) => (
                title,
                DocIdentity::Path(
                    std::fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf()),
                ),
            ),
            None => (title, DocIdentity::Scratch),
        }
    }

    /// Take a fresh fold snapshot of the source, keeping collapsed the folds
    /// that still exist by kind and opening line.
    fn refresh_folds(&mut self) {
        let current = self.document.session().fold_snapshot();
        self.collapsed_folds = match &self.fold_snapshot {
            Some(previous) => {
                crate::document_folding::remap_collapsed(previous, &self.collapsed_folds, &current)
            },
            None => std::collections::BTreeSet::new(),
        };
        self.fold_snapshot = Some(current);
    }

    /// Drop the derived reading. The script list and the tiles showing it
    /// belong to the window, not to the document, so they stay.
    fn clear_reading(&mut self) {
        self.reading_result = None;
        self.reading_error = None;
        self.reading_source = None;
    }
}

/// State owned by the standalone application around the reusable document surface.
///
/// The path field is an explicit capability supplied by this desktop host. It is
/// intentionally not part of `knot.document.v1`, whose source admission remains
/// the embedding host's responsibility.
pub struct DesktopState {
    /// The open documents and the tiles that show them.
    pub docs: DocumentWorkspace<DocumentEntry>,
    pub(crate) link_form: Option<crate::link_workflow::LinkForm>,
    pub(crate) link_form_focus_requested: bool,
    pub command_chrome: CommandChrome,
    /// What readers see while no document is open: an empty read-only source,
    /// never a save target.
    placeholder: DocumentEntry,
    pub appearance: Appearance,
    /// Local surface thresholds; never part of a document or sync settings.
    pub collapse: CollapsePreferences,
    pub presentation: workbench::WorkbenchPresentation,
    viewport: (f32, f32),
    source_system_ch: Option<(u8, f32)>,
    collapse_reveal: Option<workbench::TileId>,
    pub scroll: crate::scroll_site::ScrollWorkspace,
    /// The Open popover's path field.
    pub path: TextInput,
    /// The Save As popover's path field, filled from the focused document
    /// when the popover opens.
    pub save_as_path: TextInput,
    pub(crate) command_palette: CommandState,
    pub(crate) command_menu_bar: CommandMenuBarState,
    pub(crate) command_menu_compact: bool,
    pub(crate) command_query: TextInput,
    pub(crate) command_palette_open: bool,
    palette_last_revealed: Option<(String, String)>,
    palette_focus_query: bool,
    palette_restore_focus: bool,
    palette_return_focus: Option<NodeId>,
    menu_return_focus: Option<NodeId>,
    menu_restore_focus: bool,
    last_content_focus: Option<NodeId>,
    /// Which status chip's popover is open.
    pub(crate) status_bar: cambium::StatusBarState,
    pub(crate) open_popover: PopoverState,
    pub(crate) save_as_popover: PopoverState,
    /// One-shot: the path popover whose field takes focus after this
    /// dispatch, set when it opens.
    focus_path_field: Option<PathCommand>,
    pub message: Option<String>,
    pub(crate) catalog: Option<KnotFileCatalog>,
    pub(crate) capture_limit: usize,
    pub(crate) graph: GraphState,
    appearance_open: bool,
    font_licenses_open: bool,
    preferences: Option<PreferencesStore>,
    recovery: Option<RecoveryRuntime>,
    recovery_error: Option<String>,
    readings_root: Option<PathBuf>,
    pub(crate) readings: Vec<ReadingScript>,
    pub(crate) readings_load_notes: Vec<String>,
    pub(crate) composition: crate::composition::CompositionState,
    /// The script each Readings tile has chosen, by name, so a refresh that
    /// adds or drops a file cannot silently arm a different reading.
    pub(crate) reading_scripts: HashMap<workbench::TileId, String>,
    window: WindowCommands,
    pub(crate) pending: Option<PendingAction>,
    discard_close: bool,
    retention_targets: Vec<Arc<dyn KnotRetainPort>>,
    retention_wake: Option<HostWake>,
    retention_selected: Option<usize>,
    retention_receiver: Option<Receiver<RetentionUpdate>>,
    retention_busy: Option<RetentionRequest>,
    retention_receipt: Option<KnotRetainReceiptV1>,
    retention_error: Option<String>,
}

#[derive(Clone)]
struct RetentionRequest {
    target: KnotRetainTargetV1,
    document_id: String,
}

enum RetentionUpdate {
    Completed {
        request: RetentionRequest,
        result: Result<KnotRetainReceiptV1, KnotRetainError>,
    },
}

impl DesktopState {
    pub fn new(session: KnotDocumentSession, window: WindowCommands) -> Self {
        Self::with_catalog(session, window, None, None)
    }

    pub fn with_path(
        session: KnotDocumentSession,
        window: WindowCommands,
        initial_path: Option<PathBuf>,
    ) -> Self {
        Self::with_catalog(session, window, initial_path, None)
    }

    pub fn with_catalog(
        session: KnotDocumentSession,
        window: WindowCommands,
        initial_path: Option<PathBuf>,
        catalog: Option<KnotFileCatalog>,
    ) -> Self {
        let site_folder = initial_path.as_ref().filter(|path| path.is_dir()).cloned();
        let path = initial_path.map_or_else(TextInput::default, |path| {
            TextInput::new(display_path(&path))
        });
        let mut state = Self {
            docs: DocumentWorkspace::new(),
            link_form: None,
            link_form_focus_requested: false,
            command_chrome: CommandChrome::default(),
            placeholder: DocumentEntry::new(KnotDocumentSession::read_only(SCRATCH_ADDRESS, "")),
            appearance: Appearance::default(),
            collapse: CollapsePreferences::default(),
            presentation: workbench::WorkbenchPresentation::default(),
            viewport: (1100.0, 700.0),
            source_system_ch: None,
            collapse_reveal: None,
            scroll: Default::default(),
            path,
            save_as_path: TextInput::default(),
            command_palette: CommandState::default()
                .with_label("Commands")
                .with_id("knot-command-list"),
            command_menu_bar: CommandMenuBarState::default()
                .with_label("Knot commands")
                .with_id("knot-command-menu-bar"),
            command_menu_compact: false,
            command_query: TextInput::default(),
            command_palette_open: false,
            palette_last_revealed: None,
            palette_focus_query: false,
            palette_restore_focus: false,
            palette_return_focus: None,
            menu_return_focus: None,
            menu_restore_focus: false,
            last_content_focus: None,
            status_bar: cambium::StatusBarState::default(),
            open_popover: PopoverState::default(),
            save_as_popover: PopoverState::default(),
            focus_path_field: None,
            message: None,
            catalog,
            capture_limit: DEFAULT_CAPTURE_MAX_BYTES,
            graph: GraphState::default(),
            appearance_open: false,
            font_licenses_open: false,
            preferences: None,
            recovery: None,
            recovery_error: None,
            readings_root: None,
            readings: Vec::new(),
            composition: crate::composition::CompositionState::default(),
            readings_load_notes: Vec::new(),
            reading_scripts: HashMap::new(),
            window,
            pending: None,
            discard_close: false,
            retention_targets: Vec::new(),
            retention_wake: None,
            retention_selected: None,
            retention_receiver: None,
            retention_busy: None,
            retention_receipt: None,
            retention_error: None,
        };
        state.open_entry(DocumentEntry::new(session));
        if let Some(page) = site_folder.and_then(|folder| state.attach_site(&folder)) {
            state.path = TextInput::new(display_path(&page));
        }
        state.sync_catalog();
        state
    }

    /// Hold the site at `folder` in the site panel, returning its index
    /// page's path. Opening that page is the caller's business.
    pub fn attach_site(&mut self, folder: &Path) -> Option<PathBuf> {
        match knot_site::Site::open(folder) {
            Ok(site) => {
                let page = site.page_path(site.config.format.index_file()).ok();
                self.scroll.folder = TextInput::new(display_path(folder));
                self.scroll.format = site.config.format;
                if let Some(port) = site.config.format.default_port() {
                    self.scroll.port = TextInput::new(port.to_string());
                }
                self.hold_site(site);
                page
            },
            Err(error) => {
                self.message = Some(format!("Site: {error}"));
                None
            },
        }
    }

    /// Open the launcher's further documents as tabs behind the focused one,
    /// which stays in front, and say which paths would not open.
    pub fn open_behind(&mut self, sessions: Vec<KnotDocumentSession>, failures: &[String]) {
        let front = self.focused_key();
        for session in sessions {
            self.open_entry(DocumentEntry::new(session));
        }
        if let Some(key) = front {
            self.docs.focus(key);
        }
        self.after_focus_change();
        if !failures.is_empty() {
            let line = format!("Not opened: {}", failures.join("; "));
            self.message = Some(match self.message.take() {
                Some(earlier) => format!("{earlier} {line}"),
                None => line,
            });
        }
    }

    /// The focused document's key, if a document is open.
    pub fn focused_key(&self) -> Option<DocKey> {
        self.docs.focused()
    }

    /// The focused document's entry, or the empty read-only placeholder while
    /// no document is open.
    pub(crate) fn entry(&self) -> &DocumentEntry {
        self.docs
            .focused()
            .and_then(|key| self.docs.doc(key))
            .unwrap_or(&self.placeholder)
    }

    pub(crate) fn entry_mut(&mut self) -> &mut DocumentEntry {
        match self.docs.focused() {
            Some(key) if self.docs.doc(key).is_some() => {
                self.docs.doc_mut(key).expect("focused entry")
            },
            _ => &mut self.placeholder,
        }
    }

    /// Route window commands to `window`, as the harness's own, so a test
    /// sees the closes this state asks for.
    #[cfg(test)]
    pub(crate) fn set_window(&mut self, window: WindowCommands) {
        self.window = window;
    }

    /// Force a platform command layout in a headless acceptance test.
    pub fn set_command_chrome(&mut self, chrome: CommandChrome) {
        self.command_chrome = chrome;
    }

    /// A document's entry by key, or the placeholder's once it has closed: a
    /// tile pinned to a document reads that document, focused or not.
    pub(crate) fn entry_for(&self, key: DocKey) -> &DocumentEntry {
        self.docs.doc(key).unwrap_or(&self.placeholder)
    }

    pub(crate) fn entry_mut_for(&mut self, key: DocKey) -> &mut DocumentEntry {
        if self.docs.doc(key).is_some() {
            self.docs.doc_mut(key).expect("open entry")
        } else {
            &mut self.placeholder
        }
    }

    /// The focused document's surface.
    pub fn document(&self) -> &KnotDocumentSurfaceState {
        &self.entry().document
    }

    pub fn document_mut(&mut self) -> &mut KnotDocumentSurfaceState {
        &mut self.entry_mut().document
    }

    /// Open `entry` in a new tab, or focus the tab already showing the same
    /// source. Returns the entry's key.
    fn open_entry(&mut self, entry: DocumentEntry) -> DocKey {
        let (title, fallback_identity) = entry.tab();
        // Resolve catalog identity before inserting the tile. The first copy
        // of an unbound launch path is catalogued synchronously below, so a
        // later copy in the same launcher batch also resolves here and reuses
        // its tab instead of briefly creating a second writer for one file.
        let identity = entry
            .document
            .session()
            .source_path()
            .and_then(|path| self.catalog.as_ref()?.lookup(path).ok().flatten())
            .map_or(fallback_identity, |record| DocIdentity::Catalog(record.id));
        let (key, inserted) = self.docs.open(identity, title, entry);
        if inserted {
            self.sync_catalog_for(key);
        }
        self.bind_site_page_for(key);
        let open = self.graph_open_nodes();
        self.graph.relayout(&open);
        key
    }

    /// Whether any document, or the placeholder, has a send in flight.
    pub(crate) fn submissions_busy(&self) -> bool {
        self.placeholder.site.busy() || self.docs.docs().any(|(_, entry)| entry.site.busy())
    }

    /// Whether a scenario must keep pumping frames before it can truthfully
    /// inspect derived or externally confirmed state.
    pub(crate) fn background_busy(&self) -> bool {
        self.graph.busy()
            || self.submissions_busy()
            || self.retention_receiver.is_some()
            || self.retention_busy.is_some()
            || self.composition.busy()
    }

    /// Take every finished send's outcome into the document it was sent from.
    pub(crate) fn drain_submissions(&mut self) {
        let entries = std::iter::once(&mut self.placeholder)
            .chain(self.docs.docs_mut().map(|(_, entry)| entry));
        for entry in entries.filter(|entry| entry.site.busy()) {
            let current = entry.document.snapshot();
            entry.site.drain(&current.text, &current.source.address);
        }
    }

    /// A document's surface by key, or the placeholder's once that document
    /// has closed: a tile's editor edits its own document, focused or not.
    pub(crate) fn surface_for(&self, key: DocKey) -> &KnotDocumentSurfaceState {
        self.docs
            .doc(key)
            .map_or(&self.placeholder.document, |entry| &entry.document)
    }

    pub(crate) fn surface_mut_for(&mut self, key: DocKey) -> &mut KnotDocumentSurfaceState {
        if self.docs.doc(key).is_some() {
            &mut self.docs.doc_mut(key).expect("open entry").document
        } else {
            &mut self.placeholder.document
        }
    }

    pub fn set_retention_targets(&mut self, targets: Vec<Arc<dyn KnotRetainPort>>, wake: HostWake) {
        self.graph.set_wake(wake.clone());
        self.refresh_graph();
        self.scroll.set_submission_wake(wake.clone());
        self.retention_targets = targets;
        self.retention_wake = Some(wake);
        self.retention_selected = None;
        self.retention_error = None;
    }

    pub fn set_composition_targets(&mut self, targets: Vec<Arc<dyn knot_composition::retention::CompositionRetainPort>>, wake: HostWake) {
        self.composition.set_targets(targets, wake);
    }

    pub(crate) fn graph_open_nodes(&self) -> Vec<OpenNode> {
        self.docs
            .docs()
            .map(|(key, entry)| {
                let snapshot = entry.document.snapshot();
                OpenNode {
                    key: key.0,
                    catalog_id: entry.catalog_id.clone(),
                    label: snapshot.display_label,
                    dirty: snapshot.dirty,
                }
            })
            .collect()
    }

    fn refresh_graph(&mut self) {
        self.refresh_graph_with_cause(None);
    }

    fn refresh_graph_with_cause(&mut self, cause: Option<apparatus::RecordRef>) {
        let catalog = self.catalog.as_ref().map(KnotFileCatalog::snapshot);
        self.graph
            .start_with_cause(catalog, self.capture_limit, cause);
        let open = self.graph_open_nodes();
        self.graph.relayout(&open);
    }

    pub(crate) fn graph_capture_facts(
        &self,
    ) -> Result<crate::graph::diagnostics::CaptureFacts<'_>, String> {
        self.graph.capture_facts()
    }

    pub(crate) fn graph_diagnostic_attachment(
        &self,
    ) -> Result<Option<apparatus::Batch<serde_json::Value>>, String> {
        self.graph.diagnostic_attachment()
    }

    fn carry_graph_request(&mut self, request: mere_view::MereViewRequest) {
        match request {
            mere_view::MereViewRequest::Activate(key) => {
                if let Some(raw) = key.strip_prefix("open:")
                    && let Ok(raw) = raw.parse()
                {
                    self.docs.focus(DocKey(raw));
                    self.after_focus_change();
                    return;
                }
                let already_open = self.docs.docs().find_map(|(doc, entry)| {
                    (entry.catalog_id.as_deref() == Some(&key)).then_some(doc)
                });
                if let Some(open) = already_open {
                    self.docs.focus(open);
                    self.after_focus_change();
                } else {
                    let authorized = self.catalog.as_ref().and_then(|catalog| {
                        let record = catalog.record(&key)?;
                        (record.availability == KnotFileCatalogAvailability::Available)
                            .then(|| catalog.root().join(record.relative_path))
                    });
                    match authorized {
                        Some(path) => {
                            self.open_path(path);
                        },
                        None => {
                            self.graph.notice = Some(
                                "That catalog document is unavailable or no longer authorized."
                                    .to_owned(),
                            );
                        },
                    }
                }
            },
            mere_view::MereViewRequest::Host(action) if action == "new" => self.new_document(),
            mere_view::MereViewRequest::Host(action) if action == "open" => {
                self.show_path_popover(PathCommand::Open)
            },
            mere_view::MereViewRequest::Layout(layout) => {
                self.graph.layout = layout;
                let open = self.graph_open_nodes();
                self.graph.relayout(&open);
                if let Some(store) = self.preferences.as_mut()
                    && let Err(error) = store.save_graph_layout(&self.graph.layout)
                {
                    self.graph.notice = Some(format!("Layout preference was not saved: {error}"));
                }
            },
            mere_view::MereViewRequest::Mint | mere_view::MereViewRequest::Session(_, _) => {
                self.graph.notice =
                    Some("Knot does not offer reservoir session changes here.".to_owned());
            },
            mere_view::MereViewRequest::Host(action) => {
                self.graph.notice = Some(format!("Knot does not offer the graph action {action}."));
            },
        }
    }

    fn select_retention_target(&mut self, index: usize) {
        if index < self.retention_targets.len() {
            self.retention_selected = Some(index);
            self.retention_error = None;
        }
    }

    fn retain_reviewed(&mut self, wake: HostWake) {
        if self.retention_busy.is_some() {
            self.retention_error =
                Some("Retention is already in progress for the reviewed request.".to_owned());
            return;
        }
        let Some(revision) = self.entry().prepared_capture.clone() else {
            self.retention_error = Some("Review a saved revision before retaining it.".to_owned());
            return;
        };
        let Some(index) = self.retention_selected else {
            self.retention_error = Some("Choose a persona and space before retaining.".to_owned());
            return;
        };
        let Some(port) = self.retention_targets.get(index).cloned() else {
            self.retention_error =
                Some("The selected retention destination is unavailable.".to_owned());
            return;
        };
        let target = port.target().clone();
        let request = RetentionRequest {
            target: target.clone(),
            document_id: revision.document_id.clone(),
        };
        let (sender, receiver) = mpsc::channel();
        self.retention_receiver = Some(receiver);
        self.retention_busy = Some(request.clone());
        self.retention_error = None;
        let wake_for_worker = wake.clone();
        let spawned = std::thread::Builder::new()
            .name("knot-retain".to_owned())
            .spawn(move || {
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    let retained = port.retain_reviewed(&target, revision);
                    // Completion permits close/reopen. Release the worker's
                    // owner capability before notifying the host.
                    drop(port);
                    retained
                }))
                .map_err(|_| KnotRetainError("Retention could not be confirmed.".to_owned()))
                .and_then(|result| result);
                let _ = sender.send(RetentionUpdate::Completed { request, result });
                wake_for_worker.wake();
            });
        if spawned.is_err() {
            self.retention_receiver = None;
            self.retention_busy = None;
            self.retention_error =
                Some("Retention could not be confirmed: worker could not start.".to_owned());
        }
    }

    fn drain_retention(&mut self) {
        let Some(receiver) = self.retention_receiver.as_ref() else {
            return;
        };
        let mut update = None;
        let mut disconnected = false;
        loop {
            match receiver.try_recv() {
                Ok(value) => update = Some(value),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    disconnected = true;
                    break;
                },
            }
        }
        if disconnected && update.is_none() {
            self.retention_receiver = None;
            self.retention_busy = None;
            self.retention_error = Some("Retention could not be confirmed; outcome is uncertain. Retry only after checking the destination.".to_owned());
        }
        if let Some(RetentionUpdate::Completed { request, result }) = update {
            self.retention_receiver = None;
            self.retention_busy = None;
            match result {
                Ok(receipt)
                    if receipt.target == request.target
                        && receipt.document_id == request.document_id =>
                {
                    self.retention_receipt = Some(receipt);
                    self.retention_error = None;
                },
                Ok(_) => self.retention_error = Some(
                    "Retention could not be confirmed: destination or document identity changed."
                        .to_owned(),
                ),
                Err(error) => {
                    self.retention_error = Some(format!(
                        "Retention of {} in {} ({}, space {}, writer {}) could not be confirmed: {error}",
                        request.document_id,
                        request.target.persona.label,
                        request.target.persona.stable_id,
                        hex32(&request.target.space_id),
                        hex32(&request.target.writer)
                    ))
                },
            }
        }
    }

    fn dirty(&self) -> bool {
        self.document().snapshot().dirty || self.entry().recovery_candidate
    }

    /// The facts a scenario asserts on. Grows as scenarios need more.
    pub(crate) fn scenario_snapshot(&self) -> taproot::ProbeSnapshot {
        let snapshot = self.document().snapshot();
        let has_reading = |kind| self.docs.readings().any(|(_, open, _)| open == kind);
        let preview_snapshot = self
            .docs
            .readings()
            .filter(|(_, kind, _)| *kind == ReadingKind::Preview)
            .filter_map(|(tile, _, _)| self.docs.document_for(tile))
            .filter_map(|key| self.docs.doc(key))
            .find_map(|entry| entry.document.session().preview_snapshot().ok());
        let reading_result_rows = self
            .docs
            .readings()
            .filter(|(_, kind, _)| *kind == ReadingKind::Readings)
            .filter_map(|(tile, _, _)| self.docs.document_for(tile))
            .filter_map(|key| self.docs.doc(key)?.reading_result.as_ref())
            .map(|result| result.rows.len())
            .max()
            .unwrap_or(0);
        taproot::ProbeSnapshot::default()
            .with_field("document", snapshot.display_label)
            .with_field("format", format!("{:?}", snapshot.format))
            .with_field(
                "dirty",
                (snapshot.dirty || self.entry().recovery_candidate).to_string(),
            )
            .with_field(
                "recovery_candidate",
                self.entry().recovery_candidate.to_string(),
            )
            .with_field(
                "recovery_available",
                self.recovery
                    .as_ref()
                    .map_or(0, |runtime| runtime.records.len())
                    .to_string(),
            )
            .with_field(
                "recovery_issues",
                self.recovery
                    .as_ref()
                    .map_or(0, |runtime| runtime.issues.len())
                    .to_string(),
            )
            .with_field("appearance_open", self.appearance_open.to_string())
            .with_field("viewport_width", format!("{:.0}", self.viewport.0))
            .with_field("viewport_height", format!("{:.0}", self.viewport.1))
            .with_field(
                "collapsed_stacks",
                self.presentation
                    .stacks
                    .iter()
                    .filter(|stack| stack.collapsed.is_some())
                    .count()
                    .to_string(),
            )
            .with_field(
                "open_drawers",
                self.presentation
                    .stacks
                    .iter()
                    .filter_map(|stack| stack.collapsed.as_ref())
                    .filter(|collapsed| collapsed.open && collapsed.drawer.is_some())
                    .count()
                    .to_string(),
            )
            .with_field("font_size", self.appearance.font_size.to_string())
            .with_field(
                "source_face",
                match self.appearance.source_face {
                    SourceFace::IbmPlexMono => "ibm-plex-mono",
                    SourceFace::SystemMonospace => "system-monospace",
                },
            )
            .with_field(
                "measure",
                match self.appearance.measure {
                    Measure::Narrow => "narrow",
                    Measure::Medium => "medium",
                    Measure::Wide => "wide",
                    Measure::Full => "full",
                },
            )
            .with_field(
                "follow_hard_wrap",
                self.appearance.follow_hard_wrap.to_string(),
            )
            .with_field(
                "source_columns",
                self.appearance
                    .source_columns(&snapshot.text)
                    .map_or_else(|| "full".to_owned(), |column| column.to_string()),
            )
            .with_field(
                "hard_wrap_column",
                knot_document::hard_wrap_column(&snapshot.text)
                    .map_or_else(|| "none".to_owned(), |column| column.to_string()),
            )
            .with_field("palette_open", self.command_palette_open.to_string())
            .with_field("link_form_open", self.link_form.is_some().to_string())
            .with_field("links_open", has_reading(ReadingKind::Links).to_string())
            .with_field(
                "link_count",
                crate::document_links::parsed_links(self.document().session())
                    .map_or(0, |links| links.len())
                    .to_string(),
            )
            .with_field("menu_open", self.command_menu_bar.open.to_string())
            .with_field(
                "command_count",
                commands::palette_items(&commands::groups(self))
                    .len()
                    .to_string(),
            )
            .with_field("document_count", self.docs.len().to_string())
            .with_field("reading_count", self.docs.readings().count().to_string())
            .with_field(
                "preview_open",
                has_reading(ReadingKind::Preview).to_string(),
            )
            .with_field(
                "outline_open",
                has_reading(ReadingKind::Outline).to_string(),
            )
            .with_field(
                "readings_open",
                has_reading(ReadingKind::Readings).to_string(),
            )
            .with_field("preview_rendered", preview_snapshot.is_some().to_string())
            .with_field(
                "preview_heading_count",
                preview_snapshot
                    .as_ref()
                    .map_or(0, |preview| preview.headings.len())
                    .to_string(),
            )
            .with_field("reading_result_rows", reading_result_rows.to_string())
            .with_field(
                "navigator_open",
                self.docs.navigator().is_some().to_string(),
            )
            .with_field("graph_open", self.docs.graph().is_some().to_string())
            .with_field("site_count", self.scroll.site_count().to_string())
            .with_field("serving_count", self.scroll.serving_count().to_string())
            .with_field("message", self.message.clone().unwrap_or_default())
    }

    /// Set the maximum source bytes used by saved-revision review and each
    /// catalog document in the asynchronous graph reading.
    pub fn set_capture_limit(&mut self, max_bytes: usize) {
        self.capture_limit = max_bytes;
        self.graph.invalidate_catalog();
        self.refresh_graph();
    }

    fn clear_prepared_capture(&mut self) {
        self.entry_mut().prepared_capture = None;
        self.entry_mut().prepared_capture_source_path = None;
        self.entry_mut().prepared_capture_error = None;
    }

    /// Read `key`'s saved revision through the catalog for review. Unsaved
    /// edits are never part of it.
    pub(crate) fn prepare_capture_for(&mut self, key: DocKey) {
        let capture_limit = self.capture_limit;
        let (Some(entry), Some(catalog)) = (self.docs.doc_mut(key), self.catalog.as_ref()) else {
            return;
        };
        entry.prepared_capture = None;
        entry.prepared_capture_source_path = None;
        entry.prepared_capture_error = None;
        let Some(id) = entry.catalog_id.clone() else {
            entry.prepared_capture_error = Some(
                entry
                    .catalog_error
                    .clone()
                    .unwrap_or_else(|| "Current document is not catalogued.".to_owned()),
            );
            return;
        };
        let Some(source_path) = entry
            .document
            .session()
            .source_path()
            .map(Path::to_path_buf)
        else {
            entry.prepared_capture_error =
                Some("Current document has no saved source path.".to_owned());
            return;
        };
        if !source_path.is_file() {
            entry.prepared_capture_error =
                Some("Current saved source path is unavailable.".to_owned());
            return;
        }
        match catalog.lookup(&source_path) {
            Ok(Some(record)) if record.id == id => {},
            Ok(_) => {
                entry.prepared_capture_error = Some(
                    "Current source no longer matches its catalog binding. Retry catalog registration."
                        .to_owned(),
                );
                return;
            },
            Err(error) => {
                entry.prepared_capture_error = Some(format!("Catalog lookup failed: {error}"));
                return;
            },
        }
        match catalog.capture_file_revision(&id, capture_limit) {
            Ok(revision) => match std::str::from_utf8(&revision.body) {
                Ok(_) => {
                    entry.prepared_capture_source_path = Some(source_path);
                    entry.prepared_capture = Some(revision);
                },
                Err(_) => {
                    entry.prepared_capture_error = Some(
                        "Saved revision is not valid UTF-8; source text is unavailable.".to_owned(),
                    );
                },
            },
            Err(error) => {
                entry.prepared_capture_error = Some(format!("Preparation failed: {error}"))
            },
        }
    }

    pub(crate) fn discard_prepared_capture_for(&mut self, key: DocKey) {
        if let Some(entry) = self.docs.doc_mut(key) {
            entry.prepared_capture = None;
            entry.prepared_capture_source_path = None;
            entry.prepared_capture_error = None;
        }
    }

    fn path_value(&self) -> Result<PathBuf, String> {
        field_path(&self.path)
    }

    /// Show `command`'s popover, and only it. Save As starts from the focused
    /// document's own path.
    pub(crate) fn show_path_popover(&mut self, command: PathCommand) {
        let shown = PopoverState {
            open: true,
            return_focus: false,
        };
        self.focus_path_field = Some(command);
        match command {
            PathCommand::Open => {
                self.save_as_popover = PopoverState::default();
                self.open_popover = shown;
            },
            PathCommand::SaveAs => {
                self.open_popover = PopoverState::default();
                self.save_as_popover = shown;
                let path = self
                    .document()
                    .session()
                    .source_path()
                    .map(display_path)
                    .unwrap_or_default();
                self.save_as_path = TextInput::new(path);
            },
        }
    }

    fn open_command_palette(&mut self) {
        self.command_palette = CommandState::default()
            .with_label("Commands")
            .with_id("knot-command-list");
        self.command_query = TextInput::default();
        self.command_palette_open = true;
        self.palette_last_revealed = None;
        self.palette_focus_query = true;
        self.palette_restore_focus = false;
    }

    fn dismiss_command_palette(&mut self) {
        self.command_palette_open = false;
        self.palette_last_revealed = None;
        self.palette_focus_query = false;
        self.palette_restore_focus = true;
    }

    fn move_palette_selection(&mut self, forward: bool) {
        let query = self.command_query.text().to_lowercase();
        let choices = commands::palette_items(&commands::groups(self));
        let enabled: Vec<usize> = choices
            .iter()
            .filter(|item| item.label.to_lowercase().contains(&query))
            .enumerate()
            .filter_map(|(position, item)| (!item.disabled).then_some(position))
            .collect();
        let Some(first) = enabled.first().copied() else {
            return;
        };
        let current = enabled
            .iter()
            .position(|position| *position == self.command_palette.selected);
        self.command_palette.selected = match (current, forward) {
            (Some(index), true) => enabled[(index + 1) % enabled.len()],
            (Some(0), false) => *enabled.last().unwrap(),
            (Some(index), false) => enabled[index - 1],
            (None, _) => first,
        };
    }

    fn activate_palette_selection(&mut self) {
        let query = self.command_query.text().to_lowercase();
        let filtered: Vec<_> = commands::palette_items(&commands::groups(self))
            .into_iter()
            .filter(|item| item.label.to_lowercase().contains(&query))
            .collect();
        let id = filtered
            .iter()
            .enumerate()
            .find(|(position, item)| *position >= self.command_palette.selected && !item.disabled)
            .or_else(|| filtered.iter().enumerate().find(|(_, item)| !item.disabled))
            .map(|(_, item)| item.id.clone());
        if let Some(id) = id {
            self.dismiss_command_palette();
            self.activate_command(&id);
        }
    }

    pub(crate) fn path_popover_event(&mut self, command: PathCommand, event: PopoverEvent) {
        let currently_open = match command {
            PathCommand::Open => self.open_popover.open,
            PathCommand::SaveAs => self.save_as_popover.open,
        };
        if event == PopoverEvent::Toggle && !currently_open {
            let id = match command {
                PathCommand::Open => commands::OPEN,
                PathCommand::SaveAs => commands::SAVE_AS,
            };
            if let Some(reason) = commands::disabled_reason(self, id) {
                self.message = Some(reason);
                return;
            }
        }
        let state = match command {
            PathCommand::Open => &mut self.open_popover,
            PathCommand::SaveAs => &mut self.save_as_popover,
        };
        if event == PopoverEvent::Toggle && !state.open {
            self.show_path_popover(command);
        } else {
            let closing = state.open;
            state.apply(event);
            if closing && self.command_chrome == CommandChrome::ClientTitlebar {
                state.return_focus = false;
                if self.focused_key().is_some() {
                    self.entry_mut().focus_source_requested = true;
                }
            }
        }
    }

    /// Run `command` on its popover's path, closing the popover once it
    /// succeeds.
    pub(crate) fn confirm_path(&mut self, command: PathCommand) {
        match command {
            PathCommand::Open => {
                if self.open_document() {
                    self.open_popover.close();
                    if self.command_chrome == CommandChrome::ClientTitlebar {
                        self.open_popover.return_focus = false;
                        if self.focused_key().is_some() {
                            self.entry_mut().focus_source_requested = true;
                        }
                    }
                }
            },
            PathCommand::SaveAs => {
                if self.save_as() {
                    self.save_as_popover.close();
                    if self.command_chrome == CommandChrome::ClientTitlebar {
                        self.save_as_popover.return_focus = false;
                        if self.focused_key().is_some() {
                            self.entry_mut().focus_source_requested = true;
                        }
                    }
                }
            },
        }
    }

    fn sync_catalog_for(&mut self, key: DocKey) {
        if self.catalog.is_none() {
            return;
        }
        let Some(entry) = self.docs.doc(key) else {
            return;
        };
        let source_path = entry
            .document
            .session()
            .source_path()
            .map(Path::to_path_buf);
        if entry.catalog_sync_attempted && entry.catalog_source_path == source_path {
            if let Some(id) = entry.catalog_id.clone() {
                self.docs.set_identity(key, DocIdentity::Catalog(id));
            }
            return;
        }
        if let Some(entry) = self.docs.doc_mut(key) {
            entry.catalog_sync_attempted = true;
            entry.catalog_source_path = source_path.clone();
            entry.catalog_id = None;
            entry.catalog_error = None;
        }
        let Some(source_path) = source_path else {
            return;
        };
        let result = self
            .catalog
            .as_mut()
            .expect("catalog checked above")
            .bind(source_path);
        match result {
            Ok(id) => {
                if let Some(entry) = self.docs.doc_mut(key) {
                    entry.catalog_id = Some(id.clone());
                }
                self.docs.set_identity(key, DocIdentity::Catalog(id));
            },
            Err(error) => {
                if let Some(entry) = self.docs.doc_mut(key) {
                    entry.catalog_error = Some(error);
                }
            },
        }
    }

    fn sync_catalog(&mut self) {
        if let Some(key) = self.focused_key() {
            self.sync_catalog_for(key);
        }
        self.refresh_graph();
    }

    fn after_successful_document_write(&mut self, key: DocKey) {
        self.after_successful_document_write_with_cause(key, None);
    }

    fn after_successful_document_write_with_cause(
        &mut self,
        key: DocKey,
        cause: Option<apparatus::RecordRef>,
    ) {
        self.clear_recovery_for(key);
        self.sync_catalog_for(key);
        self.graph.invalidate_catalog();
        self.refresh_graph_with_cause(cause);
    }

    fn retry_catalog_binding(&mut self) {
        if self.catalog.is_none() {
            return;
        }
        self.entry_mut().catalog_sync_attempted = false;
        self.sync_catalog();
    }

    fn clear_comparison(&mut self) {
        self.entry_mut().comparison = None;
        self.entry_mut().comparison_error = None;
    }

    fn clear_outline(&mut self) {
        self.entry_mut().outline_snapshot = None;
        self.entry_mut().outline_error = None;
    }

    /// Whether `key`'s fold snapshot no longer matches its source.
    fn fold_stale(&self, key: DocKey) -> bool {
        self.docs.doc(key).is_some_and(|entry| {
            entry.fold_snapshot.as_ref().is_none_or(|snapshot| {
                !crate::document_folding::snapshot_matches(entry.document.session(), snapshot)
            })
        })
    }

    /// Bring the fold snapshot of every document a Folded tile shows up to
    /// its source. Folds that still exist stay collapsed.
    fn sync_fold_snapshots(&mut self) {
        for key in self.reading_documents(ReadingKind::Folded) {
            if self.fold_stale(key)
                && let Some(entry) = self.docs.doc_mut(key)
            {
                entry.refresh_folds();
                entry.fold_error = None;
            }
        }
    }

    /// Focus `key`'s document for editing; the Folded tile stays open.
    pub(crate) fn edit_source(&mut self, key: DocKey) {
        self.focus_document(key);
        self.entry_mut().focus_source_requested = true;
    }

    /// `key`'s entry while `action_snapshot` is still its fold snapshot. A
    /// stale one brings the snapshot up to date and says so instead.
    fn fold_target(
        &mut self,
        key: DocKey,
        action_snapshot: &knot_document::KnotFoldSnapshotV1,
    ) -> Option<&mut DocumentEntry> {
        let entry = self.docs.doc_mut(key)?;
        if entry.fold_snapshot.as_ref() == Some(action_snapshot)
            && crate::document_folding::snapshot_matches(entry.document.session(), action_snapshot)
        {
            return Some(entry);
        }
        entry.refresh_folds();
        entry.fold_error = Some("Fold snapshot is stale for the current source.".to_owned());
        None
    }

    pub(crate) fn toggle_fold(
        &mut self,
        key: DocKey,
        action_snapshot: knot_document::KnotFoldSnapshotV1,
        source_index: usize,
    ) {
        let Some(entry) = self.fold_target(key, &action_snapshot) else {
            return;
        };
        if !crate::document_folding::normalized_folds(&action_snapshot)
            .iter()
            .any(|fold| fold.source_index == source_index)
        {
            entry.fold_error =
                Some("That fold is no longer part of the current source.".to_owned());
            return;
        }
        if !entry.collapsed_folds.insert(source_index) {
            entry.collapsed_folds.remove(&source_index);
        }
        entry.fold_error = None;
    }

    pub(crate) fn collapse_all_folds(
        &mut self,
        key: DocKey,
        action_snapshot: knot_document::KnotFoldSnapshotV1,
    ) {
        if let Some(entry) = self.fold_target(key, &action_snapshot) {
            entry.collapsed_folds = crate::document_folding::collapse_all_indices(&action_snapshot);
            entry.fold_error = None;
        }
    }

    pub(crate) fn expand_all_folds(
        &mut self,
        key: DocKey,
        action_snapshot: knot_document::KnotFoldSnapshotV1,
    ) {
        if let Some(entry) = self.fold_target(key, &action_snapshot) {
            entry.collapsed_folds.clear();
            entry.fold_error = None;
        }
    }

    /// The documents the open reading tiles of `kind` show.
    pub(crate) fn reading_documents(&self, kind: ReadingKind) -> Vec<DocKey> {
        let mut keys: Vec<DocKey> = self
            .docs
            .readings()
            .filter(|(_, open, _)| *open == kind)
            .filter_map(|(tile, _, _)| self.docs.document_for(tile))
            .collect();
        keys.sort();
        keys.dedup();
        keys
    }

    /// Whether `key`'s outline snapshot no longer matches its source.
    fn outline_stale(&self, key: DocKey) -> bool {
        let Some(entry) = self.docs.doc(key) else {
            return false;
        };
        let current = entry.document.snapshot();
        entry.outline_snapshot.as_ref().is_none_or(|snapshot| {
            snapshot.address != current.source.address || snapshot.source_text != current.text
        })
    }

    fn sync_outline_snapshot(&mut self) {
        for key in self.reading_documents(ReadingKind::Outline) {
            if self.outline_stale(key)
                && let Some(entry) = self.docs.doc_mut(key)
            {
                entry.outline_snapshot = Some(entry.document.session().outline_snapshot());
            }
        }
    }

    /// Show or hide the reading of `kind` that follows the focused document.
    pub(crate) fn toggle_reading(&mut self, kind: ReadingKind) {
        if let Some(tile) = self.docs.following_reading(kind) {
            self.docs.close(tile);
            return;
        }
        self.collapse_reveal = Some(self.docs.open_reading(kind, None, reading_title(kind)));
        match kind {
            ReadingKind::Outline => {
                self.entry_mut().outline_error = None;
                self.sync_outline_snapshot();
            },
            ReadingKind::Readings => self.refresh_readings(),
            ReadingKind::Folded => self.sync_fold_snapshots(),
            ReadingKind::Preview
            | ReadingKind::Changes
            | ReadingKind::Links
            | ReadingKind::Submit => {},
        }
    }

    /// Show the Navigator, left of the documents, or close it.
    pub(crate) fn toggle_navigator(&mut self) {
        match self.docs.navigator() {
            Some(tile) => {
                self.docs.close(tile);
            },
            None => {
                self.collapse_reveal = Some(self.docs.open_navigator(crate::navigator::TITLE));
            },
        }
    }

    pub(crate) fn toggle_graph(&mut self) {
        match self.docs.graph() {
            Some(tile) => {
                self.docs.close(tile);
            },
            None => {
                self.collapse_reveal = Some(self.docs.open_graph("Graph"));
            },
        }
    }

    /// Pin a reading tile to the document it shows, or let it follow the
    /// focus again.
    pub(crate) fn toggle_pin(&mut self, tile: workbench::TileId) {
        let pinned = match self.docs.role(tile) {
            Some(TileRole::Reading { pinned, .. }) => *pinned,
            _ => return,
        };
        let next = match pinned {
            Some(_) => None,
            None => self.docs.document_for(tile),
        };
        self.docs.set_pinned(tile, next);
        self.sync_outline_snapshot();
        self.sync_fold_snapshots();
    }

    /// Make `key` the focused document, as activating its tab does.
    pub(crate) fn focus_document(&mut self, key: DocKey) {
        if self.docs.focused() != Some(key) {
            self.docs.focus(key);
            self.after_focus_change();
        }
    }

    /// The readings directory this host offers. The panel never picks a path of
    /// its own; the launcher supplies one or the lane stays empty.
    pub fn set_readings_root(&mut self, root: Option<PathBuf>) {
        self.readings_root = root;
        self.refresh_readings();
    }

    /// The preferences file this host owns. Loading applies its appearance; a
    /// file that cannot be read leaves defaults and says why, and a file a
    /// newer Knot wrote loads what this one knows and says that.
    pub fn set_preferences_path(&mut self, path: Option<PathBuf>) {
        self.composition = crate::composition::CompositionState::configured(
            path.as_ref()
                .and_then(|path| path.parent())
                .map(|root| root.join("composition")),
        );
        self.preferences = path.map(PreferencesStore::open);
        let Some(store) = &self.preferences else {
            return;
        };
        self.appearance = store.preferences().appearance.known.clone();
        self.collapse = store.preferences().collapse.clone();
        self.graph.layout = store.preferences().graph_layout.clone();
        let open = self.graph_open_nodes();
        self.graph.relayout(&open);
        let line = store
            .unreadable()
            .map(|why| {
                format!(
                    "Preferences could not be read, so defaults are in use and changes are not saved: {why}"
                )
            })
            .or_else(|| store.written_by_newer());
        if let Some(line) = line {
            self.message = Some(match self.message.take() {
                Some(earlier) => format!("{earlier} {line}"),
                None => line,
            });
        }
    }

    /// Opt in a standalone host to local document recovery. Embeddings that
    /// never call this make no plaintext recovery writes.
    pub fn set_recovery_path(&mut self, path: Option<PathBuf>, wake: HostWake) {
        self.recovery = None;
        self.recovery_error = None;
        let Some(path) = path else {
            return;
        };
        let days = self
            .preferences
            .as_ref()
            .map_or(30, |store| store.preferences().recovery_days);
        let retention = RecoveryRetention {
            max_age_days: Some(u32::from(days)),
            ..RecoveryRetention::default()
        };
        match RecoveryRuntime::start(path, retention, wake) {
            Ok(mut recovery) => {
                let count = recovery.records.len();
                let issues = recovery.issues.len();
                self.recovery_error = recovery.drain_error().0;
                self.recovery = Some(recovery);
                if count > 0 || issues > 0 {
                    self.message = Some(format!(
                        "Document recovery: {count} available, {issues} unreadable. Open Recovery for details."
                    ));
                }
            },
            Err(error) => self.recovery_error = Some(error),
        }
    }

    fn sync_recovery(&mut self) {
        let Some(recovery) = self.recovery.as_ref() else {
            return;
        };
        let session_id = recovery.session_id.clone();
        let focused = self.focused_key();
        let mut offers = Vec::new();
        let mut resolved = Vec::new();
        for (key, entry) in self.docs.docs_mut() {
            let session = entry.document.session();
            let (source, format, selection, dirty, posture, address) =
                session.recovery_observation();
            if !dirty && !entry.recovery_candidate {
                if entry.recovery_id.is_some() {
                    resolved.push(key);
                }
                continue;
            }
            let local_file = session.source_path().is_some();
            let local_scratch = posture == knot_document::KnotDocumentWritePostureV1::Scratch
                && (address == SCRATCH_ADDRESS || address.starts_with("recovery:"));
            if !(dirty || entry.recovery_candidate)
                || posture == knot_document::KnotDocumentWritePostureV1::ReadOnly
                || !(local_file || local_scratch)
                || recovery_format(format).is_none()
            {
                continue;
            }
            if source.len() > RecoveryRetention::default().max_item_bytes as usize {
                self.recovery_error = Some(format!(
                    "{} exceeds the local recovery item size limit.",
                    address
                ));
                continue;
            }
            let mut hasher = blake3::Hasher::new();
            hasher.update(source.as_bytes());
            hasher.update(&selection.anchor.byte.to_le_bytes());
            hasher.update(&selection.focus.byte.to_le_bytes());
            hasher.update(&[
                u8::from(selection.anchor.affinity == cambium::CaretAffinity::Upstream),
                u8::from(selection.focus.affinity == cambium::CaretAffinity::Upstream),
            ]);
            hasher.update(&[u8::from(focused == Some(key))]);
            let fingerprint = *hasher.finalize().as_bytes();
            if entry.recovery_fingerprint == Some(fingerprint) {
                continue;
            }
            let id = *entry.recovery_id.get_or_insert_with(RecoveryId::new);
            offers.push((
                key,
                fingerprint,
                RecoveryRecord {
                    id,
                    source_text: source.to_owned(),
                    format: recovery_format(format).expect("checked above").into(),
                    original_path: entry
                        .recovery_origin
                        .clone()
                        .or_else(|| session.source_path().map(Path::to_path_buf)),
                    original_address: entry
                        .recovery_origin_address
                        .clone()
                        .or_else(|| Some(address.to_owned())),
                    selection: crate::recovery::CaretSelection {
                        anchor: selection.anchor.byte,
                        head: selection.focus.byte,
                        anchor_upstream: selection.anchor.affinity
                            == cambium::CaretAffinity::Upstream,
                        head_upstream: selection.focus.affinity == cambium::CaretAffinity::Upstream,
                    },
                    active_hint: focused == Some(key),
                    created_at_ms: 0,
                    updated_at_ms: 0,
                    session_id: session_id.clone(),
                },
            ));
        }
        for key in resolved {
            self.clear_recovery_for(key);
        }
        if let Some(recovery) = self.recovery.as_mut() {
            let mut accepted = Vec::new();
            for (key, fingerprint, record) in offers {
                if recovery.offer(record) {
                    accepted.push((key, fingerprint));
                }
            }
            recovery.retry();
            let (error, failed) = recovery.drain_error();
            for (key, fingerprint) in accepted {
                if let Some(entry) = self.docs.doc_mut(key) {
                    entry.recovery_fingerprint = Some(fingerprint);
                }
            }
            for id in failed {
                for (_, entry) in self.docs.docs_mut() {
                    if entry.recovery_id == Some(id) {
                        entry.recovery_fingerprint = None;
                    }
                }
            }
            if let Some(error) = error {
                self.recovery_error = Some(error);
            }
        }
    }

    fn clear_recovery_for(&mut self, key: DocKey) {
        let id = self.docs.doc(key).and_then(|entry| entry.recovery_id);
        let Some(id) = id else {
            return;
        };
        if !self.clear_recovery_id(id) {
            return;
        }
        if let Some(entry) = self.docs.doc_mut(key) {
            entry.recovery_id = None;
            entry.recovery_candidate = false;
            entry.recovery_origin = None;
            entry.recovery_origin_address = None;
            entry.recovery_fingerprint = None;
        }
    }

    fn clear_recovery_id(&mut self, id: RecoveryId) -> bool {
        if let Some(recovery) = self.recovery.as_mut()
            && let Err(error) = recovery.clear(id)
        {
            self.recovery_error = Some(format!("Could not clear document recovery copy: {error}"));
            return false;
        }
        true
    }

    fn restore_recovery(&mut self, id: RecoveryId) {
        let already_open = self
            .docs
            .docs()
            .find(|(_, entry)| entry.recovery_id == Some(id))
            .map(|(key, _)| key);
        if let Some(key) = already_open {
            self.docs.focus(key);
            self.after_focus_change();
            self.message = Some("Recovery candidate is already open.".into());
            return;
        }
        let record = match self.recovery.as_mut().map(|runtime| runtime.claim(id)) {
            Some(Ok(Some(record))) => record,
            Some(Err(error)) => {
                self.recovery_error = Some(format!("Cannot claim recovery copy: {error}"));
                return;
            },
            _ => {
                self.recovery_error = Some("Recovery copy is no longer available.".into());
                return;
            },
        };
        let Some(format) = parse_recovery_format(&record.format) else {
            self.message = Some(format!(
                "Cannot restore recovery item: unsupported format {}.",
                record.format
            ));
            return;
        };
        let affinity = |upstream| {
            if upstream {
                cambium::CaretAffinity::Upstream
            } else {
                cambium::CaretAffinity::Downstream
            }
        };
        let selection = cambium::CaretSelection {
            anchor: cambium::CaretPosition {
                byte: record.selection.anchor,
                affinity: affinity(record.selection.anchor_upstream),
            },
            focus: cambium::CaretPosition {
                byte: record.selection.head,
                affinity: affinity(record.selection.head_upstream),
            },
        };
        let address = format!("recovery:{:?}", record.id);
        match KnotDocumentSession::recovery_candidate(
            address,
            record.source_text,
            format,
            selection,
        ) {
            Ok(session) => {
                let mut entry = DocumentEntry::new(session);
                entry.recovery_id = Some(record.id);
                entry.recovery_candidate = true;
                entry.recovery_origin = record.original_path.clone();
                entry.recovery_origin_address = record.original_address.clone();
                let key = self.open_entry(entry);
                let label = record
                    .original_path
                    .as_deref()
                    .and_then(Path::file_name)
                    .and_then(|name| name.to_str())
                    .unwrap_or("scratch document");
                self.docs.set_title(key, format!("Recovered {label}"));
                self.save_as_path = TextInput::default();
                self.after_focus_change();
                self.message = Some(format!(
                    "Recovered {label} as a new unsaved candidate. Compare the original, then Save As to a new path or Discard the copy."
                ));
            },
            Err(error) => self.message = Some(format!("Cannot restore recovery item: {error}")),
        }
    }

    fn discard_recovery(&mut self, id: RecoveryId) {
        let Some(recovery) = self.recovery.as_mut() else {
            return;
        };
        match recovery.clear(id) {
            Ok(()) => {
                let open = self
                    .docs
                    .docs()
                    .find(|(_, entry)| entry.recovery_id == Some(id))
                    .map(|(key, _)| key);
                if let Some(key) = open {
                    self.close_document(key);
                }
                self.message = Some("Recovery copy discarded.".into());
            },
            Err(error) => self.recovery_error = Some(format!("Recovery discard failed: {error}")),
        }
    }

    fn compare_recovery(&mut self, id: RecoveryId) {
        let open = self
            .docs
            .docs()
            .find(|(_, entry)| entry.recovery_id == Some(id))
            .map(|(key, _)| key);
        if let Some(key) = open {
            self.docs.focus(key);
            self.after_focus_change();
            self.compare_disk_for(key);
            self.show_changes_for(key);
            self.message = Some(self.docs.doc(key).and_then(|entry| entry.comparison_error.as_ref())
                .map_or_else(
                    || "Compared recovery candidate with the current original in Changes. Neither source was written.".to_owned(),
                    |error| format!("Recovery comparison unavailable: {error}"),
                ));
            return;
        }
        let record = self
            .recovery
            .as_ref()
            .and_then(|runtime| runtime.records.iter().find(|item| item.id == id));
        let Some(record) = record else {
            return;
        };
        let Some(path) = record.original_path.as_ref() else {
            self.message =
                Some("This scratch recovery copy has no original file to compare.".into());
            return;
        };
        let candidate = self
            .docs
            .docs()
            .find(|(_, entry)| entry.recovery_id == Some(id))
            .map(|(_, entry)| entry.document.snapshot().text)
            .unwrap_or_else(|| record.source_text.clone());
        let limit = RecoveryRetention::default().max_item_bytes;
        self.message = Some(match std::fs::metadata(path) {
            Ok(metadata) if !metadata.is_file() => format!(
                "Original {} is not a regular file; it was not changed.",
                path.display()
            ),
            Ok(metadata) if metadata.len() > limit => format!(
                "Original {} is too large to compare here; it was not changed.",
                path.display()
            ),
            Ok(_) => {
                let mut bytes = Vec::new();
                let result = std::fs::File::open(path)
                    .and_then(|file| file.take(limit + 1).read_to_end(&mut bytes));
                match result {
                    Ok(_) if bytes.len() as u64 > limit => format!(
                        "Original {} grew too large to compare; it was not changed.",
                        path.display()
                    ),
                    Ok(_) if bytes == candidate.as_bytes() => format!(
                        "Original {} currently matches this recovery copy. It was not changed.",
                        path.display()
                    ),
                    Ok(_) => format!(
                        "Original {} differs from this recovery copy. It was not changed; use Save As for the candidate.",
                        path.display()
                    ),
                    Err(error) => format!("Could not read original {}: {error}", path.display()),
                }
            },
            Err(error) => format!("Could not inspect original {}: {error}", path.display()),
        });
    }

    pub fn preferences(&self) -> Option<&PreferencesStore> {
        self.preferences.as_ref()
    }

    /// Change only local collapse thresholds, retaining unknown preference keys.
    pub fn set_collapse_preferences(&mut self, mut collapse: CollapsePreferences) {
        collapse.normalize();
        self.collapse = collapse;
        if let Some(store) = self.preferences.as_mut()
            && let Err(error) = store.save_collapse(&self.collapse)
        {
            self.message = Some(format!("Collapse preferences not saved: {error}"));
        }
    }

    fn adjust_collapse(&mut self, setting: usize, delta: i32) {
        let mut collapse = self.collapse.clone();
        let value = match setting {
            0 => &mut collapse.reading_min_width,
            1 => &mut collapse.rail_width,
            2 => &mut collapse.menu_below,
            3 => &mut collapse.drawer_below,
            _ => &mut collapse.status_below,
        };
        *value = (i32::from(*value) + delta).clamp(0, i32::from(u16::MAX)) as u16;
        self.set_collapse_preferences(collapse);
    }

    fn on_presentation_event(&mut self, event: workbench::PresentationEvent) {
        let closing = matches!(event, workbench::PresentationEvent::Closed(_));
        if let workbench::PresentationEvent::Opened(anchor) = event {
            for stack in &mut self.presentation.stacks {
                if stack.anchor != anchor
                    && let Some(collapsed) = &mut stack.collapsed
                {
                    collapsed.open = false;
                }
            }
        }
        self.presentation.apply(event);
        // The application can restore the actual editor, including its retained
        // selection, rather than the generic Workbench source container.
        self.presentation.focus_return_requested = false;
        if closing {
            self.entry_mut().focus_source_requested = true;
        }
    }

    /// Every appearance control goes through here, so each change is saved.
    pub(crate) fn update_appearance(&mut self, change: impl FnOnce(&mut Appearance)) {
        change(&mut self.appearance);
        let Some(store) = self.preferences.as_mut() else {
            return;
        };
        if let Err(error) = store.save_appearance(&self.appearance) {
            self.message = Some(format!("Appearance not saved: {error}"));
        }
    }

    fn reset_preferences(&mut self) {
        let Some(store) = self.preferences.as_mut() else {
            return;
        };
        self.message = Some(match store.reset(&self.appearance) {
            Ok(()) => format!("Preferences file reset: {}.", store.path().display()),
            Err(error) => format!("Preferences reset failed: {error}"),
        });
        self.collapse = store.preferences().collapse.clone();
    }

    fn set_recovery_days(&mut self, days: u16) {
        let Some(store) = self.preferences.as_mut() else {
            return;
        };
        match store.save_recovery_days(days) {
            Ok(_) => {
                if let Some(recovery) = self.recovery.as_mut()
                    && let Err(error) = recovery.set_retention_days(days)
                {
                    self.recovery_error =
                        Some(format!("Recovery retention update failed: {error}"));
                    return;
                }
                self.message = Some(format!(
                    "Local recovery copies are kept for up to {days} days."
                ));
            },
            Err(error) => self.message = Some(format!("Recovery preference not saved: {error}")),
        }
    }

    pub(crate) fn readings_root_label(&self) -> String {
        match &self.readings_root {
            Some(root) => format!("Scripts: {}", root.display()),
            None => "Scripts: this window has no readings folder".to_owned(),
        }
    }

    pub(crate) fn refresh_readings(&mut self) {
        let Some(root) = self.readings_root.clone() else {
            self.readings.clear();
            self.readings_load_notes.clear();
            return;
        };
        let (scripts, notes) =
            knot_readings::load_dir(&root, MAX_READING_SCRIPTS, MAX_READING_SOURCE_BYTES);
        self.readings = scripts;
        self.readings_load_notes = notes;
    }

    /// The script `tile` has chosen, while it is still in the folder.
    pub(crate) fn reading_script(&self, tile: workbench::TileId) -> Option<&ReadingScript> {
        let name = self.reading_scripts.get(&tile)?;
        self.readings.iter().find(|script| &script.name == name)
    }

    pub(crate) fn select_reading(&mut self, tile: workbench::TileId, index: usize) {
        let Some(script) = self.readings.get(index) else {
            return;
        };
        self.reading_scripts.insert(tile, script.name.clone());
        if let Some(entry) = self
            .docs
            .document_for(tile)
            .and_then(|key| self.docs.doc_mut(key))
        {
            entry.reading_error = None;
        }
    }

    /// Run `tile`'s chosen reading over its document's source, synchronously.
    /// The budget is the lane's own; a runaway returns a receipt, not a hang.
    pub(crate) fn run_reading(&mut self, tile: workbench::TileId) {
        let Some(script) = self.reading_script(tile).cloned() else {
            self.message = Some("Choose a reading before running one.".to_owned());
            return;
        };
        let Some(entry) = self
            .docs
            .document_for(tile)
            .and_then(|key| self.docs.doc_mut(key))
        else {
            return;
        };
        let input = match ReadingInput::from_session(entry.document.session()) {
            Ok(input) => input,
            Err(error) => {
                entry.clear_reading();
                entry.reading_error = Some(ReadingError::Runtime { message: error });
                return;
            },
        };
        let source = input.text.clone();
        use knot_readings::backend::{ReadingBackend, RhaiReadingBackend};
        match RhaiReadingBackend.run(&script, &input, ReadingBudget::default()) {
            Ok(result) => {
                entry.reading_result = Some(result);
                entry.reading_source = Some(source);
                entry.reading_error = None;
            },
            Err(error) => {
                entry.clear_reading();
                entry.reading_error = Some(error);
            },
        }
    }

    /// A reading is derived state: it is stale the moment its source moves.
    /// The tile says so and keeps showing it rather than closing itself.
    pub(crate) fn reading_is_stale(&self, key: DocKey) -> bool {
        let Some(entry) = self.docs.doc(key) else {
            return false;
        };
        let Some(result) = entry.reading_result.as_ref() else {
            return false;
        };
        let current = entry.document.snapshot();
        result.provenance.source.address != current.source.address
            || entry.reading_source.as_deref() != Some(current.text.as_str())
    }

    /// Select a reading row's source range in `key`'s document, focusing
    /// that document first.
    pub(crate) fn select_reading_row_in(&mut self, key: DocKey, index: usize) {
        self.focus_document(key);
        self.select_reading_row(index);
    }

    fn select_reading_row(&mut self, index: usize) {
        let Some(result) = self.entry().reading_result.as_ref() else {
            return;
        };
        let Some(row) = result.rows.get(index) else {
            return;
        };
        let Some((start, end)) = row.span else {
            self.entry_mut().reading_error = Some(ReadingError::Runtime {
                message: format!("\"{}\" carries no source range.", row.label),
            });
            return;
        };
        let address = result.provenance.source.address.clone();
        let Some(text) = self.entry().reading_source.clone() else {
            return;
        };
        match self
            .document_mut()
            .session_mut()
            .select_source_span(&address, &text, start, end)
        {
            Ok(()) => {
                self.entry_mut().reading_error = None;
                self.entry_mut().focus_source_requested = true;
            },
            Err(error) => {
                self.entry_mut().reading_error = Some(ReadingError::Runtime {
                    message: error.clone(),
                });
                self.message = Some(format!("Reading row selection failed: {error}"));
            },
        }
    }

    fn clear_readings(&mut self) {
        self.entry_mut().clear_reading();
    }

    /// Whether a tile that has closed still keeps state here.
    fn closed_tiles_hold_state(&self) -> bool {
        self.reading_scripts
            .keys()
            .any(|tile| self.docs.role(*tile).is_none())
    }

    /// Drop the state closed tiles kept.
    fn prune_tile_state(&mut self) {
        let docs = &self.docs;
        self.reading_scripts
            .retain(|tile, _| docs.role(*tile).is_some());
    }

    fn toggle_appearance(&mut self) {
        self.appearance_open = !self.appearance_open;
    }

    /// Select a preview heading's source range in `document` (the focused
    /// one when `None`), focusing that document first.
    pub(crate) fn select_preview_heading(
        &mut self,
        document: Option<DocKey>,
        address: &str,
        source_text: &str,
        heading: &KnotOutlineItemV1,
        index: usize,
    ) {
        if let Some(key) = document {
            self.focus_document(key);
        }
        let result = self.document().session().preview_snapshot();
        let result = result.and_then(|snapshot| {
            if snapshot.address != address
                || snapshot.source_text != source_text
                || snapshot.headings.get(index) != Some(heading)
            {
                return Err("preview heading is stale for the current source".to_owned());
            }
            self.document_mut()
                .session_mut()
                .select_preview_heading(&snapshot, index)
        });
        match result {
            Ok(()) => self.entry_mut().focus_source_requested = true,
            Err(error) => self.message = Some(format!("Preview heading selection failed: {error}")),
        }
    }

    /// Select an outline row's source range in `key`'s document, focusing
    /// that document first.
    fn select_outline_item_in(&mut self, key: DocKey, index: usize) {
        self.focus_document(key);
        self.select_outline_item(index);
    }

    fn select_outline_item(&mut self, index: usize) {
        let Some(snapshot) = self.entry().outline_snapshot.clone() else {
            self.entry_mut().outline_error =
                Some("Outline is not ready; show it again.".to_owned());
            return;
        };
        let result = self
            .document_mut()
            .session_mut()
            .select_outline_item(&snapshot, index);
        match result {
            Ok(()) => {
                self.entry_mut().outline_error = None;
                self.entry_mut().focus_source_requested = true;
            },
            Err(error) => {
                self.entry_mut().outline_error = Some(error.clone());
                self.message = Some(format!("Outline selection failed: {error}"));
            },
        }
    }

    /// Compare the focused document with disk, and show the result in a
    /// Changes tile.
    fn compare_disk(&mut self) {
        let Some(key) = self.focused_key() else {
            return;
        };
        self.compare_disk_for(key);
        self.show_changes_for(key);
    }

    /// Compare `key`'s buffer with its file as it is on disk now.
    pub(crate) fn compare_disk_for(&mut self, key: DocKey) {
        let Some(entry) = self.docs.doc_mut(key) else {
            return;
        };
        let comparison = if entry.recovery_candidate {
            match entry.recovery_origin.as_deref() {
                Some(path) => read_recovery_original(path).map(|disk_text| {
                    let snapshot = entry.document.snapshot();
                    KnotDiskComparisonV1 {
                        address: snapshot.source.address,
                        buffer_text: snapshot.text,
                        disk_text,
                        // A restored candidate has no saved baseline with
                        // authority over the original; the UI labels this.
                        disk_changed_since_baseline: false,
                    }
                }),
                None => Err("Scratch recovery has no original file to compare.".into()),
            }
        } else {
            entry.document.session().compare_disk()
        };
        match comparison {
            Ok(comparison) => {
                entry.comparison = Some(comparison);
                entry.comparison_error = None;
            },
            Err(error) => {
                entry.comparison = None;
                entry.comparison_error = Some(error);
            },
        }
    }

    pub(crate) fn hide_comparison_for(&mut self, key: DocKey) {
        if let Some(entry) = self.docs.doc_mut(key) {
            entry.comparison = None;
            entry.comparison_error = None;
        }
    }

    /// Bring forward a Changes tile showing `key`, opening one that follows
    /// the focus when none does.
    fn show_changes_for(&mut self, key: DocKey) {
        let showing = self
            .docs
            .readings()
            .filter(|(_, kind, _)| *kind == ReadingKind::Changes)
            .map(|(tile, _, _)| tile)
            .find(|tile| self.docs.document_for(*tile) == Some(key));
        match showing {
            Some(tile) => self.docs.activate(tile),
            None => {
                self.docs.open_reading(
                    ReadingKind::Changes,
                    None,
                    reading_title(ReadingKind::Changes),
                );
            },
        }
    }

    pub(crate) fn request(&mut self, action: PendingAction) {
        if self.dirty() {
            self.pending = Some(action);
        } else {
            self.perform(action);
        }
    }

    fn perform(&mut self, action: PendingAction) {
        match action {
            PendingAction::Quit => self.window.close(),
            PendingAction::CloseDocument(key) => self.close_document(key),
            PendingAction::CloseMetadata(tile) => self.close_metadata(tile),
            PendingAction::CloseSite(site) => self.close_site_now(site),
            PendingAction::Reload => {
                if self.entry().recovery_candidate {
                    self.reload_recovery_candidate();
                    return;
                }
                match self.document_mut().apply(KnotDocumentIntentV1::Reload) {
                    Ok(_) => {
                        self.clear_comparison();
                        self.clear_prepared_capture();
                        self.clear_outline();
                        self.clear_readings();
                        self.sync_outline_snapshot();
                        self.sync_fold_snapshots();
                        self.sync_catalog();
                        self.graph.invalidate_catalog();
                        self.refresh_graph();
                        self.message = Some("Reloaded from disk.".to_owned());
                    },
                    Err(error) => self.message = Some(intent_error_label("Reload", error)),
                }
            },
        }
    }

    fn reload_recovery_candidate(&mut self) {
        let Some(candidate) = self.focused_key() else {
            return;
        };
        let Some(path) = self.entry().recovery_origin.clone() else {
            self.message = Some(
                "Scratch recovery has no original to reload. Save As or Discard the copy.".into(),
            );
            return;
        };
        let already_open_dirty = self.docs.docs().any(|(key, entry)| {
            key != candidate
                && entry.document.session().source_path() == Some(path.as_path())
                && entry.document.snapshot().dirty
        });
        if already_open_dirty {
            self.message = Some("The original is already open with unsaved changes; review that tab before discarding this recovery copy.".into());
            return;
        }
        match KnotDocumentSession::open(&path) {
            Ok(session) => {
                let original = self.open_entry(DocumentEntry::new(session));
                self.close_document(candidate);
                self.docs.focus(original);
                self.after_focus_change();
                self.message = Some(format!(
                    "Loaded current original {}. The recovery candidate was discarded without writing the original.",
                    path.display()
                ));
            },
            Err(error) => {
                self.message = Some(format!(
                    "Could not reload original {}: {error}; recovery candidate remains open.",
                    path.display()
                ))
            },
        }
    }

    /// Readings and bindings follow the focused document: bring them up to
    /// date after the focus moves. Each document holds its own site page.
    fn after_focus_change(&mut self) {
        self.sync_outline_snapshot();
        self.sync_fold_snapshots();
        self.sync_catalog();
    }

    fn new_document(&mut self) {
        self.open_entry(DocumentEntry::new(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "",
        )));
        self.path = TextInput::default();
        self.after_focus_change();
        self.message = Some("New untitled Djot document.".to_owned());
    }

    fn open_document(&mut self) -> bool {
        match self.path_value() {
            Ok(path) => self.open_path(path),
            Err(error) => {
                self.message = Some(error);
                false
            },
        }
    }

    /// Open `path` in a new tab, or switch to the tab already showing it.
    /// `false` when it could not.
    pub(crate) fn open_path(&mut self, path: PathBuf) -> bool {
        let resolved = std::fs::canonicalize(&path).ok();
        let identity = self
            .catalog
            .as_ref()
            .and_then(|catalog| catalog.lookup(&path).ok().flatten())
            .map_or_else(
                || DocIdentity::Path(resolved.clone().unwrap_or_else(|| path.clone())),
                |record| DocIdentity::Catalog(record.id),
            );
        if let Some(key) = self.docs.find(&identity) {
            self.docs.focus(key);
            self.after_focus_change();
            let label = self.document().snapshot().display_label;
            self.message = Some(format!("{label} is already open."));
            return true;
        }
        match KnotDocumentSession::open(&path) {
            Ok(session) => {
                self.path = TextInput::new(display_path(&path));
                self.open_entry(DocumentEntry::new(session));
                self.after_focus_change();
                self.message = Some(format!("Opened {}.", display_path(&path)));
                true
            },
            Err(error) => {
                self.message = Some(format!("Open failed: {error}"));
                false
            },
        }
    }

    fn save(&mut self) {
        let dispatched = self.graph.save_dispatched();
        let Some(key) = self.focused_key() else {
            self.graph.file_write_returned(dispatched, false);
            self.message = Some("No document is open.".to_owned());
            return;
        };
        match self.document_mut().apply(KnotDocumentIntentV1::Save) {
            Ok(_) => {
                let returned = self.graph.file_write_returned(dispatched, true);
                self.after_successful_document_write_with_cause(key, returned);
                self.message = Some("Saved.".to_owned());
            },
            Err(error) => {
                self.graph.file_write_returned(dispatched, false);
                self.message = Some(intent_error_label("Save", error));
            },
        }
    }

    fn save_as(&mut self) -> bool {
        let Some(key) = self.focused_key() else {
            self.message = Some("No document is open.".to_owned());
            return false;
        };
        let path = match field_path(&self.save_as_path) {
            Ok(path) => path,
            Err(error) => {
                self.message = Some(error);
                return false;
            },
        };
        match self
            .document_mut()
            .apply(KnotDocumentIntentV1::SaveAs(path.clone()))
        {
            Ok(_) => {
                self.clear_comparison();
                self.clear_prepared_capture();
                self.clear_outline();
                self.clear_readings();
                self.sync_outline_snapshot();
                self.sync_fold_snapshots();
                let (title, identity) = self.entry().tab();
                self.docs.set_identity(key, identity);
                self.docs.set_title(key, title);
                self.after_successful_document_write(key);
                self.bind_site_page_for(key);
                self.message = Some(format!("Saved as {}.", path.display()));
                true
            },
            Err(error) => {
                self.message = Some(intent_error_label("Save As", error));
                false
            },
        }
    }

    fn reload(&mut self) {
        if self.focused_key().is_none() {
            self.message = Some("No document is open.".to_owned());
            return;
        }
        self.request(PendingAction::Reload);
    }

    /// Save the focused document for a pending action: Save As from the path
    /// field for scratch, an ordinary save otherwise.
    fn save_for_pending(&mut self) -> bool {
        let Some(key) = self.focused_key() else {
            return false;
        };
        if self.document().snapshot().write_posture
            == knot_document::KnotDocumentWritePostureV1::Scratch
        {
            if self.save_as_path.text().trim().is_empty() {
                let label = self.document().snapshot().display_label;
                self.show_path_popover(PathCommand::SaveAs);
                self.message = Some(format!("Choose where to save {label}."));
                return false;
            }
            self.save_as()
        } else {
            match self.document_mut().apply(KnotDocumentIntentV1::Save) {
                Ok(_) => {
                    self.after_successful_document_write(key);
                    true
                },
                Err(error) => {
                    self.message = Some(intent_error_label("Save", error));
                    false
                },
            }
        }
    }

    /// Documents with unsaved changes, in the order they were opened.
    pub(crate) fn dirty_documents(&self) -> Vec<DocKey> {
        self.docs
            .docs()
            .filter(|(_, entry)| entry.document.snapshot().dirty || entry.recovery_candidate)
            .map(|(key, _)| key)
            .collect()
    }

    fn confirm_save(&mut self) {
        let Some(action) = self.pending.take() else {
            return;
        };
        match action {
            PendingAction::Quit => {
                // Save every file-backed document. A scratch document or a
                // refused save stays listed, and the window stays open.
                let focused = self.focused_key();
                let mut failures = Vec::new();
                for key in self.dirty_documents() {
                    self.docs.focus(key);
                    if self.document().snapshot().write_posture
                        == knot_document::KnotDocumentWritePostureV1::Scratch
                    {
                        continue;
                    }
                    match self.document_mut().apply(KnotDocumentIntentV1::Save) {
                        Ok(_) => self.after_successful_document_write(key),
                        Err(error) => failures.push(intent_error_label("Save", error)),
                    }
                }
                for tile in self.dirty_metadata() {
                    if let Some(TileRole::Metadata { site, page }) = self.docs.role(tile).cloned()
                        && let Err(error) = self.save_metadata(site, &page)
                    {
                        failures.push(error);
                    }
                }
                if let Some(key) = focused {
                    self.docs.focus(key);
                }
                if self.dirty_documents().is_empty() && self.dirty_metadata().is_empty() {
                    self.window.close();
                } else {
                    self.pending = Some(PendingAction::Quit);
                    self.message = Some(match failures.last() {
                        Some(error) => error.clone(),
                        None => {
                            "Scratch documents need Save As or a discard before closing.".to_owned()
                        },
                    });
                }
            },
            PendingAction::CloseDocument(key) => {
                self.docs.focus(key);
                if self.save_for_pending() {
                    self.close_document(key);
                } else {
                    self.pending = Some(PendingAction::CloseDocument(key));
                }
            },
            PendingAction::CloseSite(site) => {
                // Save every unsaved page and metadata draft of the site; the
                // site closes once none is left.
                let focused = self.focused_key();
                let mut failures = Vec::new();
                for key in self.site_dirty_pages(site) {
                    self.docs.focus(key);
                    match self.document_mut().apply(KnotDocumentIntentV1::Save) {
                        Ok(_) => self.after_successful_document_write(key),
                        Err(error) => failures.push(intent_error_label("Save", error)),
                    }
                }
                for tile in self.site_dirty_drafts(site) {
                    if let Some(TileRole::Metadata { page, .. }) = self.docs.role(tile).cloned()
                        && let Err(error) = self.save_metadata(site, &page)
                    {
                        failures.push(error);
                    }
                }
                if let Some(key) = focused {
                    self.docs.focus(key);
                }
                if self.site_dirty_pages(site).is_empty() && self.site_dirty_drafts(site).is_empty()
                {
                    self.close_site_now(site);
                } else {
                    self.pending = Some(PendingAction::CloseSite(site));
                    self.message = failures.last().cloned();
                }
            },
            PendingAction::CloseMetadata(tile) => {
                let Some(TileRole::Metadata { site, page }) = self.docs.role(tile).cloned() else {
                    return;
                };
                match self.save_metadata(site, &page) {
                    Ok(()) => self.close_metadata(tile),
                    Err(error) => {
                        self.message = Some(error);
                        self.pending = Some(PendingAction::CloseMetadata(tile));
                    },
                }
            },
            PendingAction::Reload => {
                if self.save_for_pending() {
                    self.perform(PendingAction::Reload);
                } else {
                    self.pending = Some(PendingAction::Reload);
                }
            },
        }
    }

    fn confirm_discard(&mut self) {
        let Some(action) = self.pending.take() else {
            return;
        };
        if matches!(action, PendingAction::Quit) {
            for key in self.dirty_documents() {
                self.clear_recovery_for(key);
            }
            if self
                .docs
                .docs()
                .any(|(_, entry)| entry.recovery_id.is_some())
            {
                self.pending = Some(PendingAction::Quit);
                self.message = self.recovery_error.clone();
                return;
            }
            self.discard_close = true;
            self.window.close();
        } else {
            let ids = match &action {
                PendingAction::CloseDocument(key) => self
                    .docs
                    .doc(*key)
                    .and_then(|entry| entry.recovery_id)
                    .map(|id| vec![(*key, id)])
                    .unwrap_or_default(),
                PendingAction::CloseSite(site) => self
                    .site_dirty_pages(*site)
                    .into_iter()
                    .filter_map(|key| {
                        self.docs
                            .doc(key)
                            .and_then(|entry| entry.recovery_id)
                            .map(|id| (key, id))
                    })
                    .collect(),
                PendingAction::Reload => self
                    .focused_key()
                    .and_then(|key| {
                        self.docs
                            .doc(key)
                            .and_then(|entry| entry.recovery_id)
                            .map(|id| (key, id))
                    })
                    .into_iter()
                    .collect(),
                PendingAction::CloseMetadata(_) | PendingAction::Quit => Vec::new(),
            };
            self.perform(action);
            for (key, id) in ids {
                if self.docs.doc(key).is_none()
                    || self.docs.doc(key).is_some_and(|entry| {
                        !entry.document.snapshot().dirty && !entry.recovery_candidate
                    })
                {
                    self.clear_recovery_id(id);
                }
            }
        }
    }

    /// Leave a summary prompt and show the first tab it listed.
    fn review_pending(&mut self) {
        let Some(action) = self.pending.take() else {
            return;
        };
        let (pages, drafts) = self.pending_lists(&action);
        if let Some(key) = pages.first().copied() {
            self.docs.focus(key);
            self.after_focus_change();
        } else if let Some(tile) = drafts.first().copied() {
            self.docs.activate(tile);
        }
    }

    /// What a summary prompt lists: the unsaved documents and metadata tiles
    /// of the window when quitting, of one site when closing it.
    fn pending_lists(&self, action: &PendingAction) -> (Vec<DocKey>, Vec<workbench::TileId>) {
        match action {
            PendingAction::CloseSite(site) => {
                (self.site_dirty_pages(*site), self.site_dirty_drafts(*site))
            },
            _ => (self.dirty_documents(), self.dirty_metadata()),
        }
    }

    fn cancel_pending(&mut self) {
        self.pending = None;
    }

    /// Apply a gesture from the frame: activation moves the focus, a close
    /// preflights its document, a divider move applies. Drags between stacks
    /// are declined until the workspace adopts them.
    fn on_workspace_event(&mut self, event: WorkspaceEvent) {
        match &event {
            WorkspaceEvent::Tile(TileEvent::Activated(tile)) => {
                let before = self.focused_key();
                self.docs.activate(*tile);
                if self.focused_key() != before {
                    self.after_focus_change();
                }
            },
            WorkspaceEvent::Tile(TileEvent::Closed(tile)) => self.request_close_tile(*tile),
            WorkspaceEvent::Tile(TileEvent::DividerMoved { .. }) => {
                self.docs.apply_layout(&event);
            },
            _ => {
                self.message = Some("Moving tabs between stacks is not available yet.".to_owned());
            },
        }
    }

    fn request_close_tile(&mut self, tile: workbench::TileId) {
        match self.docs.role(tile).cloned() {
            Some(TileRole::Document(key)) => {
                let dirty = self.docs.doc(key).is_some_and(|entry| {
                    entry.document.snapshot().dirty || entry.recovery_candidate
                });
                if dirty {
                    self.docs.focus(key);
                    self.after_focus_change();
                    self.pending = Some(PendingAction::CloseDocument(key));
                } else {
                    self.close_document(key);
                }
            },
            Some(TileRole::Metadata { site, page }) => {
                if self.draft_dirty(site, &page) {
                    self.docs.activate(tile);
                    self.pending = Some(PendingAction::CloseMetadata(tile));
                } else {
                    self.close_metadata(tile);
                }
            },
            Some(TileRole::Site(site)) => self.request_close_site(site),
            _ => {
                self.docs.close(tile);
            },
        }
    }

    /// Close a document's tab without asking; its entry goes with it.
    pub(crate) fn close_document(&mut self, key: DocKey) {
        let retaining = self
            .retention_busy
            .as_ref()
            .zip(
                self.docs
                    .doc(key)
                    .and_then(|entry| entry.catalog_id.as_ref()),
            )
            .is_some_and(|(busy, id)| &busy.document_id == id);
        if retaining {
            self.message =
                Some("Wait for retention to finish before closing this document.".to_owned());
            return;
        }
        // Direct clean-tab close has no unsaved bytes; only explicit Discard
        // or a successful Save may clear an existing recovery copy.
        let label = self
            .docs
            .doc(key)
            .map(|entry| entry.document.snapshot().display_label);
        let before = self.focused_key();
        self.docs.prepare_last_document_close(key, "Graph");
        if let Some(tile) = self.docs.tile_of(key) {
            self.docs.close(tile);
        }
        if self.focused_key() != before {
            self.after_focus_change();
        }
        if let Some(label) = label {
            self.message = Some(format!("Closed {label}."));
        }
        let open = self.graph_open_nodes();
        self.graph.relayout(&open);
    }

    fn close_request(&mut self, request: CloseRequest) -> CloseDisposition {
        if self.retention_busy.is_some() {
            self.message = Some("Wait for retention to finish before closing.".to_owned());
            self.discard_close = false;
            return CloseDisposition::KeepVisible;
        }
        if self.discard_close {
            self.discard_close = false;
            return CloseDisposition::Exit;
        }
        if !self.dirty_documents().is_empty() || !self.dirty_metadata().is_empty() {
            self.pending = Some(PendingAction::Quit);
            return CloseDisposition::KeepVisible;
        }
        if matches!(request, CloseRequest::Native | CloseRequest::Command) {
            if let Some(recovery) = self.recovery.as_mut()
                && let Err(error) = recovery.flush()
            {
                self.recovery_error = Some(format!("Document recovery flush failed: {error}"));
                return CloseDisposition::KeepVisible;
            }
            CloseDisposition::Exit
        } else {
            CloseDisposition::KeepVisible
        }
    }
}

/// The sentence a refused or failed `action` posts to the message line: the
/// refusal in knot-document's words, which the save chip shows too, then
/// what to do about it.
fn intent_error_label(action: &str, error: KnotDocumentIntentErrorV1) -> String {
    match error {
        KnotDocumentIntentErrorV1::Refused(refusal) => {
            let advice = match refusal {
                KnotDocumentRefusalV1::ExternalChange => {
                    " Compare, Reload, or choose a new Save As path."
                },
                KnotDocumentRefusalV1::ScratchHasNoSaveTarget => " Use Save As.",
                KnotDocumentRefusalV1::ReadOnly => "",
            };
            format!(
                "{action} refused: {}.{advice}",
                knot_document_refusal_label(refusal)
            )
        },
        KnotDocumentIntentErrorV1::SaveFailed(failure) => {
            format!("{action} failed: {}", failure.message)
        },
    }
}

/// The retention chip's popover: everything the retention block held, its
/// actions included (slice 1 step 5d).
fn retention_detail(state: &DesktopState) -> DesktopView {
    {
        let destinations = if state.retention_targets.is_empty() {
            Box::new(span("No storage destinations available.")) as DesktopView
        } else {
            let rows = state
                .retention_targets
                .iter()
                .enumerate()
                .map(|(index, port)| {
                    let target = port.target();
                    let selected = state.retention_selected == Some(index);
                    let label = retention_target_label(target, &state.retention_targets);
                    (
                        index,
                        button(label, move |state: &mut DesktopState, _| {
                            state.select_retention_target(index)
                        })
                        .attr("data-retention-target", index.to_string())
                        .attr("aria-pressed", selected.to_string()),
                    )
                })
                .collect::<Vec<_>>();
            Box::new(el("div", Keyed::new(rows)).attr("class", "knot-retention-targets"))
                as DesktopView
        };
        let selected_detail: DesktopView = if let Some(port) = state
            .retention_selected
            .and_then(|index| state.retention_targets.get(index))
        {
            let target = port.target();
            Box::new(
                el(
                    "div",
                    (
                        span(format!("Persona: {}", target.persona.label)),
                        span(format!("Persona stable ID: {}", target.persona.stable_id)),
                        span(format!("Space ID: {}", hex32(&target.space_id))),
                        span(format!("Writer ID: {}", hex32(&target.writer))),
                        span(format!(
                            "Encryption: {}",
                            encryption_label(target.encryption)
                        )),
                    ),
                )
                .attr("class", "knot-retention-selected")
                .attr("role", "region")
                .attr("aria-label", "Selected retention destination")
                .attr("aria-live", "polite"),
            )
        } else {
            Box::new(
                el("div", span("No destination selected."))
                    .attr("class", "knot-retention-selected")
                    .attr("role", "region")
                    .attr("aria-label", "Selected retention destination")
                    .attr("aria-live", "polite"),
            )
        };
        let busy = state.retention_busy.as_ref().map(|request| {
            span(format!(
                "Retaining {} in {} ({}, space {}, writer {})…",
                request.document_id,
                request.target.persona.label,
                request.target.persona.stable_id,
                hex32(&request.target.space_id),
                hex32(&request.target.writer)
            ))
            .attr("class", "knot-retention-busy")
        });
        let error = state
            .retention_error
            .as_ref()
            .map(|error| span(error.clone()).attr("class", "knot-retention-error"));
        let receipt = state.retention_receipt.as_ref().map(|receipt| {
            span(format!(
                "Last confirmed retention: {} in {} ({}, {}, space {}, writer {}, operation {}){}",
                receipt.document_id,
                receipt.target.persona.label,
                receipt.target.persona.stable_id,
                encryption_label(receipt.target.encryption),
                hex32(&receipt.target.space_id),
                hex32(&receipt.target.writer),
                hex32(&receipt.operation),
                if receipt.already_retained {
                    "; already retained"
                } else {
                    ""
                }
            ))
            .attr("class", "knot-retention-receipt")
        });
        let retain_button = if state.retention_busy.is_none()
            && state.entry().prepared_capture.is_some()
            && state.retention_selected.is_some()
        {
            state.retention_wake.clone().map(|wake| {
                button(
                    "Retain reviewed revision",
                    move |state: &mut DesktopState, _| state.retain_reviewed(wake.clone()),
                )
            })
        } else {
            None
        };
        Box::new(
            el(
                "section",
                (
                    el(
                        "header",
                        (
                            span("Retain reviewed revision"),
                            span("Choose a persona and space"),
                        ),
                    ),
                    destinations,
                    selected_detail,
                    retain_button,
                    busy,
                    error,
                    receipt,
                ),
            )
            .attr("class", "knot-status-detail knot-retention")
            .attr("role", "region")
            .attr("aria-label", "Retain reviewed revision"),
        )
    }
}

/// The catalog chip's popover: the document's ID, or why it has none, with
/// Retry catalog after a failure (slice 1 step 5d).
fn catalog_detail(state: &DesktopState) -> DesktopView {
    let status: DesktopView = if let Some(id) = &state.entry().catalog_id {
        Box::new(
            span(format!("Document ID: {id}"))
                .attr("class", "knot-catalog-status")
                .attr("aria-live", "polite"),
        )
    } else if let Some(error) = &state.entry().catalog_error {
        Box::new(
            el(
                "div",
                (
                    span(format!("Not catalogued: {error}")),
                    button("Retry catalog", |state: &mut DesktopState, _| {
                        state.retry_catalog_binding();
                    }),
                ),
            )
            .attr("class", "knot-catalog-status knot-catalog-error")
            .attr("role", "status"),
        )
    } else {
        Box::new(
            span("Not catalogued: unsaved document")
                .attr("class", "knot-catalog-status")
                .attr("aria-live", "polite"),
        )
    };
    Box::new(el("div", status).attr("class", "knot-status-detail"))
}

/// Where the focused document stands in the catalog; `None` without one.
fn catalog_state(state: &DesktopState) -> Option<crate::status::Catalog> {
    use crate::status::Catalog;
    state.catalog.as_ref()?;
    let entry = state.entry();
    Some(if entry.catalog_id.is_some() {
        Catalog::Bound
    } else if entry.catalog_error.is_some() {
        Catalog::Failed
    } else {
        Catalog::Unsaved
    })
}

/// Whether the retention chip shows: where the retention block did.
fn retention_shown(state: &DesktopState) -> bool {
    !(state.document().snapshot().format.native_source() && state.retention_targets.is_empty())
}

fn retention_state(state: &DesktopState) -> crate::status::Retention {
    use crate::status::Retention;
    if state.retention_busy.is_some() {
        Retention::Busy
    } else if state.retention_error.is_some() {
        Retention::Failed
    } else if state.retention_receipt.is_some() {
        Retention::Retained
    } else {
        Retention::Idle
    }
}

/// The serving chip's popover: the served site's address with Stop serving,
/// or why nothing is served with Publish locally (slice 1 step 5d).
fn serving_detail(state: &DesktopState) -> DesktopView {
    let focused = state
        .site_page()
        .and_then(|page| state.scroll.site(page.site).map(|entry| (page.site, entry)));
    let (line, action): (String, DesktopView) = match focused {
        Some((site, entry)) if entry.server.is_some() => {
            let server = entry.server.as_ref().expect("checked above");
            (
                format!(
                    "{} · revision {} · saved snapshot",
                    server.url(),
                    entry.publication_number()
                ),
                Box::new(button("Stop serving", move |state: &mut DesktopState, _| {
                    state.scroll.stop_serving(site);
                    state.message = Some("Local serving stopped.".into());
                })),
            )
        },
        Some((site, _)) => (
            "Not published. Save writes drafts; Publish locally serves a saved snapshot over loopback when this site format has a local server.".into(),
            Box::new(button("Publish locally", move |state: &mut DesktopState, _| {
                state.publish_site(site)
            })),
        ),
        None => (
            "No site page is focused.".into(),
            Box::new(el("div", ())),
        ),
    };
    Box::new(
        el(
            "div",
            (span(line).attr("class", "knot-serving-status"), action),
        )
        .attr("class", "knot-status-detail"),
    )
}

fn recovery_detail(state: &DesktopState) -> DesktopView {
    let Some(runtime) = state.recovery.as_ref() else {
        let reason = state.recovery_error.as_ref().map_or_else(
            || "Local document recovery is unavailable.".to_owned(),
            |error| format!("Local document recovery is unavailable: {error}"),
        );
        return Box::new(
            el("div", span(reason))
                .attr("class", "knot-status-detail knot-recovery")
                .attr("role", "status"),
        );
    };
    let rows = runtime
        .records
        .iter()
        .map(|record| {
            let id = record.id;
            let title = record
                .original_path
                .as_deref()
                .and_then(Path::file_name)
                .and_then(|name| name.to_str())
                .or(record.original_address.as_deref())
                .unwrap_or("scratch document");
            (
                format!("{:?}", id),
                el(
                    "div",
                    (
                        span(format!(
                            "{title} · {} bytes · {}",
                            record.source_text.len(),
                            record.format
                        )),
                        button("Restore", move |state: &mut DesktopState, _| {
                            state.restore_recovery(id)
                        }),
                        button("Compare original", move |state: &mut DesktopState, _| {
                            state.compare_recovery(id)
                        }),
                        button("Discard copy", move |state: &mut DesktopState, _| {
                            state.discard_recovery(id)
                        }),
                    ),
                )
                .attr("class", "knot-recovery-row"),
            )
        })
        .collect::<Vec<_>>();
    let issues = runtime
        .issues
        .iter()
        .enumerate()
        .map(|(index, issue)| (index, span(format!("Unreadable recovery item: {issue:?}"))))
        .collect::<Vec<_>>();
    let error: DesktopView = state.recovery_error.as_ref().map_or_else(
        || Box::new(el("div", ())) as DesktopView,
        |error| Box::new(span(error.clone()).attr("role", "status")) as DesktopView,
    );
    Box::new(el("div", (
        span("Local document drafts only. Sealed vault content and site forms are excluded. Restoring opens a new unsaved candidate; Save As creates a new file."),
        el("div", Keyed::new(rows)),
        el("div", Keyed::new(issues)),
        error,
    )).attr("class", "knot-status-detail knot-recovery"))
}

pub fn desktop_view(state: &DesktopState) -> DesktopView {
    let appearance_panel: DesktopView = if state.appearance_open {
        let appearance = &state.appearance;
        let hard_wrap_note: DesktopView = if appearance.follow_hard_wrap
            && let Some(column) = knot_document::hard_wrap_column(&state.document().snapshot().text)
        {
            let preview_measure = appearance
                .measure
                .columns()
                .map_or_else(|| "Full".to_owned(), |columns| format!("{columns}ch"));
            Box::new(span(format!("Source follows detected {column}-column wrap ({}ch with slack); preview uses {preview_measure}.", column.saturating_add(1)))
                .attr("class", "knot-hard-wrap-note")
                .attr("role", "status"))
        } else {
            Box::new(el("div", ()))
        };
        let font_licenses: DesktopView = if state.font_licenses_open {
            Box::new(
                el(
                    "div",
                    (
                        el("h3", "IBM Plex Mono"),
                        el("pre", crate::fonts::IBM_PLEX_MONO_LICENSE),
                        el("h3", "Source Serif 4"),
                        el("pre", crate::fonts::SOURCE_SERIF_4_LICENSE),
                    ),
                )
                .attr("class", "knot-font-licenses")
                .attr("id", "knot-font-licenses")
                .attr("role", "region")
                .attr("aria-label", "Bundled font licences"),
            )
        } else {
            Box::new(el("div", ()))
        };
        // Saves refuse while the file is unreadable; say so where the controls
        // are, and offer the one action that may overwrite it.
        let preferences_note: DesktopView = match state
            .preferences
            .as_ref()
            .and_then(PreferencesStore::unreadable)
        {
            Some(why) => Box::new(
                el(
                    "div",
                    (
                        span(format!(
                            "Not saving appearance: the preferences file could not be read ({why})."
                        )),
                        button("Reset preferences file", |state: &mut DesktopState, _| {
                            state.reset_preferences();
                        })
                        .attr(
                            "aria-label",
                            "Reset preferences file, replacing its unreadable contents",
                        ),
                    ),
                )
                .attr("class", "knot-appearance-row knot-preferences-error")
                .attr("role", "status"),
            ),
            None => Box::new(el("div", ())),
        };
        Box::new(
            el(
                "section",
                (
                    el(
                        "div",
                        (
                            button("Light", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| appearance.dark = false);
                            })
                            .attr("aria-pressed", (!appearance.dark).to_string()),
                            button("Dark", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| appearance.dark = true);
                            })
                            .attr("aria-pressed", appearance.dark.to_string()),
                            button("Highlight", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.highlight = !appearance.highlight;
                                });
                            })
                            .attr("aria-pressed", appearance.highlight.to_string()),
                        ),
                    )
                    .attr("class", "knot-appearance-row"),
                    el(
                        "div",
                        (
                            button("Smaller", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.font_size = appearance
                                        .font_size
                                        .saturating_sub(1)
                                        .max(Appearance::MIN_FONT_SIZE);
                                });
                            }),
                            span(format!("Text size: {}", appearance.font_size)),
                            button("Larger", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.font_size = appearance
                                        .font_size
                                        .saturating_add(1)
                                        .min(Appearance::MAX_FONT_SIZE);
                                });
                            }),
                        ),
                    )
                    .attr("class", "knot-appearance-row"),
                    el(
                        "div",
                        (
                            button("IBM Plex Mono", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.source_face = SourceFace::IbmPlexMono
                                });
                            })
                            .attr(
                                "aria-pressed",
                                (appearance.source_face == SourceFace::IbmPlexMono).to_string(),
                            ),
                            button("System monospace", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.source_face = SourceFace::SystemMonospace
                                });
                            })
                            .attr(
                                "aria-pressed",
                                (appearance.source_face == SourceFace::SystemMonospace).to_string(),
                            ),
                            button("Font licences", |state: &mut DesktopState, _| {
                                state.font_licenses_open = !state.font_licenses_open;
                            })
                            .attr("aria-expanded", state.font_licenses_open.to_string())
                            .attr("aria-controls", "knot-font-licenses"),
                        ),
                    )
                    .attr("class", "knot-appearance-row")
                    .attr("aria-label", "Source face"),
                    font_licenses,
                    el(
                        "div",
                        Keyed::new(
                            [
                                (Measure::Narrow, "Narrow · 60ch"),
                                (Measure::Medium, "Medium · 72ch"),
                                (Measure::Wide, "Wide · 90ch"),
                                (Measure::Full, "Full"),
                            ]
                            .into_iter()
                            .enumerate()
                            .map(|(index, (measure, label))| {
                                (
                                    index,
                                    button(label, move |state: &mut DesktopState, _| {
                                        state.update_appearance(|appearance| {
                                            appearance.measure = measure
                                        });
                                    })
                                    .attr(
                                        "aria-pressed",
                                        (appearance.measure == measure).to_string(),
                                    ),
                                )
                            })
                            .collect::<Vec<_>>(),
                        ),
                    )
                    .attr("class", "knot-appearance-row")
                    .attr("aria-label", "Writing measure"),
                    hard_wrap_note,
                    el(
                        "div",
                        Keyed::new(
                            [
                                ("Reading minimum", state.collapse.reading_min_width),
                                ("Rail width", state.collapse.rail_width),
                                ("Menu below", state.collapse.menu_below),
                                ("Drawers below", state.collapse.drawer_below),
                                ("Status chips below", state.collapse.status_below),
                            ]
                            .into_iter()
                            .enumerate()
                            .map(|(setting, (label, value))| {
                                let step = if setting == 1 { 4 } else { 20 };
                                (
                                    setting,
                                    el(
                                        "div",
                                        (
                                            span(format!("{label}: {value}px")),
                                            button("−", move |state: &mut DesktopState, _| {
                                                state.adjust_collapse(setting, -step)
                                            })
                                            .attr("aria-label", format!("Decrease {label}")),
                                            button("+", move |state: &mut DesktopState, _| {
                                                state.adjust_collapse(setting, step)
                                            })
                                            .attr("aria-label", format!("Increase {label}")),
                                        ),
                                    )
                                    .attr("class", "knot-appearance-row"),
                                )
                            })
                            .collect::<Vec<_>>(),
                        ),
                    )
                    .attr("aria-label", "Narrow workspace thresholds"),
                    el(
                        "div",
                        (
                            button("Follow hard wrap", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| {
                                    appearance.follow_hard_wrap = !appearance.follow_hard_wrap
                                });
                            })
                            .attr("aria-pressed", appearance.follow_hard_wrap.to_string()),
                            button("Compact", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| appearance.relaxed = false);
                            })
                            .attr("aria-pressed", (!appearance.relaxed).to_string()),
                            button("Relaxed", |state: &mut DesktopState, _| {
                                state.update_appearance(|appearance| appearance.relaxed = true);
                            })
                            .attr("aria-pressed", appearance.relaxed.to_string()),
                        ),
                    )
                    .attr("class", "knot-appearance-row"),
                    el(
                        "div",
                        (
                            span(format!(
                                "Document recovery retention: {} days",
                                state
                                    .preferences
                                    .as_ref()
                                    .map_or(30, |store| store.preferences().recovery_days)
                            )),
                            button("7 days", |state: &mut DesktopState, _| {
                                state.set_recovery_days(7)
                            }),
                            button("30 days", |state: &mut DesktopState, _| {
                                state.set_recovery_days(30)
                            }),
                            button("90 days", |state: &mut DesktopState, _| {
                                state.set_recovery_days(90)
                            }),
                        ),
                    )
                    .attr("class", "knot-appearance-row"),
                    preferences_note,
                ),
            )
            .attr("class", "knot-appearance-panel")
            .attr("id", "knot-appearance-panel")
            .attr("role", "region")
            .attr("aria-label", "Appearance controls"),
        )
    } else {
        Box::new(el("div", ()))
    };
    let prompt: DesktopView = match state.pending.as_ref() {
        Some(action @ (PendingAction::Quit | PendingAction::CloseSite(_))) => {
            let (pages, drafts) = state.pending_lists(action);
            let mut labels: Vec<String> = pages
                .iter()
                .filter_map(|key| {
                    let entry = state.docs.doc(*key)?;
                    Some(entry.document.snapshot().display_label)
                })
                .collect();
            let documents = labels.len();
            labels.extend(
                drafts
                    .iter()
                    .filter_map(|tile| match state.docs.role(*tile) {
                        Some(TileRole::Metadata { page, .. }) => Some(format!("Metadata · {page}")),
                        _ => None,
                    }),
            );
            let site = match action {
                PendingAction::CloseSite(site) => state
                    .scroll
                    .site(*site)
                    .map(crate::scroll_site::SiteEntry::name),
                _ => None,
            };
            let title = match (labels.as_slice(), site) {
                ([label], _) => format!("{label} has unsaved changes."),
                (all, Some(site)) => format!("{} tabs of {site} have unsaved changes.", all.len()),
                (all, None) if all.len() == documents => {
                    format!("{} documents have unsaved changes.", all.len())
                },
                (all, None) => format!("{} tabs have unsaved changes.", all.len()),
            };
            let listed = labels
                .into_iter()
                .enumerate()
                .map(|(index, label)| (index as u64, span(label)))
                .collect::<Vec<_>>();
            Box::new(
                el(
                    "aside",
                    (
                        span(title).attr("id", "knot-confirm-message"),
                        el("div", Keyed::new(listed)).attr("class", "knot-confirm-list"),
                        button("Save all", |state: &mut DesktopState, _| {
                            state.confirm_save()
                        })
                        .attr("id", "knot-confirm-save"),
                        button("Discard all", |state: &mut DesktopState, _| {
                            state.confirm_discard()
                        }),
                        button("Review", |state: &mut DesktopState, _| {
                            state.review_pending()
                        })
                        .attr("id", "knot-confirm-review"),
                        button("Cancel", |state: &mut DesktopState, _| {
                            state.cancel_pending()
                        }),
                    ),
                )
                .attr("class", "knot-confirm")
                .attr("role", "dialog")
                .attr("aria-label", "Unsaved changes"),
            )
        },
        Some(action) => {
            let title = match action {
                PendingAction::CloseDocument(key) => format!(
                    "{} has unsaved changes.",
                    state
                        .docs
                        .doc(*key)
                        .map_or_else(String::new, |entry| entry.document.snapshot().display_label)
                ),
                PendingAction::CloseMetadata(tile) => match state.docs.role(*tile) {
                    Some(TileRole::Metadata { page, .. }) => {
                        format!("Metadata · {page} has unsaved changes.")
                    },
                    _ => "These metadata edits are unsaved.".to_owned(),
                },
                _ => "Reload will replace unsaved changes with disk text.".to_owned(),
            };
            Box::new(
                el(
                    "aside",
                    (
                        span(title).attr("id", "knot-confirm-message"),
                        button("Save", |state: &mut DesktopState, _| state.confirm_save())
                            .attr("id", "knot-confirm-save"),
                        button("Discard", |state: &mut DesktopState, _| {
                            state.confirm_discard()
                        }),
                        button("Cancel", |state: &mut DesktopState, _| {
                            state.cancel_pending()
                        }),
                    ),
                )
                .attr("class", "knot-confirm")
                .attr("role", "dialog")
                .attr("aria-label", "Unsaved changes"),
            )
        },
        None => Box::new(el("div", ())),
    };
    let message = state.message.clone().unwrap_or_else(|| "Ready.".to_owned());
    let snapshot = state.focused_key().map(|_| {
        let mut snapshot = state.document().snapshot();
        snapshot.dirty |= state.entry().recovery_candidate;
        snapshot
    });
    let mut chips = snapshot
        .as_ref()
        .map(crate::status::chips)
        .unwrap_or_default();
    if snapshot.is_some() {
        chips.extend(catalog_state(state).map(crate::status::catalog_chip));
        if retention_shown(state) {
            chips.push(crate::status::retention_chip(retention_state(state)));
        }
    }
    if let Some(entry) = state
        .site_page()
        .and_then(|page| state.scroll.site(page.site))
    {
        let label = match entry.server.as_ref() {
            Some(server) => format!("{} · serving :{}", entry.name(), server.address().port()),
            None => format!("{} · not serving", entry.name()),
        };
        chips.push(crate::status::serving_chip(label));
    }
    if let Some(recovery) = state.recovery.as_ref() {
        chips.push(crate::status::recovery_chip(
            recovery.records.len(),
            recovery.issues.len(),
            state.recovery_error.is_some(),
        ));
    } else if state.recovery_error.is_some() {
        chips.push(crate::status::recovery_chip(0, 0, true));
    }
    let status_bar = cambium::status_bar(
        cambium::StatusBar::new(&message, &chips)
            .with_chip_limit(state.collapse.chip_limit(state.viewport.0)),
        &state.status_bar,
        |state: &mut DesktopState, event| state.status_bar.apply(event),
        |key: &str| match key {
            crate::status::CATALOG => Some(catalog_detail(state)),
            crate::status::RETENTION => Some(retention_detail(state)),
            crate::status::SERVING => Some(serving_detail(state)),
            crate::status::RECOVERY => Some(recovery_detail(state)),
            _ => {
                let sections = crate::status::sections(key, snapshot.as_ref()?)?;
                let save: Option<DesktopView> = (key == crate::status::SAVE).then(|| {
                    Box::new(button("Save", |state: &mut DesktopState, _| state.save()))
                        as DesktopView
                });
                Some(Box::new(
                    el("div", (cambium::detail_panel(&sections), save))
                        .attr("class", "knot-status-detail"),
                ) as DesktopView)
            },
        },
    );
    let document_preview_button: DesktopView =
        if crate::document_preview::supported(state.document().snapshot().format) {
            reading_toggle(
                state,
                ReadingKind::Preview,
                commands::PREVIEW,
                "Show Preview",
                "Hide Preview",
            )
        } else {
            Box::new(el("div", ()))
        };
    let document_folding_button: DesktopView =
        if crate::document_folding::supported(state.document().snapshot().format) {
            reading_toggle(
                state,
                ReadingKind::Folded,
                commands::FOLDS,
                "Show folds",
                "Hide folds",
            )
        } else {
            Box::new(el("div", ()))
        };
    let chrome: DesktopView = if state.command_chrome == CommandChrome::ClientTitlebar {
        client_titlebar(state)
    } else if state.command_menu_compact {
        Box::new(
            el(
                "nav",
                (
                    crate::scroll_site::site_popover(state),
                    command_menu_bar_view(state),
                ),
            )
            .attr("class", "knot-workspace-toolbar")
            .attr("aria-label", "Commands"),
        )
    } else {
        Box::new(
            el(
                "nav",
                (
                    el(
                        "div",
                        (
                            crate::scroll_site::site_popover(state),
                            button("Commands", |state: &mut DesktopState, _| {
                                state.activate_command(commands::PALETTE)
                            })
                            .attr("id", "knot-command-palette-trigger"),
                        ),
                    )
                    .attr("class", "knot-command-entry"),
                    command_button(state, commands::NEW, "New"),
                    path_popover(state, PathCommand::Open, false),
                    command_button(state, commands::SAVE, "Save"),
                    path_popover(state, PathCommand::SaveAs, false),
                    command_button(state, commands::RELOAD, "Reload"),
                    command_button(state, commands::COMPARE, "Compare"),
                    reading_toggle(
                        state,
                        ReadingKind::Changes,
                        commands::CHANGES,
                        "Show changes",
                        "Hide changes",
                    ),
                    document_preview_button,
                    document_folding_button,
                    button("Appearance", |state: &mut DesktopState, _| {
                        state.activate_command(commands::APPEARANCE);
                    })
                    .attr("aria-expanded", state.appearance_open.to_string())
                    .attr("aria-controls", "knot-appearance-panel"),
                    reading_toggle(
                        state,
                        ReadingKind::Outline,
                        commands::OUTLINE,
                        "Show Outline",
                        "Hide Outline",
                    ),
                    reading_toggle(
                        state,
                        ReadingKind::Readings,
                        commands::READINGS,
                        "Readings",
                        "Hide Readings",
                    ),
                    navigator_toggle(state),
                    graph_toggle(state),
                    reading_toggle(
                        state,
                        ReadingKind::Submit,
                        commands::SUBMIT,
                        "Upload / submit",
                        "Hide upload / submit",
                    ),
                ),
            )
            .attr("class", "knot-workspace-toolbar")
            .attr("aria-label", "Commands"),
        )
    };
    Box::new(
        el(
            "main",
            (
                chrome,
                (state.command_chrome == CommandChrome::ClientTitlebar
                    && (state.open_popover.open || state.save_as_popover.open))
                    .then(|| client_command_popovers(state)),
                state.command_palette_open.then(|| command_palette_view(state)),
                span("0").attr("id", "knot-source-ch-probe")
                    .attr("aria-hidden", "true")
                    .attr("style", format!("position:fixed;left:0;top:0;display:block;width:1ch;height:1px;visibility:hidden;overflow:hidden;font-family:{};font-size:{}px;", state.appearance.source_face.css_family(), state.appearance.font_size)),
                state.appearance_open.then_some(appearance_panel),
                state.link_form.as_ref().map(|_| crate::link_workflow::form_view(state)),
                document_frame(state),
                state.pending.as_ref().map(|_| prompt),
                status_bar,
            ),
        )
        .attr(
            "class",
            format!(
                "{}{}",
                state.appearance.root_class(),
                if state.document().snapshot().format.native_source() {
                    " knot-native-site-mode"
                } else {
                    ""
                },
            ),
        ),
    )
}

/// A toolbar control projected from the catalog's current availability.
fn command_button(state: &DesktopState, id: &'static str, label: &'static str) -> DesktopView {
    let reason = commands::disabled_reason(state, id);
    let mut control = button(label, move |state: &mut DesktopState, _| {
        state.activate_command(id)
    })
    .attr("data-command-id", id)
    .attr("aria-disabled", reason.is_some().to_string());
    if let Some(reason) = reason {
        control = control.attr("aria-description", reason);
    }
    Box::new(control)
}

/// A command-row button that shows or hides the reading of `kind` following
/// the focused document, naming that tile's region while it is open.
fn reading_toggle(
    state: &DesktopState,
    kind: ReadingKind,
    command: &'static str,
    show: &'static str,
    hide: &'static str,
) -> DesktopView {
    let following = state.docs.following_reading(kind);
    let reason = commands::disabled_reason(state, command);
    let mut toggle = button(
        if following.is_some() { hide } else { show },
        move |state: &mut DesktopState, _| state.activate_command(command),
    )
    .attr("aria-expanded", following.is_some().to_string())
    .attr("data-command-id", command)
    .attr("aria-disabled", reason.is_some().to_string());
    if let Some(reason) = reason {
        toggle = toggle.attr("aria-description", reason);
    }
    match following {
        Some(tile) => Box::new(toggle.attr("aria-controls", reading_region_id(tile))),
        None => Box::new(toggle),
    }
}

/// The command row's Navigator toggle, naming the Navigator's region while
/// it is open.
fn navigator_toggle(state: &DesktopState) -> DesktopView {
    let open = state.docs.navigator();
    let toggle = button(
        if open.is_some() {
            "Hide Navigator"
        } else {
            crate::navigator::TITLE
        },
        |state: &mut DesktopState, _| state.activate_command(commands::NAVIGATOR),
    )
    .attr("aria-expanded", open.is_some().to_string());
    match open {
        Some(tile) => Box::new(toggle.attr("aria-controls", crate::navigator::region_id(tile))),
        None => Box::new(toggle),
    }
}

fn graph_toggle(state: &DesktopState) -> DesktopView {
    let open = state.docs.graph();
    let toggle = button(
        if open.is_some() {
            "Hide Graph"
        } else {
            "Graph"
        },
        |state: &mut DesktopState, _| state.activate_command(commands::GRAPH),
    )
    .attr("aria-expanded", open.is_some().to_string());
    match open {
        Some(_) => Box::new(toggle.attr("aria-controls", crate::graph::REGION_ID)),
        None => Box::new(toggle),
    }
}

/// The id of a reading tile's region.
fn reading_region_id(tile: workbench::TileId) -> String {
    format!("knot-reading-{}", tile.0)
}

/// A command that takes a path: its button opens a popover holding a
/// single-line path field and the command's own button; Enter runs it too.
fn path_popover(state: &DesktopState, command: PathCommand, hidden_trigger: bool) -> DesktopView {
    let (label, shown, field_id, trigger_id, confirm_id) = match command {
        PathCommand::Open => (
            "Open",
            &state.open_popover,
            "knot-path-field",
            "knot-open",
            "knot-open-confirm",
        ),
        PathCommand::SaveAs => (
            "Save As",
            &state.save_as_popover,
            "knot-save-as-field",
            "knot-save-as",
            "knot-save-as-confirm",
        ),
    };
    let field: fn(&mut DesktopState) -> &mut TextInput = match command {
        PathCommand::Open => |state| &mut state.path,
        PathCommand::SaveAs => |state| &mut state.save_as_path,
    };
    let mut model = Popover::new(label, shown)
        .with_placement(PopoverPlacement::BelowStart)
        .with_trigger_attr("id", trigger_id);
    if hidden_trigger {
        model = model
            .with_trigger_attr("style", "display:none")
            .with_trigger_attr("aria-hidden", "true")
            .with_trigger_attr("tabindex", "-1");
    } else if let Some(reason) = commands::disabled_reason(
        state,
        match command {
            PathCommand::Open => commands::OPEN,
            PathCommand::SaveAs => commands::SAVE_AS,
        },
    ) {
        model = model
            .with_trigger_attr("aria-disabled", "true")
            .with_trigger_attr("aria-description", reason);
    }
    popover(
        model,
        move |state: &mut DesktopState, event| state.path_popover_event(command, event),
        || {
            let body = el(
                "div",
                (
                    el(
                        "label",
                        (
                            "Path",
                            lens(|input: &mut TextInput| text_field_typed(input), field),
                        ),
                    )
                    .attr("id", field_id)
                    .attr("class", "knot-path-field"),
                    button(label, move |state: &mut DesktopState, _| {
                        state.confirm_path(command)
                    })
                    .attr("id", confirm_id),
                ),
            )
            .attr("class", "knot-path-popover");
            Some(Box::new(
                on_key(body, move |state: &mut DesktopState, event| {
                    if matches!(event.key, cambium::Key::Named(cambium::NamedKey::Enter)) {
                        event.prevent_default();
                        state.confirm_path(command);
                    }
                })
                .focusable(false),
            ) as DesktopView)
        },
    )
}

fn command_palette_view(state: &DesktopState) -> DesktopView {
    if !state.command_palette_open {
        return Box::new(el("div", ()));
    }
    let items = commands::palette_items(&commands::groups(state));
    let shown = items.clone();
    let list: DesktopView = Box::new(map_action(
        lens(
            move |palette: &mut CommandState| cambium::command_palette(palette, &items),
            |state: &mut DesktopState| &mut state.command_palette,
        ),
        move |state: &mut DesktopState, event: CommandEvent| match event {
            CommandEvent::Activate(path) => {
                let id = shown
                    .get(path.first().copied().unwrap_or(usize::MAX))
                    .map(|item| item.id.clone());
                state.dismiss_command_palette();
                if let Some(id) = id {
                    state.activate_command(&id);
                }
            },
            CommandEvent::Dismiss => state.dismiss_command_palette(),
        },
    ));
    let dialog = el(
        "div",
        (
            el(
                "label",
                (
                    span("Search commands"),
                    lens(
                        |input: &mut TextInput| text_field_typed(input),
                        |state: &mut DesktopState| &mut state.command_query,
                    ),
                ),
            )
            .attr("id", "knot-command-query")
            .attr("class", "knot-command-query"),
            list,
        ),
    )
    .attr("id", "knot-command-palette")
    .attr("class", "knot-command-palette")
    .attr("role", "dialog")
    .attr("aria-modal", "true")
    .attr("aria-label", "Commands");
    Box::new(el(
        "div",
        (
            on_click(
                el("div", ())
                    .attr("class", "knot-command-backdrop")
                    .attr("aria-hidden", "true"),
                |state: &mut DesktopState, _| state.dismiss_command_palette(),
            ),
            dialog,
        ),
    ))
}

fn command_menu_bar_view(state: &DesktopState) -> DesktopView {
    let groups = commands::groups(state);
    let shown = groups.clone();
    let compact = state.command_menu_compact;
    Box::new(map_action(
        lens(
            move |menu: &mut CommandMenuBarState| cambium::command_menu_bar(menu, &groups, compact),
            |state: &mut DesktopState| &mut state.command_menu_bar,
        ),
        move |state: &mut DesktopState, event: CommandEvent| {
            state.menu_restore_focus = true;
            if let CommandEvent::Activate(path) = event
                && let Some(id) = commands::id_at_path(&shown, &path)
            {
                state.activate_command(&id);
            }
        },
    ))
}

fn client_titlebar(state: &DesktopState) -> DesktopView {
    let title = state.document().snapshot().display_label;
    Box::new(
        el(
            "header",
            (
                command_menu_bar_view(state),
                span(title)
                    .attr("class", "knot-client-titlebar-title")
                    .attr("aria-label", "Document title"),
                command_button(state, commands::SAVE, "Save"),
                if state.command_menu_compact {
                    Box::new(el("div", ())) as DesktopView
                } else {
                    reading_toggle(
                        state,
                        ReadingKind::Outline,
                        commands::OUTLINE,
                        "Outline",
                        "Hide Outline",
                    )
                },
                if !state.command_menu_compact
                    && crate::document_preview::supported(state.document().snapshot().format)
                {
                    reading_toggle(
                        state,
                        ReadingKind::Preview,
                        commands::PREVIEW,
                        "Preview",
                        "Hide Preview",
                    )
                } else {
                    Box::new(el("div", ())) as DesktopView
                },
                if state.command_menu_compact {
                    Box::new(el("div", ())) as DesktopView
                } else {
                    reading_toggle(
                        state,
                        ReadingKind::Readings,
                        commands::READINGS,
                        "Readings",
                        "Hide Readings",
                    )
                },
                button("−", |state: &mut DesktopState, _| state.window.minimize())
                    .attr("aria-label", "Minimize window")
                    .attr("class", "knot-client-caption"),
                button("□", |state: &mut DesktopState, _| {
                    state.window.toggle_maximize()
                })
                .attr("aria-label", "Maximize window")
                .attr("class", "knot-client-caption"),
                button("×", |state: &mut DesktopState, _| state.window.close())
                    .attr("aria-label", "Close window")
                    .attr("class", "knot-client-caption"),
            ),
        )
        .attr("class", "knot-client-titlebar")
        .attr("aria-label", "Knot title bar"),
    )
}

fn client_command_popovers(state: &DesktopState) -> DesktopView {
    Box::new(
        el(
            "div",
            (
                path_popover(state, PathCommand::Open, true),
                path_popover(state, PathCommand::SaveAs, true),
                crate::scroll_site::site_popover_with_hidden_trigger(state, true),
            ),
        )
        .attr("class", "knot-client-command-popovers"),
    )
}

/// A typed path, or the sentence that asks for one.
fn field_path(field: &TextInput) -> Result<PathBuf, String> {
    let value = field.text().trim();
    if value.is_empty() {
        Err("Enter a file path first.".to_owned())
    } else {
        Ok(PathBuf::from(value))
    }
}

/// A path as a person reads it: without the Windows verbatim prefix a
/// canonical path carries (D5).
pub fn display_path(path: &Path) -> String {
    let text = path.display().to_string();
    if let Some(rest) = text.strip_prefix(r"\\?\UNC\") {
        return format!(r"\\{rest}");
    }
    match text.strip_prefix(r"\\?\") {
        Some(rest) if rest.get(1..2) == Some(":") => rest.to_owned(),
        _ => text,
    }
}

/// One document tile: its editor and the panels read from it, the writing
/// area the window had before tabs. The panels read the focused entry, which
/// is the document a single stack shows.
fn document_tile(state: &DesktopState, key: DocKey) -> DesktopView {
    let highlight = state.appearance.highlight;
    let document: DesktopView = Box::new(lens(
        move |state: &mut KnotDocumentSurfaceState| {
            knot_document_view_with_status(state, highlight, KnotDocumentStatus::HostOwned)
        },
        move |state: &mut DesktopState| state.surface_mut_for(key),
    ));
    let source_wrapper = el("div", document)
        .attr("class", "knot-source-wrapper")
        .attr(
            "style",
            state
                .appearance
                .writing_style(&state.surface_for(key).snapshot().text),
        );
    Box::new(
        el(
            "div",
            el("div", source_wrapper).attr("class", "knot-writing-area"),
        )
        .attr("class", "knot-document-tile")
        .attr("data-knot-document", key.0.to_string()),
    )
}

fn graph_view(state: &DesktopState) -> DesktopView {
    let open = state.graph_open_nodes();
    let model = state.graph.model(&open);
    let view = mere_view::MereView {
        model: &model,
        state: &state.graph.view,
        leaf_key: crate::graph::LEAF_KEY,
        width: state.graph.size.0,
        height: state.graph.size.1,
    };
    Box::new(
        el(
            "div",
            mere_view::mere_view(
                view,
                |state: &mut DesktopState, event| state.graph.view.apply(event),
                |state: &mut DesktopState, request| state.carry_graph_request(request),
            ),
        )
        .attr("id", crate::graph::REGION_ID)
        .attr("class", "knot-graph"),
    )
}

/// The Workbench frame: every open document as a tab, its tile rendered on
/// demand through an identity lens so the tile can read the whole window's
/// state. A document's tab carries its mark: needs attention after a
/// refusal, else unsaved changes.
fn document_frame(state: &DesktopState) -> DesktopView {
    let current = state.docs.focused().and_then(|key| state.docs.tile_of(key));
    let model = WorkspaceModel {
        workspace: state.docs.workspace(),
        current,
        float_layer_visible: false,
    };
    let marks = |tile: workbench::TileId| match state.docs.role(tile) {
        Some(TileRole::Document(key)) => state.docs.doc(*key).and_then(|entry| {
            let mut snapshot = entry.document.snapshot();
            snapshot.dirty |= entry.recovery_candidate;
            crate::status::tab_mark(&snapshot)
        }),
        Some(TileRole::Metadata { site, page }) => state
            .draft_dirty(*site, page)
            .then_some(cambium::TabMark::Modified),
        _ => None,
    };
    Box::new(
        el(
            "div",
            workspace_view_presented_with_marks(
                &model,
                &marks,
                &state.presentation,
                |state: &mut DesktopState, event| state.on_workspace_event(event),
                |state: &mut DesktopState, event| state.on_presentation_event(event),
                tile_fill,
            ),
        )
        .attr("class", "knot-frame")
        .attr("id", "knot-frame"),
    )
}

fn tile_fill(tile: &workbench::Tile) -> Slot<DesktopState, ()> {
    let id = tile.id;
    Slot::View(Box::new(lens(
        move |state: &mut DesktopState| tile_view(state, id),
        |state: &mut DesktopState| state,
    )))
}

fn tile_view(state: &DesktopState, tile: workbench::TileId) -> DesktopView {
    match state.docs.role(tile) {
        Some(TileRole::Document(key)) => document_tile(state, *key),
        Some(TileRole::Reading { kind, pinned }) => reading_tile(state, tile, *kind, *pinned),
        Some(TileRole::Navigator) => crate::navigator::view(state, tile),
        Some(TileRole::Graph) => graph_view(state),
        Some(TileRole::Metadata { site, page }) => {
            crate::scroll_site::metadata_view(state, tile, *site, page)
        },
        Some(TileRole::Site(site)) => crate::scroll_site::site_view(state, *site),
        None => Box::new(el("div", ())),
    }
}

/// A reading's tab title.
pub(crate) fn reading_title(kind: ReadingKind) -> &'static str {
    match kind {
        ReadingKind::Outline => "Outline",
        ReadingKind::Preview => "Preview",
        ReadingKind::Folded => "Folded source",
        ReadingKind::Readings => "Readings",
        ReadingKind::Changes => "Changes",
        ReadingKind::Links => "Links",
        ReadingKind::Submit => "Upload / submit",
    }
}

/// A reading tile: a header naming the reading and the document it reads,
/// with a Pin that keeps it on that document, above the reading itself.
fn reading_tile(
    state: &DesktopState,
    tile: workbench::TileId,
    kind: ReadingKind,
    pinned: Option<DocKey>,
) -> DesktopView {
    let Some(key) = state.docs.document_for(tile) else {
        return Box::new(
            el("div", span("No document is open."))
                .attr("class", "knot-reading knot-reading-empty"),
        );
    };
    let label = state.surface_for(key).snapshot().display_label;
    let header = el(
        "header",
        (
            span(reading_title(kind)).attr("class", "knot-reading-title"),
            span("·")
                .attr("class", "knot-reading-separator")
                .attr("aria-hidden", "true"),
            span(label).attr("class", "knot-reading-document"),
            button(
                if pinned.is_some() { "Unpin" } else { "Pin" },
                move |state: &mut DesktopState, _| state.toggle_pin(tile),
            )
            .attr("class", "knot-reading-pin")
            .attr("aria-pressed", pinned.is_some().to_string()),
        ),
    )
    .attr("class", "knot-reading-header");
    let body: DesktopView = match kind {
        ReadingKind::Outline => outline_body(state, key),
        ReadingKind::Preview => crate::document_preview::view(state, key, tile),
        ReadingKind::Readings => crate::readings::view(state, key, tile),
        ReadingKind::Folded => crate::document_folding::view(state, key, tile),
        ReadingKind::Changes => crate::changes::view(state, key, tile),
        ReadingKind::Links => crate::link_workflow::reading_view(state, key),
        ReadingKind::Submit => crate::scroll_site::submit_view(state, key),
    };
    Box::new(
        el("section", (header, body))
            .attr("class", "knot-reading")
            .attr("id", reading_region_id(tile))
            .attr("data-knot-reading", tile.0.to_string())
            .attr("role", "region")
            .attr(
                "aria-label",
                format!(
                    "{} of {label_for_region}",
                    reading_title(kind),
                    label_for_region = state.surface_for(key).snapshot().display_label
                ),
            ),
    )
}

/// The outline of `key`'s document: a row per heading that selects its
/// source range in that document.
fn outline_body(state: &DesktopState, key: DocKey) -> DesktopView {
    let Some(entry) = state.docs.doc(key) else {
        return Box::new(el("div", ()));
    };
    if entry.document.snapshot().format.native_source() {
        return Box::new(
            span("A source outline is not available for this native protocol format yet. Use its preview when available.")
                .attr("class", "knot-outline"),
        );
    }
    let error = entry
        .outline_error
        .as_ref()
        .map(|error| span(format!("Outline error: {error}")).attr("class", "knot-outline-error"));
    let rows: DesktopView = match &entry.outline_snapshot {
        None => Box::new(span("Outline is updating; try again shortly.")),
        Some(snapshot) if snapshot.items.is_empty() => {
            Box::new(span("No headings in this document."))
        },
        Some(snapshot) => {
            let rows = snapshot
                .items
                .iter()
                .enumerate()
                .map(|(index, item)| {
                    let label = item.label.clone();
                    let level = item.level;
                    let accessible_label = format!("Heading level {level}: {label}");
                    (
                        item.start,
                        button(label, move |state: &mut DesktopState, _| {
                            state.select_outline_item_in(key, index);
                        })
                        .attr("class", "knot-outline-row")
                        .attr("data-outline-index", index.to_string())
                        .attr("data-outline-level", level.to_string())
                        .attr("aria-label", accessible_label),
                    )
                })
                .collect::<Vec<_>>();
            Box::new(el("div", Keyed::new(rows)).attr("class", "knot-outline-rows"))
        },
    };
    Box::new(el("div", (error, rows)).attr("class", "knot-outline"))
}

fn ancestor_has_id<D: LayoutDom>(dom: &D, focused: D::NodeId, id: &str) -> bool {
    let namespace = Namespace::from("");
    let local = LocalName::from("id");
    let mut node = Some(focused);
    while let Some(current) = node {
        if dom.attribute(current, &namespace, &local) == Some(id) {
            return true;
        }
        node = dom.parent(current);
    }
    false
}

/// The document whose tile holds `node`, read off the tile's
/// `data-knot-document`.
/// The nearest value of attribute `name` on `node` or an ancestor.
fn ancestor_attribute<D: LayoutDom>(dom: &D, node: D::NodeId, name: &str) -> Option<String> {
    let namespace = Namespace::from("");
    let local = LocalName::from(name);
    let mut node = Some(node);
    while let Some(current) = node {
        if let Some(value) = dom.attribute(current, &namespace, &local) {
            return Some(value.to_string());
        }
        node = dom.parent(current);
    }
    None
}

fn document_key_of<D: LayoutDom>(dom: &D, node: D::NodeId) -> Option<DocKey> {
    let namespace = Namespace::from("");
    let local = LocalName::from("data-knot-document");
    let mut node = Some(node);
    while let Some(current) = node {
        if let Some(value) = dom.attribute(current, &namespace, &local) {
            return value.parse().ok().map(DocKey);
        }
        node = dom.parent(current);
    }
    None
}

fn ancestor_has_class<D: LayoutDom>(dom: &D, focused: D::NodeId, class: &str) -> bool {
    let mut node = Some(focused);
    while let Some(current) = node {
        if dom.has_class(current, class) {
            return true;
        }
        node = dom.parent(current);
    }
    false
}

pub fn focused_text(runner: &DesktopRunner) -> Option<FocusedTextSlot<DesktopState>> {
    let focused = runner.focus()?;
    let dom = runner.dom();
    let dom_ref = dom.borrow();
    let name = LayoutDom::element_name(&*dom_ref, focused)?;
    let is_text_control = name.local.as_ref() == "textarea" || name.local.as_ref() == "input";
    let is_document_textarea = name.local.as_ref() == "textarea";
    if !is_text_control {
        return None;
    }
    let folder = ancestor_has_id(&*dom_ref, focused, "knot-scroll-folder");
    let port = ancestor_has_class(&*dom_ref, focused, "knot-site-port")
        .then(|| ancestor_attribute(&*dom_ref, focused, "data-knot-site"))
        .flatten()
        .and_then(|site| site.parse().ok())
        .map(SiteKey);
    let submission = ancestor_attribute(&*dom_ref, focused, "data-knot-submission")
        .and_then(|key| key.parse().ok())
        .map(DocKey);
    let composer_field = crate::scroll_site::COMPOSER_FIELDS
        .iter()
        .position(|class| ancestor_has_class(&*dom_ref, focused, class));
    let metadata_tile = ancestor_attribute(&*dom_ref, focused, "data-knot-metadata")
        .and_then(|tile| tile.parse().ok())
        .map(workbench::TileId);
    let metadata =
        (0..6).find(|i| ancestor_has_class(&*dom_ref, focused, &format!("knot-meta-field-{i}")));
    let path = ancestor_has_id(&*dom_ref, focused, "knot-path-field");
    let save_as_path = ancestor_has_id(&*dom_ref, focused, "knot-save-as-field");
    let document = document_key_of(&*dom_ref, focused);
    drop(dom_ref);
    if folder {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(|s| &s.scroll.folder),
            get_mut: Box::new(|s| &mut s.scroll.folder),
        });
    }
    if let Some(site) = port {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(move |s| crate::scroll_site::site_port_field(s, site)),
            get_mut: Box::new(move |s| crate::scroll_site::site_port_field_mut(s, site)),
        });
    }
    if let (Some(key), Some(field)) = (submission, composer_field) {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(move |s| crate::scroll_site::composer_text(s, key, field)),
            get_mut: Box::new(move |s| crate::scroll_site::composer_text_mut(s, key, field)),
        });
    }
    if let (Some(tile), Some(i)) = (metadata_tile, metadata) {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(move |s| crate::scroll_site::draft_field(s, tile, i)),
            get_mut: Box::new(move |s| &mut crate::scroll_site::draft_fields(s, tile)[i]),
        });
    }
    if path {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(|state| &state.path),
            get_mut: Box::new(|state| &mut state.path),
        });
    }
    if save_as_path {
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(|state| &state.save_as_path),
            get_mut: Box::new(|state| &mut state.save_as_path),
        });
    }
    if is_document_textarea {
        let key = document.or_else(|| runner.state().focused_key())?;
        if runner.state().surface_for(key).snapshot().write_posture
            == knot_document::KnotDocumentWritePostureV1::ReadOnly
        {
            return None;
        }
        return Some(FocusedTextSlot {
            node: focused,
            get: Box::new(move |state| state.surface_for(key).session().input()),
            get_mut: Box::new(move |state| {
                state
                    .surface_mut_for(key)
                    .session_mut()
                    .input_mut()
                    .expect("editable document focus")
            }),
        });
    }
    None
}

/// Whether keyboard focus is in an open document's source editor. Scenario
/// receipts use this host fact instead of inferring focus from visible text.
pub(crate) fn source_is_focused(runner: &DesktopRunner) -> bool {
    let Some(focused) = runner.focus() else {
        return false;
    };
    let dom = runner.dom();
    let dom = dom.borrow();
    LayoutDom::element_name(&*dom, focused).is_some_and(|name| name.local.as_ref() == "textarea")
        && document_key_of(&*dom, focused).is_some()
}

pub fn key_intercept(runner: &mut DesktopRunner, press: &KeyPress) -> bool {
    if runner.state().link_form.is_some()
        && matches!(
            press.key,
            Key::Named(cambium_genet_winit_host::NamedKey::Escape)
        )
    {
        runner.update(crate::link_workflow::dismiss);
        return true;
    }
    if runner.state().command_palette_open {
        let query_focused = runner.focus().is_some_and(|focused| {
            let dom = runner.dom();
            ancestor_has_id(&*dom.borrow(), focused, "knot-command-query")
        });
        match press.key {
            Key::Named(cambium_genet_winit_host::NamedKey::Escape) => {
                runner.update(DesktopState::dismiss_command_palette);
                return true;
            },
            Key::Named(cambium_genet_winit_host::NamedKey::Tab) => {
                let target_id = if query_focused {
                    "knot-command-list"
                } else {
                    "knot-command-query"
                };
                if let Some(target) = runner.focusables().into_iter().find(|node| {
                    let dom = runner.dom();
                    ancestor_has_id(&*dom.borrow(), *node, target_id)
                }) {
                    runner.set_focus(Some(target));
                }
                return true;
            },
            Key::Named(cambium_genet_winit_host::NamedKey::ArrowDown) if query_focused => {
                runner.update(|state| state.move_palette_selection(true));
                return true;
            },
            Key::Named(cambium_genet_winit_host::NamedKey::ArrowUp) if query_focused => {
                runner.update(|state| state.move_palette_selection(false));
                return true;
            },
            Key::Named(cambium_genet_winit_host::NamedKey::Enter) if query_focused => {
                runner.update(DesktopState::activate_palette_selection);
                return true;
            },
            _ => {},
        }
        if !query_focused
            && ((matches!(press.key, Key::Character(_)) && !press.modifiers.is_command_chord())
                || matches!(
                    press.key,
                    Key::Named(cambium_genet_winit_host::NamedKey::Backspace)
                )
                || (commands::shortcut_id(press).is_none() && press.modifiers.is_command_chord()))
        {
            if let Some(query) = runner.focusables().into_iter().find(|node| {
                let dom = runner.dom();
                ancestor_has_id(&*dom.borrow(), *node, "knot-command-query")
            }) {
                runner.set_focus(Some(query));
            }
            return false;
        }
    }
    if runner.state().command_chrome == CommandChrome::ClientTitlebar
        && !runner.state().command_palette_open
        && matches!(
            press.key,
            Key::Named(cambium_genet_winit_host::NamedKey::F10)
                | Key::Named(cambium_genet_winit_host::NamedKey::Alt)
        )
        && let Some(event) = press.to_runner_key()
    {
        let previous = runner.focus();
        let mut entered = false;
        runner.update(|state| {
            entered = state.command_menu_bar.handle_entry_key(&event);
            if entered && state.menu_return_focus.is_none() {
                state.menu_return_focus = previous.or(state.last_content_focus);
            }
        });
        if entered {
            return true;
        }
    }
    let Some(id) = commands::shortcut_id(press) else {
        return false;
    };
    if id == commands::PALETTE && !runner.state().command_palette_open {
        let previous = runner.focus();
        runner.update(|state| {
            state.palette_return_focus = previous;
            state.activate_command(id);
        });
    } else if id == commands::PALETTE {
        runner.update(DesktopState::dismiss_command_palette);
    } else if !runner.state().command_palette_open {
        runner.update(|state| state.activate_command(id));
    } else {
        return false;
    }
    true
}

pub fn close_request(runner: &mut DesktopRunner, request: CloseRequest) -> CloseDisposition {
    let mut disposition = CloseDisposition::KeepVisible;
    runner.update(|state| disposition = state.close_request(request));
    disposition
}

/// Complete an outline activation after the click has rebuilt the retained
/// tree. The click target itself is a button, so focus must be returned to the
/// existing document textarea before the next key or IME event is routed.
pub fn after_dispatch(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    ctx.runner.update(DesktopState::sync_recovery);
    if ctx.runner.state().composition.busy() {
        ctx.runner.update(|state| state.composition.drain());
    }
    if ctx.runner.state().retention_receiver.is_some() {
        ctx.runner.update(|state| state.drain_retention());
    }
    if ctx.runner.state().submissions_busy() {
        ctx.runner.update(DesktopState::drain_submissions);
    }
    // An edit or page change since the last dispatch: drop the fold state of
    // headings the source no longer has before the next toggle can see it.
    if ctx.runner.state().micron_folds_need_sync() {
        ctx.runner.update(DesktopState::sync_micron_folds);
    }
    if ctx.runner.state().closed_tiles_hold_state() {
        ctx.runner.update(DesktopState::prune_tile_state);
    }
    crate::scroll_site::scroll_to_micron_jump(ctx);
    sync_command_query(ctx);
    reveal_palette_selection(ctx);
    focus_command_menu(ctx);
    focus_command_palette(ctx);
    focus_path_field(ctx);
    if ctx.runner.state().link_form_focus_requested {
        ctx.runner
            .update(|state| state.link_form_focus_requested = false);
        let target = ctx.runner.focusables().into_iter().find(|node| {
            let dom = ctx.runner.dom();
            ancestor_has_id(&*dom.borrow(), *node, "knot-link-form")
        });
        if let Some(target) = target {
            ctx.runner.set_focus(Some(target));
        }
    }
    track_content_focus(ctx);
    let state = ctx.runner.state();
    let focus_requested = state.entry().focus_source_requested;
    let outline_needs_sync = state
        .reading_documents(ReadingKind::Outline)
        .into_iter()
        .any(|key| state.outline_stale(key));
    // A Folded tile follows its source: an edit re-derives the folds rather
    // than closing the tile, and the folds that still exist stay collapsed.
    let folds_need_sync = state
        .reading_documents(ReadingKind::Folded)
        .into_iter()
        .any(|key| state.fold_stale(key));
    if !focus_requested && !outline_needs_sync && !folds_need_sync {
        return;
    }
    ctx.runner.update(|state| {
        if outline_needs_sync {
            state.sync_outline_snapshot();
        }
        if folds_need_sync {
            state.sync_fold_snapshots();
        }
    });
    if !focus_requested {
        return;
    }
    focus_pending_source(ctx);
}

/// Complete an application focus intent after the destination subtree exists.
/// Host dispatch normally does this immediately; frame preparation also drains
/// intents raised by retained runner dispatch (including scenario key input).
/// Keep the request if its editor has not mounted yet, so a layout cannot lose it.
fn focus_pending_source(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) -> bool {
    if !ctx.runner.state().entry().focus_source_requested {
        return false;
    }
    let focused_key = ctx.runner.state().focused_key();
    let (target, workspace) = {
        let dom = ctx.runner.dom();
        let dom_ref = dom.borrow();
        let target = ctx.runner.focusables().into_iter().find(|node| {
            LayoutDom::element_name(&*dom_ref, *node)
                .is_some_and(|name| name.local.as_ref() == "textarea")
                && ancestor_has_class(&*dom_ref, *node, "knot-document-body")
                && document_key_of(&*dom_ref, *node) == focused_key
        });
        let workspace = target.and_then(|mut node| loop {
            if dom_ref
                .attribute(node, &Namespace::from(""), &LocalName::from("class"))
                .is_some_and(|class| class.split_whitespace().any(|class| class == "knot-workspace"))
            {
                return Some(node);
            }
            node = dom_ref.parent(node)?;
        });
        (target, workspace)
    };
    if let Some(target) = target {
        ctx.runner
            .update(|state| state.entry_mut().focus_source_requested = false);
        ctx.runner.set_focus(Some(target));
        // The source keeps its own caret/selection scroll, but returning to it
        // must not scroll the fixed application chrome out of the window.
        // Requests resolve after caret-follow in the host's next layout.
        if let Some(workspace) = workspace {
            ctx.scroll_into_view(workspace, ScrollAlign::Start);
        }
        return true;
    }
    false
}

/// Put focus in the field of a path popover that has just opened.
fn focus_path_field(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    let Some(command) = ctx.runner.state().focus_path_field else {
        return;
    };
    ctx.runner.update(|state| state.focus_path_field = None);
    let id = match command {
        PathCommand::Open => "knot-path-field",
        PathCommand::SaveAs => "knot-save-as-field",
    };
    let target = {
        let dom = ctx.runner.dom();
        let dom_ref = dom.borrow();
        ctx.runner.focusables().into_iter().find(|node| {
            LayoutDom::element_name(&*dom_ref, *node)
                .is_some_and(|name| name.local.as_ref() == "input")
                && ancestor_has_id(&*dom_ref, *node, id)
        })
    };
    if let Some(target) = target {
        ctx.runner.set_focus(Some(target));
    }
}

fn sync_command_query(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    if !ctx.runner.state().command_palette_open {
        return;
    }
    let query_focused = ctx.runner.focus().is_some_and(|focused| {
        let dom = ctx.runner.dom();
        ancestor_has_id(&*dom.borrow(), focused, "knot-command-query")
    });
    let text = ctx.runner.state().command_query.text();
    let query = &ctx.runner.state().command_palette.query;
    if text == query {
        return;
    }
    if query_focused {
        let text = text.to_owned();
        ctx.runner.update(|state| {
            state.command_palette.query = text;
            state.command_palette.selected = 0;
        });
    } else {
        let query = query.clone();
        ctx.runner
            .update(|state| state.command_query = TextInput::new(query));
    }
}

/// Arrow keys can change the palette's active descendant while focus stays in
/// its query field. Keep that row inside the list's bounded scrollport, rather
/// than relying on focus-follow (the option itself never receives focus).
fn reveal_palette_selection(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    if !ctx.runner.state().command_palette_open {
        return;
    }
    fn node_with_id<D: LayoutDom>(dom: &D, node: D::NodeId, id: &str) -> Option<D::NodeId> {
        if dom.attribute(node, &Namespace::from(""), &LocalName::from("id")) == Some(id) {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| node_with_id(dom, child, id))
    }
    let active_id = {
        let dom = ctx.runner.dom();
        let dom = dom.borrow();
        node_with_id(&*dom, dom.document(), "knot-command-list")
            .and_then(|list| {
                dom.attribute(
                    list,
                    &Namespace::from(""),
                    &LocalName::from("aria-activedescendant"),
                )
            })
            .filter(|id| !id.is_empty())
            .map(str::to_owned)
    };
    let Some(active_id) = active_id else {
        return;
    };
    let marker = (ctx.runner.state().command_palette.query.clone(), active_id);
    if ctx.runner.state().palette_last_revealed.as_ref() == Some(&marker) {
        return;
    }
    ctx.runner
        .update(|state| state.palette_last_revealed = Some(marker.clone()));
    let selected = {
        let dom = ctx.runner.dom();
        let dom = dom.borrow();
        node_with_id(&*dom, dom.document(), "knot-command-list")
            .and_then(|list| node_with_id(&*dom, list, &marker.1))
    };
    if let Some(node) = selected {
        ctx.scroll_into_view(node, ScrollAlign::Nearest);
    }
}

fn focus_command_palette(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    if ctx.runner.state().palette_focus_query {
        let previous = ctx.runner.focus();
        ctx.runner.update(|state| {
            state.palette_focus_query = false;
            if state.palette_return_focus.is_none() {
                state.palette_return_focus = previous;
            }
        });
        let target = ctx.runner.focusables().into_iter().find(|node| {
            let dom = ctx.runner.dom();
            let dom = dom.borrow();
            LayoutDom::element_name(&*dom, *node).is_some_and(|name| name.local.as_ref() == "input")
                && ancestor_has_id(&*dom, *node, "knot-command-query")
        });
        if let Some(target) = target {
            ctx.runner.set_focus(Some(target));
        }
    } else if ctx.runner.state().palette_restore_focus {
        let previous = ctx.runner.state().palette_return_focus;
        ctx.runner.update(|state| {
            state.palette_restore_focus = false;
            state.palette_return_focus = None;
        });
        let focusables = ctx.runner.focusables();
        let target = previous
            .filter(|node| focusables.contains(node))
            .or_else(|| {
                focusables.iter().copied().find(|node| {
                    let dom = ctx.runner.dom();
                    ancestor_has_id(&*dom.borrow(), *node, "knot-command-palette-trigger")
                })
            });
        if let Some(target) = target {
            ctx.runner.set_focus(Some(target));
        }
    }
}

fn focus_command_menu(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    if ctx.runner.state().command_menu_bar.open && ctx.runner.state().menu_return_focus.is_none() {
        let previous = ctx.runner.state().last_content_focus;
        ctx.runner
            .update(|state| state.menu_return_focus = previous);
    }
    if !ctx.runner.state().menu_restore_focus {
        return;
    }
    let previous = ctx.runner.state().menu_return_focus;
    ctx.runner.update(|state| {
        state.menu_restore_focus = false;
        state.menu_return_focus = None;
    });
    let focusables = ctx.runner.focusables();
    let target = previous
        .filter(|node| focusables.contains(node))
        .or_else(|| {
            focusables.into_iter().find(|node| {
                let dom = ctx.runner.dom();
                let dom = dom.borrow();
                LayoutDom::element_name(&*dom, *node)
                    .is_some_and(|name| name.local.as_ref() == "textarea")
                    && document_key_of(&*dom, *node) == ctx.runner.state().focused_key()
            })
        });
    if let Some(target) = target {
        ctx.runner.set_focus(Some(target));
    }
}

fn track_content_focus(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    let Some(focused) = ctx.runner.focus() else {
        return;
    };
    let within_commands = {
        let dom = ctx.runner.dom();
        let dom = dom.borrow();
        ancestor_has_id(&*dom, focused, "knot-command-menu-bar")
            || ancestor_has_id(&*dom, focused, "knot-command-palette")
    };
    if !within_commands && ctx.runner.state().last_content_focus != Some(focused) {
        ctx.runner
            .update(|state| state.last_content_focus = Some(focused));
    }
}

/// Drain worker completions after a host wake and rebuild the retained view.
pub fn after_wake(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) {
    ctx.runner.update(|state| {
        if let Some(recovery) = state.recovery.as_mut() {
            recovery.retry();
            let (error, failed) = recovery.drain_error();
            for id in failed {
                for (_, entry) in state.docs.docs_mut() {
                    if entry.recovery_id == Some(id) {
                        entry.recovery_fingerprint = None;
                    }
                }
            }
            if let Some(error) = error {
                state.recovery_error = Some(error);
            }
        }
    });
    if ctx.runner.state().graph.busy() {
        ctx.runner.update(|state| {
            if state.graph.drain() {
                let open = state.graph_open_nodes();
                state.graph.relayout(&open);
            }
        });
    }
    if ctx.runner.state().composition.busy() {
        ctx.runner.update(|state| state.composition.drain());
    }
    if ctx.runner.state().retention_receiver.is_some() {
        ctx.runner.update(|state| state.drain_retention());
    }
    if ctx.runner.state().submissions_busy() {
        ctx.runner.update(DesktopState::drain_submissions);
    }
}

/// The desktop's frame hook: measure any recipe cards waiting on the previous
/// layout, then the graph tile.
pub fn graph_frame(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) -> bool {
    let measuring = crate::composition::measure_recipe_cards(ctx);
    graph_tile_frame(ctx) || measuring
}

/// Measure the graph's actual tile and register the shared component's paint
/// leaf from the same model and layout used by its native targets.
fn graph_tile_frame(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) -> bool {
    let chrome_changed = update_collapse_layout(ctx);
    let focus_changed = focus_pending_source(ctx);
    fn find<D: LayoutDom>(dom: &D, node: D::NodeId) -> Option<D::NodeId> {
        let namespace = Namespace::from("");
        let id = LocalName::from("id");
        if dom.attribute(node, &namespace, &id) == Some(crate::graph::REGION_ID) {
            return Some(node);
        }
        dom.dom_children(node).find_map(|child| find(dom, child))
    }
    let node = {
        let dom = ctx.runner.dom();
        let dom = dom.borrow();
        find(&*dom, ctx.runner.root())
    };
    let Some(node) = node else {
        ctx.leaves.remove(&crate::graph::LEAF_KEY);
        return chrome_changed || focus_changed;
    };
    let Some((_, _, width, height)) = ctx.painted_rect(node) else {
        ctx.leaves.remove(&crate::graph::LEAF_KEY);
        return chrome_changed || focus_changed;
    };
    let size = (
        width.round().max(1.0) as u32,
        height.round().max(1.0) as u32,
    );
    let current = ctx.runner.state().graph.size;
    if current != size {
        ctx.runner.update(|state| {
            let open = state.graph_open_nodes();
            state.graph.set_size(size, &open);
        });
    }
    let leaf = {
        let state = ctx.runner.state();
        let open = state.graph_open_nodes();
        let model = state.graph.model(&open);
        mere_view::MereView {
            model: &model,
            state: &state.graph.view,
            leaf_key: crate::graph::LEAF_KEY,
            width: state.graph.size.0,
            height: state.graph.size.1,
        }
        .paint_leaf(|kind| state.appearance.graph_color(kind))
    };
    ctx.leaves.insert(crate::graph::LEAF_KEY, Box::new(leaf));
    chrome_changed || focus_changed || current != size
}

/// Run after real host layout, including resize and UI zoom. Harness drives
/// this same hook, so no test-only window-size state can mask a native failure.
fn update_collapse_layout(
    ctx: &mut AppCtx<'_, DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
) -> bool {
    fn find<D: LayoutDom>(dom: &D, node: D::NodeId, name: &str, value: &str) -> Option<D::NodeId> {
        if dom.attribute(node, &Namespace::from(""), &LocalName::from(name)) == Some(value) {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| find(dom, child, name, value))
    }
    let (frame, probe) = {
        let dom = ctx.runner.dom();
        let dom = dom.borrow();
        (
            find(&*dom, dom.document(), "id", "knot-frame"),
            find(&*dom, dom.document(), "id", "knot-source-ch-probe"),
        )
    };
    let viewport = ctx.logical_size;
    let Some(mut frame) = frame.and_then(|node| ctx.painted_rect(node)) else {
        return false;
    };
    frame.2 = frame.2.min(viewport.0).max(1.0);
    let state = ctx.runner.state();
    let system_ch = if state.appearance.source_face == SourceFace::SystemMonospace {
        probe
            .and_then(|node| ctx.painted_rect(node))
            .map(|rect| rect.2)
            .filter(|width| width.is_finite() && *width > 0.0)
            .map(|width| (state.appearance.font_size, width))
    } else {
        None
    };
    let measured_ch = system_ch
        .or(state.source_system_ch)
        .filter(|(size, _)| *size == state.appearance.font_size)
        .map(|(_, width)| width);
    let current = state.docs.focused().and_then(|key| state.docs.tile_of(key));
    let mut presentation = crate::collapse::presentation(
        state.docs.workspace().tiled(),
        &state.collapse,
        viewport,
        frame,
        &state.presentation,
        current,
        |tile| state.docs.role(tile).cloned(),
        |tile| match state.docs.role(tile) {
            Some(TileRole::Document(key)) => crate::collapse::source_width(
                &state.appearance,
                &state.surface_for(*key).snapshot().text,
                measured_ch,
            ),
            _ => 0.0,
        },
    );
    // Anchor each drawer to its own measured rail. Coordinates are translated
    // from the host viewport into the positioned workspace, then clamped by
    // overlay_surface; a right reading therefore opens against the right edge.
    for stack in &mut presentation.stacks {
        if let Some(drawer) = stack
            .collapsed
            .as_mut()
            .and_then(|collapsed| collapsed.drawer.as_mut())
        {
            let node = {
                let dom = ctx.runner.dom();
                let dom = dom.borrow();
                find(
                    &*dom,
                    dom.document(),
                    "data-rail",
                    &stack.anchor.0.to_string(),
                )
            };
            if let Some(rect) = node.and_then(|node| ctx.painted_rect(node)) {
                drawer.trigger = (rect.0 - frame.0, rect.1 - frame.1, rect.2, 0.0);
            }
        }
    }
    if viewport.0 < f32::from(state.collapse.drawer_below)
        && let Some(reveal) = state.collapse_reveal
    {
        fn anchor(
            tree: &workbench::TileTree,
            tile: workbench::TileId,
        ) -> Option<workbench::TileId> {
            match tree {
                workbench::TileTree::Stack(stack) => stack
                    .tabs
                    .iter()
                    .any(|t| t.id == tile)
                    .then(|| stack.tabs.first().map(|t| t.id))
                    .flatten(),
                workbench::TileTree::Split { children, .. } => {
                    children.iter().find_map(|child| anchor(&child.tree, tile))
                },
            }
        }
        if let Some(anchor) = anchor(state.docs.workspace().tiled(), reveal) {
            for stack in &mut presentation.stacks {
                if let Some(collapsed) = &mut stack.collapsed {
                    collapsed.open = stack.anchor == anchor;
                }
            }
        }
    }
    let compact = viewport.0 < f32::from(state.collapse.menu_below);
    let changed = presentation != state.presentation
        || compact != state.command_menu_compact
        || viewport != state.viewport
        || system_ch.is_some_and(|width| Some(width) != state.source_system_ch);
    if changed || state.collapse_reveal.is_some() {
        ctx.runner.update(|state| {
            state.presentation = presentation;
            state.viewport = viewport;
            state.command_menu_compact = compact;
            state.collapse_reveal = None;
            if system_ch.is_some() {
                state.source_system_ch = system_ch;
            }
        });
    }
    changed
}

pub const DESKTOP_CSS: &str = concat!(
    ".knot-workspace { display:flex; flex-direction:column; gap:12px; padding:20px 20px 0; height:100vh; box-sizing:border-box; }",
    ".knot-workspace-toolbar { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }",
    ".knot-command-entry { display:flex; align-items:center; gap:8px; }",
    ".knot-client-titlebar { --app-region:drag; display:flex; align-items:center; gap:8px; min-height:36px; margin:-20px -20px 0; padding:0 8px; border-bottom:1px solid; box-sizing:border-box; }",
    ".knot-client-titlebar-title { --app-region:drag; flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; text-align:center; }",
    ".knot-client-titlebar button { --app-region:no-drag; flex:none; }",
    ".knot-client-titlebar .knot-client-caption { width:30px; min-width:30px; padding:4px; box-sizing:border-box; }",
    ".knot-client-titlebar .command-menu-bar { --app-region:no-drag; flex:none; }",
    ".knot-client-command-popovers { position:relative; height:0; width:0; overflow:visible; }",
    ".knot-command-backdrop { position:fixed; left:0; top:0; right:0; bottom:0; z-index:199; background:#0004; }",
    ".knot-command-palette { position:fixed; top:58px; left:0; right:0; margin:0 auto; z-index:200; display:flex; flex-direction:column; gap:8px; width:560px; max-width:88vw; max-height:72vh; box-sizing:border-box; overflow:visible; padding:12px; border:1px solid; border-radius:8px; box-shadow:0 12px 30px #0004; }",
    ".knot-command-query { display:flex; flex-direction:column; gap:4px; }",
    ".knot-command-query input { width:100%; box-sizing:border-box; }",
    ".knot-command-palette .command-surface { display:flex; flex-direction:column; min-height:0; outline:none; }",
    ".knot-command-palette .command-items { display:flex; flex-direction:column; max-height:56vh; overflow:auto; }",
    ".knot-command-palette .command-item { display:flex; align-items:center; gap:8px; min-height:28px; padding:5px 8px; border-radius:4px; }",
    ".knot-command-palette .command-label { flex:1; }",
    ".knot-command-palette .command-shortcut { opacity:0.7; }",
    ".knot-command-palette .command-disabled-reason { opacity:0.7; font-size:12px; }",
    ".knot-command-palette .command-item[aria-disabled=true] { opacity:0.55; }",
    ".knot-command-palette .command-item.selected { outline:2px solid currentColor; outline-offset:-2px; }",
    ".knot-appearance-panel { display:flex; flex-direction:column; gap:8px; padding:10px; border:1px solid; max-height:30vh; min-width:0; flex-shrink:0; overflow:auto; box-sizing:border-box; }",
    ".knot-appearance-row { display:flex; align-items:center; flex-wrap:wrap; gap:6px; }",
    ".knot-font-licenses { max-height:240px; overflow:auto; }",
    ".knot-font-licenses pre { white-space:pre-wrap; overflow-wrap:anywhere; font:inherit; }",
    ".knot-source-wrapper { flex:1; min-width:0; width:100%; }",
    ".knot-path-field { display:flex; align-items:center; gap:6px; flex:1; }",
    ".knot-path-field input { min-width:280px; flex:1; }",
    ".knot-path-popover { display:flex; align-items:center; flex-wrap:wrap; gap:8px; width:560px; max-width:80vw; margin-top:4px; padding:10px; border:1px solid; border-radius:6px; box-sizing:border-box; }",
    ".knot-path-popover .knot-path-field { min-width:0; }",
    ".knot-path-popover .knot-path-field input { min-width:0; }",
    ".knot-reading { display:flex; flex-direction:column; gap:8px; padding:8px 12px; min-width:0; }",
    ".knot-reading-header { display:flex; align-items:center; gap:6px; min-width:0; padding-right:1px; box-sizing:border-box; }",
    ".knot-reading-title { font-weight:600; white-space:nowrap; }",
    ".knot-reading-separator { opacity:0.6; }",
    ".knot-reading-document { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }",
    ".knot-reading-pin { flex:none; }",
    ".knot-workspace > .status-bar { flex:none; gap:8px; margin:0 -20px; padding:4px 20px; min-height:28px; box-sizing:border-box; border-top:1px solid; font-size:13px; }",
    ".knot-workspace .status-chips { gap:6px; }",
    ".knot-workspace .status-chip { padding:2px 8px; }",
    ".knot-status-detail { display:flex; flex-direction:column; align-items:flex-start; gap:8px; min-width:260px; margin-bottom:4px; padding:10px; border:1px solid; border-radius:6px; }",
    ".knot-status-detail .detail-section-title { font-weight:600; }",
    ".knot-status-detail .detail-row { display:flex; gap:8px; }",
    ".knot-status-detail .detail-value { overflow-wrap:anywhere; }",
    ".knot-catalog-status { min-height:1.4em; overflow-wrap:anywhere; }",
    ".knot-catalog-error { color:crimson; display:flex; align-items:center; gap:8px; }",
    ".knot-review { padding:12px; border:1px solid; display:flex; flex-direction:column; gap:6px; }",
    ".knot-review-header { display:flex; flex-wrap:wrap; align-items:baseline; justify-content:space-between; gap:8px; }",
    ".knot-review-error { color:crimson; }",
    ".knot-review-source { max-height:240px; overflow:auto; white-space:pre-wrap; overflow-wrap:anywhere; user-select:text; }",
    ".knot-retention { padding:12px; border:1px solid; display:flex; flex-direction:column; gap:8px; }",
    ".knot-retention header { display:flex; flex-wrap:wrap; justify-content:space-between; gap:8px; }",
    ".knot-retention-targets { display:flex; flex-wrap:wrap; gap:6px; }",
    ".knot-retention-targets button { flex:1 1 180px; min-width:0; text-align:left; }",
    ".knot-retention-targets button[aria-pressed=true] { outline:2px solid currentColor; outline-offset:1px; }",
    ".knot-retention-selected { display:flex; flex-wrap:wrap; gap:4px 12px; padding:8px; border:1px solid; overflow-wrap:anywhere; }",
    ".knot-retention-selected span { min-width:0; }",
    ".knot-retention-error { color:crimson; }",
    ".knot-retention-receipt, .knot-retention-busy, .knot-retention-error, .knot-retention-targets button { overflow-wrap:anywhere; max-width:100%; }",
    ".knot-confirm { display:flex; align-items:center; gap:8px; padding:12px; border:1px solid; }",
    ".knot-confirm [id=knot-confirm-message] { margin-right:auto; }",
    ".knot-confirm-list { display:flex; flex-direction:column; gap:2px; }",
    "[id=knot-link-form] { flex:none; min-width:0; display:flex; flex-direction:column; align-items:stretch; max-height:240px; overflow:auto; }",
    "[id=knot-link-form] > div { display:flex; flex-wrap:wrap; gap:6px; }",
    "[id=knot-link-form] button { min-width:0; overflow-wrap:anywhere; }",
    ".knot-link-row { min-width:0; max-width:100%; display:flex; flex-direction:column; gap:6px; padding:6px 0; }",
    ".knot-link-description { min-width:0; max-width:100%; display:flex; flex-direction:column; gap:2px; }",
    ".knot-link-description span { display:block; min-width:0; max-width:100%; white-space:normal; overflow-wrap:anywhere; }",
    ".knot-link-label { font-weight:600; }",
    ".knot-link-kind { opacity:.8; }",
    ".knot-link-actions { min-width:0; display:flex; flex-wrap:wrap; gap:6px; }",
    ".knot-frame { position:relative; min-width:0; flex:1 1 0px; min-height:0; }",
    ".knot-graph { width:100%; height:100%; min-width:0; min-height:0; }",
    // Keep these exemptions inside the Graph tile. Extra overflow clips around
    // the positioned notice and self-clipping graph blank netrender's whole
    // native frame; ordinary Workbench content slots remain scrollable.
    ".knot-graph > .mere-view { max-width:100%; max-height:100%; overflow:visible; }",
    // Knot's workspace-wide button treatment must not turn Mere's transparent
    // graph hit targets into visible boxes over their node labels.
    ".knot-graph button.graph-canvas-swatch-node { padding:0; border:0; border-radius:0; background:transparent; color:inherit; }",
    ".knot-graph button.graph-canvas-swatch-node:hover { background:transparent; }",
    ".knot-frame .frisket-tabbar { flex:0 0 30px; height:30px; align-items:flex-end; gap:2px; padding:0 6px; border-bottom:1px solid; overflow:hidden; }",
    ".knot-frame .frisket-tab { flex:0 1 auto; max-width:240px; height:26px; margin-right:0; padding:0 6px 0 12px; gap:6px; font-size:13px; border:1px solid transparent; border-bottom:none; border-radius:6px 6px 0 0; }",
    ".knot-frame .frisket-tab.active { height:27px; margin-bottom:-1px; }",
    ".knot-frame .frisket-label { flex:0 1 auto; text-overflow:ellipsis; }",
    ".knot-frame .frisket-close { flex:0 0 18px; width:18px; height:auto; margin-left:0; padding:0; font-size:13px; visibility:hidden; }",
    ".knot-frame .frisket-tab.active .frisket-close, .knot-frame .frisket-tab:hover .frisket-close { visibility:visible; }",
    ".knot-frame .frisket-content { flex:1 1 0px; min-height:0; overflow:auto; padding:12px; }",
    ".knot-frame .frisket-divider { flex:0 0 1px; }",
    ".knot-frame .frisket-rail { padding:0; border-radius:0; box-sizing:border-box; overflow:hidden; }",
    ".knot-frame .frisket-panel-close { flex:none; max-width:100%; }",
    ".knot-frame .frisket-content[data-tile=\"18446744073709551615\"] { overflow:visible; padding:0; }",
    ".knot-empty-frame { display:block; padding:24px 0; }",
    ".knot-document-tile { display:flex; flex-direction:column; gap:12px; }",
    ".knot-writing-area { display:flex; align-items:flex-start; gap:12px; padding:16px; border:1px solid; box-sizing:border-box; }",
    ".knot-document { flex:1; min-width:0; }",
    ".knot-document-body textarea { display:block; width:100%; min-height:360px; line-height:1.5; box-sizing:border-box; }",
    ".knot-outline { display:flex; flex-direction:column; min-width:0; }",
    ".knot-outline-rows { display:flex; flex-direction:column; gap:2px; margin-top:8px; }",
    ".knot-outline-row { display:block; width:100%; text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }",
    ".knot-outline-row[data-outline-level=2] { padding-left:16px; }",
    ".knot-outline-row[data-outline-level=3] { padding-left:32px; }",
    ".knot-outline-row[data-outline-level=4] { padding-left:48px; }",
    ".knot-outline-row[data-outline-level=5] { padding-left:64px; }",
    ".knot-outline-row[data-outline-level=6] { padding-left:80px; }",
    ".knot-outline-error { color:crimson; }",
    ".knot-changes { display:flex; flex-direction:column; gap:12px; min-width:0; }",
    ".knot-comparison { padding:12px; border:1px solid; display:flex; flex-direction:column; align-items:flex-start; gap:6px; }",
    ".knot-comparison-header { display:flex; flex-wrap:wrap; gap:8px; align-items:baseline; }",
    ".knot-comparison-versions { display:flex; flex-wrap:wrap; gap:12px; }",
    ".knot-comparison-version { flex:1 1 360px; min-width:0; }",
    ".knot-comparison-version pre { max-height:240px; overflow:auto; white-space:pre-wrap; overflow-wrap:anywhere; user-select:text; }",
    "@media (max-width:700px) { .knot-workspace { padding:12px 12px 0; } .knot-workspace > .status-bar { margin:0 -12px; padding:4px 12px; } .knot-path-field input { min-width:160px; } .knot-writing-area { flex-direction:column; align-items:stretch; } }",
    "@media (max-height:320px) { .knot-workspace { gap:4px; padding-top:4px; } .knot-workspace-toolbar { flex:none; } .knot-workspace > .status-bar { padding-top:2px; padding-bottom:2px; min-height:24px; } .knot-frame .frisket-content { padding-top:4px; padding-bottom:4px; } .knot-writing-area { padding-top:4px; padding-bottom:4px; } .knot-appearance-panel { padding:4px; max-height:20vh; } .knot-workspace > [id=knot-link-form], .knot-confirm { max-height:25vh; overflow:auto; min-height:0; flex:none; } }",
);

#[cfg(test)]
mod tests {
    use super::*;
    use cambium::TextCommand;
    use cambium_genet_winit_host::{Harness, Init, KeyPress, Modifiers, NamedKey, inert_hooks};
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Arc, Mutex, mpsc};
    use taproot::Selector;
    use tempfile::tempdir;

    #[test]
    fn short_zoomed_viewport_keeps_source_status_and_drawer_inside_the_window() {
        let assert_chrome = |host: &DesktopHarness| {
            assert_eq!(host.viewport_scroll(), (0.0, 0.0), "workspace must not scroll");
            for class in ["knot-workspace-toolbar", "status-bar"] {
                let nodes = host.with_dom(|dom| dom.all_with_class(dom.document(), class));
                let (x, y, w, h) = host.painted_rect(nodes[0]).unwrap();
                assert!(
                    x >= -0.5 && x + w <= 320.5 && y >= -0.5 && y + h <= 175.5,
                    "{class} outside viewport: ({x},{y},{w},{h})"
                );
            }
        };
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Field notes on the estuary\n\nA source line remains readable with the Appearance disclosure open.",
        ));
        host.update(|state| state.toggle_reading(ReadingKind::Preview));
        host.layout_at(4000.0, 700.0);
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        let before = host.state().document().snapshot();
        let canonical = host.state().docs.workspace().tiled().clone();
        host.set_ui_zoom(4.0);
        host.layout_at(1280.0, 700.0);
        for appearance_open in [false, true, false] {
            host.update(|state| state.appearance_open = appearance_open);
            for _ in 0..4 {
                host.prepare_frame();
                host.relayout();
            }
            let status = host.with_dom(|dom| dom.all_with_class(dom.document(), "status-bar"));
            let (x, y, w, h) = host.painted_rect(status[0]).unwrap();
            assert!(
                x >= -0.5 && x + w <= 320.5 && y >= -0.5 && y + h <= 175.5,
                "status outside viewport with Appearance={appearance_open}: ({x},{y},{w},{h})"
            );
            let source = host.with_dom(|dom| {
                taproot::matching(
                    dom,
                    &Selector::role("textbox").with_attr("aria-label", "Document text"),
                )
            });
            let (_, y, w, h) = host.visible_rect(source[0]).unwrap();
            assert!(
                y >= 0.0 && y + h <= 175.5 && w > 100.0 && h >= 24.0,
                "source unreadable with Appearance={appearance_open}: ({y},{w},{h})"
            );
        }
        let reading = host
            .state()
            .presentation
            .stacks
            .iter()
            .find(|stack| {
                stack.collapsed.as_ref().is_some_and(|collapsed| {
                    collapsed.label == "Readings" && collapsed.drawer.is_some()
                })
            })
            .expect("collapsed reading drawer")
            .anchor;
        assert!(
            host.click_on(&Selector::role("button").with_attr("data-rail", reading.0.to_string()))
        );
        host.after_dispatch();
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        let panels =
            host.with_dom(|dom| dom.all_with_class(dom.document(), "overlay-surface-panel"));
        assert_eq!(panels.len(), 1);
        let (x, y, w, h) = host.painted_rect(panels[0]).unwrap();
        assert!(
            x >= -0.5 && x + w <= 320.5 && y >= -0.5 && y + h <= 175.5 && h >= 24.0,
            "drawer outside viewport: ({x},{y},{w},{h})"
        );
        assert_eq!(host.state().document().snapshot(), before);
        assert_eq!(host.state().docs.workspace().tiled(), &canonical);
        let heading = Selector::role("button")
            .with_attr("aria-label", "Select source heading: Field notes on the estuary");
        let scroll_before = host.element_scroll_total();
        assert!(host.click_on(&heading), "preview heading must be reachable");
        host.after_dispatch();
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        let heading_nodes = host.with_dom(|dom| taproot::matching(dom, &heading));
        let (x, y, w, h) = host.visible_rect(heading_nodes[0]).expect("visible preview heading");
        assert!(
            x >= 0.0 && x + w <= 320.5 && y >= 0.0 && y + h <= 175.5 && h >= 24.0,
            "preview heading unreadable after scrolling: ({x},{y},{w},{h})"
        );
        assert!(host.element_scroll_total() > scroll_before);
        assert_chrome(&host);
        assert_eq!(host.state().document().snapshot().text, before.text);
        assert_eq!(host.state().docs.workspace().tiled(), &canonical);
        let selected = host.state().document().snapshot();
        assert!(host.click_on(
            &Selector::role("button").with_attr("class", "frisket-panel-close")
        ));
        host.after_dispatch();
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        host.press_key(&KeyPress::named(NamedKey::Escape));
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        assert!(host.state().presentation.stacks.iter().all(|stack| {
            !stack.collapsed.as_ref().is_some_and(|collapsed| collapsed.open)
        }));
        assert!(source_is_focused(host.runner()));
        assert_chrome(&host);
        let source = host.with_dom(|dom| {
            taproot::matching(
                dom,
                &Selector::role("textbox").with_attr("aria-label", "Document text"),
            )
        });
        let (_, y, w, h) = host.visible_rect(source[0]).unwrap();
        assert!(y >= 0.0 && y + h <= 175.5 && w > 100.0 && h >= 24.0);
        assert!(host.element_scroll_total() > 0.0, "nested source scroll is retained");
        assert_eq!(host.state().document().snapshot(), selected);
    }

    #[test]
    fn drawer_escape_from_retained_scenario_dispatch_restores_source_during_frame() {
        let mut hooks = crate::host_hooks();
        hooks.after_frame = Box::new(|ctx| {
            // Mesquite's key verb dispatches to the retained runner after a
            // frame; unlike physical host input it does not run after_dispatch.
            ctx.runner
                .dispatch_key(cambium::KeyEvent::new(cambium::Key::Named(
                    cambium::NamedKey::Escape,
                )));
        });
        let mut host = Harness::with_hooks(
            Init {
                state: DesktopState::new(
                    KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# Source\n\noriginal source"),
                    WindowCommands::new(),
                ),
                logic: desktop_view as fn(&DesktopState) -> DesktopView,
                sheet: crate::desktop_sheet(),
                fonts: crate::fonts::bundled_fonts(),
                images: Vec::new(),
            },
            hooks,
        );
        host.update(|state| state.toggle_reading(ReadingKind::Preview));
        host.layout_at(320.0, 700.0);
        for _ in 0..4 {
            host.prepare_frame();
            host.relayout();
        }
        assert_eq!(
            host.state()
                .presentation
                .stacks
                .iter()
                .filter_map(|stack| stack.collapsed.as_ref())
                .filter(|collapsed| collapsed.open && collapsed.drawer.is_some())
                .count(),
            1
        );
        let before = host.state().document().snapshot();
        let canonical = host.state().docs.workspace().tiled().clone();
        host.after_frame();
        assert!(host.state().entry().focus_source_requested);
        host.relayout();
        host.prepare_frame();
        host.relayout();
        assert!(source_is_focused(host.runner()));
        assert!(!host.state().entry().focus_source_requested);
        assert_eq!(host.state().document().snapshot(), before);
        assert_eq!(host.state().docs.workspace().tiled(), &canonical);
    }

    #[test]
    fn document_link_menu_keeps_selection_and_cancel_escape_restore_source_focus() {
        let temp = tempdir().unwrap();
        let source_path = temp.path().join("source.djot");
        let target_path = temp.path().join("target.djot");
        std::fs::write(&source_path, "α 日本語 tail\n").unwrap();
        std::fs::write(&target_path, "# Target\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&source_path).unwrap());
        let source = host.state().focused_key().unwrap();
        host.update(|state| {
            state.set_command_chrome(CommandChrome::ClientTitlebar);
            state.open_path(target_path.clone());
            state.focus_document(source);
        });
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("textbox").with_attr("aria-label", "Document text")));
        host.update(|state| {
            let snapshot = state.document().snapshot();
            state
                .document_mut()
                .session_mut()
                .select_source_span(
                    &snapshot.source.address,
                    &snapshot.text,
                    "α ".len(),
                    "α 日本語".len(),
                )
                .unwrap();
        });
        let selection = host.state().document().snapshot().selection;
        for cancel in [true, false] {
            host.press_key(&KeyPress::named(NamedKey::F10));
            assert!(
                host.click_on(&Selector::role("menuitem").with_attr("data-key", "group.document"))
            );
            assert!(host.click_on(
                &Selector::role("menuitem").with_attr("data-key", commands::LINK_DOCUMENT)
            ));
            assert!(host.state().link_form.is_some());
            assert!(focus_inside(&host, "knot-link-form"));
            if cancel {
                assert!(
                    host.click_on(&Selector::role("button").with_attr("id", "knot-link-cancel"))
                );
            } else {
                host.press_key(&KeyPress::named(NamedKey::Escape));
            }
            assert!(host.state().link_form.is_none());
            assert!(source_is_focused(host.runner()));
            assert_eq!(host.state().document().snapshot().selection, selection);
        }
        host.update(crate::link_workflow::begin);
        host.after_dispatch();
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").with_attr("data-link-target", "0")));
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-link-insert")));
        assert_eq!(
            host.state().document().snapshot().text,
            "α [日本語](./target.djot) tail\n"
        );
        assert!(source_is_focused(host.runner()));
    }

    #[test]
    fn links_reading_derives_dirty_open_document_backlinks_and_selects_the_owner() {
        let temp = tempdir().unwrap();
        let source_path = temp.path().join("source.djot");
        let target_path = temp.path().join("target.djot");
        std::fs::write(&source_path, "[日本語](./target.djot)\n").unwrap();
        std::fs::write(&target_path, "# Target\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&source_path).unwrap());
        let source = host.state().focused_key().unwrap();
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "dirty ".into(),
                )))
                .unwrap();
            state.open_path(target_path.clone());
            state.toggle_reading(ReadingKind::Links);
        });
        host.layout_at(1100.0, 700.0);
        let target = host.state().focused_key().unwrap();
        assert_ne!(source, target);
        let content = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let reading = class_node(&dom, dom.document(), "knot-readings").unwrap();
            text_content(&dom, reading)
        };
        assert!(content.contains("currently open saved documents only"));
        assert!(content.contains("source.djot · unsaved buffer · 日本語"));
        assert!(host.click_on(
            &Selector::role("button").containing("source.djot · unsaved buffer · 日本語")
        ));
        assert_eq!(host.state().focused_key(), Some(source));
        assert!(source_is_focused(host.runner()));
        let snapshot = host.state().document().snapshot();
        let span = crate::document_links::parsed_links(host.state().document().session()).unwrap()
            [0]
        .span
        .unwrap();
        assert_eq!(
            (
                snapshot.selection.anchor.byte,
                snapshot.selection.focus.byte
            ),
            span
        );
    }

    #[test]
    fn links_reading_wraps_descriptions_above_actions_and_preserves_exact_accessible_target() {
        let temp = tempdir().unwrap();
        let source_path = temp.path().join("source.djot");
        let target_path = temp
            .path()
            .join(format!("{}.djot", "Target 日本語 notes ".repeat(3)));
        std::fs::write(&target_path, "# Target\n").unwrap();
        let relationship = &crate::document_links::RELATIONSHIPS[0];
        let markup = crate::document_links::markup(
            &source_path,
            &target_path,
            "Selected source",
            "Target",
            Some(relationship.slug),
        )
        .unwrap();
        let exact_target = crate::document_links::relative_url(&source_path, &target_path).unwrap();
        std::fs::write(&source_path, &markup).unwrap();
        let mut host = harness(KnotDocumentSession::open(&source_path).unwrap());
        host.update(|state| state.toggle_reading(ReadingKind::Links));
        host.layout_at(900.0, 640.0);
        let (description, actions, reading) = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let description = class_node(&dom, dom.document(), "knot-link-description").unwrap();
            let actions = class_node(&dom, dom.document(), "knot-link-actions").unwrap();
            let reading = class_node(&dom, dom.document(), "knot-reading").unwrap();
            let visible = text_content(&dom, description);
            assert!(visible.contains("Target 日本語 notes"));
            assert!(visible.contains("cites · local document"));
            assert!(!visible.contains("%E6"));
            assert!(!visible.contains(relationship.iri));
            let accessible = LayoutDom::attribute(
                &*dom,
                description,
                &Namespace::from(""),
                &LocalName::from("aria-label"),
            )
            .unwrap();
            assert!(accessible.contains(&exact_target));
            assert!(accessible.contains(relationship.iri));
            (description, actions, reading)
        };
        let (x, y, width, height) = host.painted_rect(description).unwrap();
        let (action_x, action_y, action_width, _) = host.painted_rect(actions).unwrap();
        let (reading_x, _, reading_width, _) = host.painted_rect(reading).unwrap();
        assert!(
            action_y >= y + height - 1.0,
            "Actions are below the wrapped description"
        );
        assert!(x >= reading_x && x + width <= reading_x + reading_width + 1.0);
        assert!(
            action_x >= reading_x && action_x + action_width <= reading_x + reading_width + 1.0
        );
    }

    fn harness(
        session: KnotDocumentSession,
    ) -> Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView> {
        harness_with_catalog(session, None)
    }

    fn harness_with_catalog(
        session: KnotDocumentSession,
        catalog: Option<KnotFileCatalog>,
    ) -> Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView> {
        let mut state = DesktopState::with_catalog(session, WindowCommands::new(), None, catalog);
        // These legacy toolbar fixtures exercise the supported plain command row.
        state.set_command_chrome(CommandChrome::PlainRow);
        let mut host = Harness::with_hooks(
            Init {
                state,
                logic: desktop_view as fn(&DesktopState) -> DesktopView,
                sheet: crate::desktop_sheet(),
                fonts: crate::fonts::bundled_fonts(),
                images: Vec::new(),
            },
            {
                let mut hooks = inert_hooks();
                hooks.frame = Box::new(graph_frame);
                hooks.after_dispatch = Box::new(after_dispatch);
                hooks.after_wake = Box::new(after_wake);
                hooks.close_request = Box::new(|ctx, request| close_request(ctx.runner, request));
                hooks.focused_text = Box::new(focused_text);
                hooks.key_intercept = Box::new(key_intercept);
                hooks
            },
        );
        let commands = host.commands();
        let wake = host.wake();
        host.update(|state| {
            state.window = commands.clone();
            state.graph.set_wake(wake.clone());
            state.refresh_graph();
        });
        host
    }

    #[test]
    fn only_the_graph_host_and_shared_view_are_exempt_from_extra_clips() {
        assert!(
            DESKTOP_CSS
                .contains(".knot-graph { width:100%; height:100%; min-width:0; min-height:0; }")
        );
        assert!(!DESKTOP_CSS.contains(
            ".knot-graph { width:100%; height:100%; min-width:0; min-height:0; overflow:"
        ));
        assert!(DESKTOP_CSS.contains(
            ".knot-graph > .mere-view { max-width:100%; max-height:100%; overflow:visible; }"
        ));
        assert!(DESKTOP_CSS.contains(
            ".knot-graph button.graph-canvas-swatch-node { padding:0; border:0; border-radius:0; background:transparent; color:inherit; }"
        ));
        assert!(DESKTOP_CSS.contains(
            ".knot-graph button.graph-canvas-swatch-node:hover { background:transparent; }"
        ));
        assert!(DESKTOP_CSS.contains(
            ".knot-frame .frisket-content { flex:1 1 0px; min-height:0; overflow:auto; padding:12px; }"
        ));
        assert!(DESKTOP_CSS.contains(
            ".knot-frame .frisket-content[data-tile=\"18446744073709551615\"] { overflow:visible; padding:0; }"
        ));
        assert!(!DESKTOP_CSS.contains(".knot-frame .mere-view {"));
    }

    #[test]
    fn last_document_closes_onto_the_shared_mere_view_and_graph_command_is_singleton() {
        let mut host = harness(KnotDocumentSession::scratch("scratch:graph", "# Graph"));
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Graph")));
        assert!(host.state().docs.graph().is_some());
        assert!(
            host.resolve(&Selector::role("region").with_attr("aria-label", "Mere: Knot graph"))
                .is_some()
        );
        assert!(host.click_on(&Selector::role("button").containing("Hide Graph")));
        assert!(host.state().docs.graph().is_none());

        let key = host.state().focused_key().unwrap();
        host.update(|state| state.close_document(key));
        host.relayout();
        let graph = Selector::role("region").with_attr("aria-label", "Mere: Knot graph");
        assert!(host.resolve(&graph).is_some());
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let graph_root = class_node(&dom, dom.document(), "knot-graph").expect("the graph root");
        let mut ancestor = dom.parent(graph_root);
        let mut graph_content = None;
        while let Some(node) = ancestor {
            if dom.has_class(node, "frisket-content") {
                graph_content = Some(node);
                break;
            }
            ancestor = dom.parent(node);
        }
        let graph_content = graph_content.expect("Graph belongs to a Workbench content slot");
        assert_eq!(
            dom.attribute(
                graph_content,
                &Namespace::from(""),
                &LocalName::from("data-tile")
            )
            .as_deref(),
            Some(crate::documents::GRAPH_TILE_ID_ATTR)
        );
        assert!(text_content(&*dom, dom.document()).contains("No catalog is configured"));
        drop(dom);
        assert!(host.click_on(&Selector::role("button").with_attr("data-action", "new")));
        assert_eq!(host.state().docs.len(), 1);
    }

    #[test]
    fn last_close_replaces_only_the_document_and_new_preserves_every_surviving_tile() {
        let mut state = DesktopState::new(
            KnotDocumentSession::scratch("scratch:workspace-graph", "# Graph"),
            WindowCommands::new(),
        );
        state.toggle_navigator();
        state.toggle_reading(ReadingKind::Preview);
        let site = SiteKey(77);
        let site_tile = state.docs.open_site_tile(site, "Site");
        let navigator = state.docs.navigator().unwrap();
        let reading = state.docs.following_reading(ReadingKind::Preview).unwrap();
        let document = state.focused_key().unwrap();

        state.close_document(document);
        assert!(state.docs.is_empty());
        let graph = state.docs.graph().expect("last document became Graph");
        for tile in [navigator, reading, site_tile, graph] {
            assert!(state.docs.workspace().tiled().find(tile).is_some());
        }

        // Explicitly closing the centre placeholder must not make New join
        // either surviving side stack.
        state.docs.close(graph);
        assert!(state.docs.graph().is_none());
        for tile in [navigator, reading, site_tile] {
            assert!(state.docs.workspace().tiled().find(tile).is_some());
        }

        state.new_document();
        let document = state.docs.tile_of(state.focused_key().unwrap()).unwrap();
        for tile in [navigator, reading, site_tile, document] {
            assert!(state.docs.workspace().tiled().find(tile).is_some());
        }
        let mut stacks = Vec::new();
        fn collect_stacks(tree: &workbench::TileTree, out: &mut Vec<Vec<workbench::TileId>>) {
            match tree {
                workbench::TileTree::Stack(stack) => {
                    out.push(stack.tabs.iter().map(|tile| tile.id).collect())
                },
                workbench::TileTree::Split { children, .. } => {
                    for child in children {
                        collect_stacks(&child.tree, out);
                    }
                },
            }
        }
        collect_stacks(state.docs.workspace().tiled(), &mut stacks);
        assert_eq!(
            stacks,
            [vec![navigator, site_tile], vec![document], vec![reading]]
        );
        assert_eq!(state.docs.navigator(), Some(navigator));
        assert_eq!(state.docs.site_tile(site), Some(site_tile));
        assert_eq!(
            state.docs.following_reading(ReadingKind::Preview),
            Some(reading)
        );

        state.toggle_graph();
        assert!(state.docs.graph().is_some());
        state.toggle_graph();
        assert!(state.docs.graph().is_none());
        state.toggle_navigator();
        assert!(state.docs.navigator().is_none());
        state.toggle_navigator();
        assert!(state.docs.navigator().is_some());
        state.toggle_reading(ReadingKind::Preview);
        assert!(state.docs.following_reading(ReadingKind::Preview).is_none());
        state.toggle_reading(ReadingKind::Preview);
        assert!(state.docs.following_reading(ReadingKind::Preview).is_some());
        assert_eq!(state.docs.site_tile(site), Some(site_tile));
    }

    #[test]
    fn graph_layout_request_is_host_owned() {
        let mut host = harness(KnotDocumentSession::scratch("scratch:graph", ""));
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Graph")));
        assert!(host.click_on(&Selector::role("button").with_attr("data-layout", "grid.default")));
        assert_eq!(host.state().graph.layout, "grid.default");
    }

    #[test]
    fn catalog_graph_worker_labels_its_reading_and_activation_opens_the_document() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let a_path = root.join("a.djot");
        let b_path = root.join("b.djot");
        std::fs::write(&a_path, "[B](b.djot)").unwrap();
        std::fs::write(&b_path, "# B").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let a = catalog.bind(&a_path).unwrap();
        let b = catalog.bind(&b_path).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&a_path).unwrap(), Some(catalog));
        drain_wake(&mut host);
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Graph")));
        host.relayout();
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let all = text_content(&*dom, dom.document());
        assert!(all.contains("Catalog reading "), "{all}");
        drop(dom);
        let activate = b.clone();
        host.update(|state| {
            state.carry_graph_request(mere_view::MereViewRequest::Activate(activate.clone()))
        });
        assert_eq!(host.state().docs.len(), 2);
        assert_eq!(host.state().entry().catalog_id.as_deref(), Some(b.as_str()));
        assert_ne!(a, b);
    }

    #[test]
    fn actual_save_flows_through_catalog_worker_acceptance_and_redacted_owner_facts() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("files");
        std::fs::create_dir(&root).unwrap();
        let path = root.join("private-source.djot");
        std::fs::write(&path, "# Private title\n").unwrap();
        std::fs::write(root.join("private-destination.djot"), "# B\n").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        catalog.bind(&path).unwrap();
        catalog.bind("private-destination.djot").unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&path).unwrap(), Some(catalog));
        host.update(|state| state.set_command_chrome(CommandChrome::ClientTitlebar));
        drain_wake(&mut host);
        host.update(|state| {
            state.graph.enable_test_diagnostics();
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("[B](private-destination.djot)\n");
        });
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Save")));
        host.after_dispatch();
        drain_wake(&mut host);
        assert!(!host.state().document().snapshot().dirty);
        assert!(
            std::fs::read_to_string(&path)
                .unwrap()
                .contains("private-destination.djot")
        );
        let facts = host.state().graph_capture_facts().unwrap();
        let installed = facts.installed.unwrap();
        assert_eq!(facts.catalog_relations, 1);
        assert_eq!(facts.read_errors, 0);
        let batch = host.state().graph_diagnostic_attachment().unwrap().unwrap();
        let phases = [
            "save_dispatched",
            "file_write_returned",
            "catalog_requested",
            "worker_started",
            "worker_completed",
            "accepted",
        ];
        let records = phases.map(|phase| {
            batch
                .records
                .iter()
                .find(|record| record.payload["phase"] == phase)
                .unwrap()
        });
        for pair in records.windows(2) {
            assert_eq!(
                pair[1].envelope.metadata.cause.as_ref(),
                Some(&pair[0].envelope.reference)
            );
        }
        assert_eq!(
            installed.request.as_ref(),
            Some(&records[2].envelope.reference)
        );
        assert_eq!(
            installed.outcome.as_ref(),
            Some(&records[4].envelope.reference)
        );
        assert_eq!(
            installed.acceptance.as_ref(),
            Some(&records[5].envelope.reference)
        );
        assert!(!serde_json::to_string(&facts).unwrap().contains("private"));
        assert!(!serde_json::to_string(&batch).unwrap().contains("private"));
    }

    #[test]
    fn failed_actual_save_records_refusal_without_dispatching_a_catalog_worker() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("files");
        std::fs::create_dir(&root).unwrap();
        let path = root.join("private-source.djot");
        std::fs::write(&path, "# A\n").unwrap();
        let catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&path).unwrap(), Some(catalog));
        host.update(|state| state.set_command_chrome(CommandChrome::ClientTitlebar));
        drain_wake(&mut host);
        host.update(|state| {
            state.graph.enable_test_diagnostics();
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("changed");
        });
        // A real filesystem refusal, after the document was opened successfully.
        std::fs::remove_file(&path).unwrap();
        std::fs::create_dir(&path).unwrap();
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Save")));
        host.after_dispatch();
        assert!(path.is_dir());
        assert!(host.state().document().snapshot().dirty);
        assert!(!host.state().graph.busy());
        let batch = host.state().graph_diagnostic_attachment().unwrap().unwrap();
        assert_eq!(batch.records.len(), 2);
        assert_eq!(batch.records[0].payload["phase"], "save_dispatched");
        assert_eq!(batch.records[1].payload["phase"], "file_write_returned");
        assert_eq!(batch.records[1].payload["result"], "write_failed");
        assert_eq!(
            batch.records[1].envelope.metadata.cause.as_ref(),
            Some(&batch.records[0].envelope.reference)
        );
        assert!(!serde_json::to_string(&batch).unwrap().contains("private"));
    }

    #[cfg(unix)]
    #[test]
    fn graph_activation_refuses_a_bound_path_replaced_by_an_out_of_root_symlink() {
        use std::os::unix::fs::symlink;

        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let open_path = root.join("open.djot");
        let target_path = root.join("target.djot");
        let outside = temp.path().join("outside.djot");
        std::fs::write(&open_path, "# Open").unwrap();
        std::fs::write(&target_path, "# Authorized once").unwrap();
        std::fs::write(&outside, "# Outside").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        catalog.bind(&open_path).unwrap();
        let target = catalog.bind(&target_path).unwrap();
        let mut host = harness_with_catalog(
            KnotDocumentSession::open(&open_path).unwrap(),
            Some(catalog),
        );
        std::fs::remove_file(&target_path).unwrap();
        symlink(&outside, &target_path).unwrap();

        let activate = target.clone();
        host.update(|state| {
            state.carry_graph_request(mere_view::MereViewRequest::Activate(activate.clone()))
        });
        assert_eq!(host.state().docs.len(), 1);
        assert_eq!(
            host.state()
                .document()
                .session()
                .source_path()
                .and_then(|path| std::fs::canonicalize(path).ok()),
            Some(std::fs::canonicalize(&open_path).unwrap())
        );
        assert!(
            host.state()
                .graph
                .notice
                .as_deref()
                .unwrap()
                .contains("unavailable or no longer authorized")
        );
    }

    #[test]
    fn every_launch_document_merges_with_its_catalog_node() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let first = root.join("first.djot");
        let second = root.join("second.djot");
        std::fs::write(&first, "# First").unwrap();
        std::fs::write(&second, "# Second").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let first_id = catalog.bind(&first).unwrap();
        let second_id = catalog.bind(&second).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&first).unwrap(), Some(catalog));
        host.update(|state| {
            state.open_behind(vec![KnotDocumentSession::open(&second).unwrap()], &[])
        });
        drain_wake(&mut host);
        let open = host.state().graph_open_nodes();
        let model = host.state().graph.model(&open);
        assert_eq!(model.graph.nodes.len(), 2);
        assert!(
            model
                .graph
                .nodes
                .iter()
                .all(|node| node.state == mere_view::NodeState::Open)
        );
        assert!(
            model
                .graph
                .nodes
                .iter()
                .all(|node| !node.key.starts_with("open:"))
        );
        assert!(model.graph.nodes.iter().any(|node| node.key == first_id));
        assert!(model.graph.nodes.iter().any(|node| node.key == second_id));
    }

    #[test]
    fn duplicate_catalog_path_in_one_launch_reuses_one_tab_and_graph_node() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let path = root.join("same.djot");
        std::fs::write(&path, "# Same").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let id = catalog.bind(&path).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&path).unwrap(), Some(catalog));

        host.update(|state| {
            state.open_behind(
                vec![
                    KnotDocumentSession::open(&path).unwrap(),
                    KnotDocumentSession::open(&path).unwrap(),
                ],
                &[],
            )
        });
        drain_wake(&mut host);

        assert_eq!(host.state().docs.len(), 1);
        assert_eq!(
            host.state()
                .docs
                .workspace()
                .tiled()
                .tiles()
                .iter()
                .filter(|tile| {
                    matches!(host.state().docs.role(tile.id), Some(TileRole::Document(_)))
                })
                .count(),
            1
        );
        assert_eq!(
            host.state()
                .docs
                .identity(host.state().focused_key().unwrap()),
            Some(&DocIdentity::Catalog(id.clone()))
        );
        let model = host.state().graph.model(&host.state().graph_open_nodes());
        assert_eq!(
            model
                .graph
                .nodes
                .iter()
                .filter(|node| node.key == id)
                .count(),
            1
        );
        assert!(
            model
                .graph
                .nodes
                .iter()
                .find(|node| node.key == id)
                .is_some_and(|node| node.state == mere_view::NodeState::Open)
        );
    }

    fn graph_reading_label(state: &DesktopState) -> String {
        state
            .graph
            .model(&state.graph_open_nodes())
            .notice
            .as_deref()
            .and_then(|notice| notice.strip_prefix("Catalog reading "))
            .and_then(|notice| notice.split('.').next())
            .expect("catalog reading label")
            .to_owned()
    }

    #[test]
    fn dirty_close_save_refreshes_catalog_links_before_the_document_leaves() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let a_path = root.join("a.djot");
        let b_path = root.join("b.djot");
        let c_path = root.join("c.djot");
        std::fs::write(&a_path, "[B](b.djot)").unwrap();
        std::fs::write(&b_path, "# B").unwrap();
        std::fs::write(&c_path, "# C").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let a = catalog.bind(&a_path).unwrap();
        let b = catalog.bind(&b_path).unwrap();
        let c = catalog.bind(&c_path).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&a_path).unwrap(), Some(catalog));
        drain_wake(&mut host);
        host.layout_at(1100.0, 700.0);
        let before = graph_reading_label(host.state());
        let key = host.state().focused_key().unwrap();
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::SelectAll))
                .unwrap();
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "[C](c.djot)".to_owned(),
                )))
                .unwrap();
        });
        assert!(close_tab(&mut host, "a.djot"));
        assert_eq!(
            host.state().pending,
            Some(PendingAction::CloseDocument(key))
        );
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(host.state().pending.is_none());
        assert!(host.state().docs.is_empty());
        assert!(host.state().docs.graph().is_some());
        drain_wake(&mut host);
        let model = host.state().graph.model(&host.state().graph_open_nodes());
        assert_ne!(graph_reading_label(host.state()), before);
        assert!(
            model
                .graph
                .relations
                .iter()
                .any(|edge| edge.from == a && edge.to == c)
        );
        assert!(
            !model
                .graph
                .relations
                .iter()
                .any(|edge| edge.from == a && edge.to == b)
        );
    }

    #[test]
    fn save_as_over_bound_path_refreshes_graph_digest_and_edges() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("root");
        std::fs::create_dir(&root).unwrap();
        let a_path = root.join("a.djot");
        let b_path = root.join("b.djot");
        let c_path = root.join("c.djot");
        std::fs::write(&a_path, "[B](b.djot)").unwrap();
        std::fs::write(&b_path, "# B").unwrap();
        std::fs::write(&c_path, "# C").unwrap();
        let mut catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let a = catalog.bind(&a_path).unwrap();
        catalog.bind(&b_path).unwrap();
        let c = catalog.bind(&c_path).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&a_path).unwrap(), Some(catalog));
        drain_wake(&mut host);
        let before = graph_reading_label(host.state());
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::SelectAll))
                .unwrap();
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "[C](c.djot)".to_owned(),
                )))
                .unwrap();
            state.save_as_path = TextInput::new(a_path.to_string_lossy());
            assert!(state.save_as());
        });
        drain_wake(&mut host);
        let model = host.state().graph.model(&host.state().graph_open_nodes());
        assert_ne!(graph_reading_label(host.state()), before);
        assert!(
            model
                .graph
                .relations
                .iter()
                .any(|edge| edge.from == a && edge.to == c)
        );
        assert_eq!(host.state().entry().catalog_id.as_deref(), Some(a.as_str()));
        assert_eq!(
            host.state()
                .docs
                .identity(host.state().focused_key().unwrap()),
            Some(&DocIdentity::Catalog(a))
        );
    }

    fn input_node(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
    ) -> Option<genet_scripted_dom::NodeId> {
        if dom
            .element_name(node)
            .is_some_and(|name| name.local.as_ref() == "input")
        {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| input_node(dom, child))
    }

    fn named_node(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
        name: &str,
    ) -> Option<genet_scripted_dom::NodeId> {
        if dom
            .element_name(node)
            .is_some_and(|element| element.local.as_ref() == name)
        {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| named_node(dom, child, name))
    }

    fn attr_node(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
        name: &str,
        expected: &str,
    ) -> Option<genet_scripted_dom::NodeId> {
        let namespace = Namespace::from("");
        let local = LocalName::from(name);
        if dom.attribute(node, &namespace, &local).as_deref() == Some(expected) {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| attr_node(dom, child, name, expected))
    }

    fn class_node(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
        class: &str,
    ) -> Option<genet_scripted_dom::NodeId> {
        if dom.has_class(node, class) {
            return Some(node);
        }
        dom.dom_children(node)
            .find_map(|child| class_node(dom, child, class))
    }

    /// D1: the editor paints the width of the column its tile gives it, not
    /// the window's.
    #[test]
    fn the_editor_fills_its_column_and_no_more() {
        for width in [1100.0, 640.0] {
            let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# Notes\n"));
            host.layout_at(width, 700.0);
            let (body, editor) = {
                let dom = host.runner().dom();
                let dom = dom.borrow();
                let body = class_node(&dom, dom.document(), "knot-document-body")
                    .expect("the document body");
                (
                    body,
                    named_node(&dom, body, "textarea").expect("the editor"),
                )
            };
            let (column_x, _, column_width, _) = host.painted_rect(body).expect("column layout");
            let (x, _, editor_width, _) = host.painted_rect(editor).expect("editor layout");
            assert!(
                (x - column_x).abs() <= 1.0 && (editor_width - column_width).abs() <= 1.0,
                "at {width}px the editor paints {x} + {editor_width} in a {column_x} + {column_width} column",
            );
        }
    }

    /// A short reading beside a long document still fills its stack, so the
    /// tile's surface does not stop where its content does.
    #[test]
    fn a_short_reading_tile_fills_its_stack() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Notes\n\nA line.\n",
        ));
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        let stacks = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let mut stacks = Vec::new();
            let mut pending = vec![dom.document()];
            while let Some(node) = pending.pop() {
                if dom.has_class(node, "frisket-stack") {
                    let bar = class_node(&dom, node, "frisket-tabbar").expect("a tab bar");
                    let content = class_node(&dom, node, "frisket-content").expect("content");
                    stacks.push((node, bar, content));
                }
                pending.extend(dom.dom_children(node));
            }
            stacks
        };
        assert_eq!(stacks.len(), 2, "the document stack and the reading stack");
        for (stack, bar, content) in stacks {
            let (_, _, _, stack_height) = host.painted_rect(stack).expect("stack layout");
            let (_, _, _, bar_height) = host.painted_rect(bar).expect("bar layout");
            let (_, _, _, content_height) = host.painted_rect(content).expect("content layout");
            assert!(
                (bar_height + content_height - stack_height).abs() <= 1.0,
                "a {stack_height}px stack holds a {bar_height}px bar and {content_height}px of content",
            );
        }
    }

    /// Step 5: a tile taller than its stack scrolls inside it, and the tile
    /// beside it and the window stay put.
    #[test]
    fn a_tall_tile_scrolls_inside_its_stack_and_the_tile_beside_it_stays() {
        let source = format!("# Notes\n\n{}", "A line of field notes.\n".repeat(120));
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, &source));
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        let (document, beside) = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let tile = |class: &str| {
                let mut node = class_node(&dom, dom.document(), class);
                while let Some(current) = node {
                    if dom.has_class(current, "frisket-content") {
                        return current;
                    }
                    node = dom.parent(current);
                }
                panic!("{class} sits in a tile")
            };
            (tile("knot-document-body"), tile("knot-outline"))
        };
        let (x, y, width, height) = host.painted_rect(document).expect("the document's tile");
        let beside_rect = host.painted_rect(beside);
        host.move_to(x + width / 2.0, y + height / 2.0);
        host.wheel(0.0, 300.0);
        assert!(
            host.element_scroll(document).1 > 0.0,
            "the document's tile scrolled"
        );
        assert_eq!(
            host.element_scroll(beside),
            (0.0, 0.0),
            "the tile beside it did not"
        );
        assert_eq!(host.painted_rect(beside), beside_rect, "nor did it move");
        assert_eq!(host.viewport_scroll(), (0.0, 0.0), "the window stayed");
    }

    /// Open a status chip's popover by clicking the chip itself, and check
    /// that it opened, so what a test then reads or misses is really there.
    fn open_chip(host: &mut DesktopHarness, key: &str) {
        if host.state().status_bar.open.as_deref() == Some(key) {
            return;
        }
        let (x, y) = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let chip = attr_node(&dom, dom.document(), "data-status-key", key)
                .unwrap_or_else(|| panic!("no {key} chip"));
            let (x, y, width, height) = host.painted_rect(chip).expect("the chip paints");
            (x + width / 2.0, y + height / 2.0)
        };
        host.click_at(x, y);
        host.relayout();
        assert_eq!(
            host.state().status_bar.open.as_deref(),
            Some(key),
            "the {key} chip opened"
        );
    }

    /// Step 5c: one click on another chip opens its popover, and a click in
    /// the document, outside the popover, closes it.
    #[test]
    fn a_chip_click_switches_popovers_and_a_click_outside_closes_them() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# Notes\n"));
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Djot")));
        assert_eq!(
            host.state().status_bar.open.as_deref(),
            Some(crate::status::FORMAT)
        );
        assert!(host.click_on(&Selector::role("button").containing("Not saved")));
        assert_eq!(
            host.state().status_bar.open.as_deref(),
            Some(crate::status::SAVE),
            "one click switched the popover"
        );
        host.click_at(550.0, 350.0);
        assert_eq!(
            host.state().status_bar.open,
            None,
            "a click in the document closed it"
        );
    }

    /// Step 5c: a refused save raises the save chip, posts its sentence to the
    /// message line, marks its tab, and shows the refusal in the chip's popover.
    #[test]
    fn a_refused_save_raises_its_chip_posts_its_sentence_and_marks_its_tab() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("notes.djot");
        std::fs::write(&path, "# Notes\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let save_chip = |host: &DesktopHarness| {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let chip =
                attr_node(&dom, dom.document(), "data-status-key", "save").expect("the save chip");
            let severity = dom
                .attribute(
                    chip,
                    &Namespace::from(""),
                    &LocalName::from("data-severity"),
                )
                .map(str::to_owned);
            (text_content(&dom, chip), severity)
        };
        assert_eq!(
            save_chip(&host),
            ("Saved".to_owned(), Some("quiet".to_owned()))
        );

        std::fs::write(&path, "# Changed elsewhere\n").unwrap();
        insert(&mut host, "More. ");
        assert!(host.click_on(&Selector::role("button").containing("Save")));
        assert_eq!(
            save_chip(&host),
            ("Save refused".to_owned(), Some("refused".to_owned()))
        );
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let message = class_node(&dom, dom.document(), "status-message").expect("message");
            assert_eq!(
                text_content(&dom, message),
                "Save refused: the file changed on disk. Compare, Reload, or choose a new Save As path."
            );
            assert!(
                attr_node(&dom, dom.document(), "data-mark", "attention").is_some(),
                "the refused document's tab is marked"
            );
            let tab = attr_node(&dom, dom.document(), "aria-description", "Needs attention")
                .expect("the marked tab is announced");
            assert!(text_content(&dom, tab).contains("notes.djot"));
        }

        assert!(host.click_on(&Selector::role("button").containing("Save refused")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let detail = class_node(&dom, dom.document(), "knot-status-detail").expect("the popover");
        let text = text_content(&dom, detail);
        let reason = knot_document_refusal_label(KnotDocumentRefusalV1::ExternalChange);
        assert!(
            text.contains(reason),
            "the popover and the message share words: {text}"
        );
        assert!(
            named_node(&dom, detail, "button").is_some(),
            "the popover offers Save"
        );
    }

    /// The document the active reading tile's header names.
    fn active_reading_document(host: &DesktopHarness) -> Option<String> {
        let dom = host.runner().dom();
        let dom = dom.borrow();
        class_node(&dom, dom.document(), "knot-reading-document")
            .map(|node| text_content(&dom, node))
    }

    fn reading_tile(host: &DesktopHarness, kind: ReadingKind, pinned: bool) -> workbench::TileId {
        host.state()
            .docs
            .readings()
            .find(|(_, open, pin)| *open == kind && pin.is_some() == pinned)
            .map(|(tile, _, _)| tile)
            .expect("the reading tile")
    }

    #[test]
    fn a_following_reading_switches_with_the_focus_and_a_pinned_one_stays() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "# A heading\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        assert_eq!(active_reading_document(&host).as_deref(), Some("a.djot"));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        let pinned = reading_tile(&host, ReadingKind::Preview, true);
        assert!(host.click_on(&Selector::role("button").containing("New")));
        let scratch = host.state().focused_key().unwrap();
        assert_ne!(scratch, a);
        assert_eq!(
            host.state().docs.document_for(pinned),
            Some(a),
            "a pin stays"
        );
        assert_eq!(active_reading_document(&host).as_deref(), Some("a.djot"));

        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        let following = reading_tile(&host, ReadingKind::Preview, false);
        assert_eq!(host.state().docs.document_for(following), Some(scratch));
        assert_eq!(
            active_reading_document(&host).as_deref(),
            Some("scratch:untitled")
        );
        host.update(|state| {
            state.docs.focus(a);
            state.after_focus_change();
        });
        assert_eq!(
            host.state().docs.document_for(following),
            Some(a),
            "an unpinned reading follows the focus"
        );
        assert_eq!(host.state().docs.document_for(pinned), Some(a));
    }

    #[test]
    fn scenario_snapshot_counts_every_pinned_reading_kind() {
        let mut state = DesktopState::new(
            KnotDocumentSession::scratch("scratch:pinned-snapshot", "# Pinned\n"),
            WindowCommands::new(),
        );
        let document = state.focused_key().unwrap();
        for (kind, title) in [
            (ReadingKind::Preview, "Preview"),
            (ReadingKind::Outline, "Outline"),
            (ReadingKind::Readings, "Readings"),
        ] {
            state.docs.open_reading(kind, Some(document), title);
        }

        let snapshot = state.scenario_snapshot();
        assert_eq!(snapshot.field("preview_open"), Some("true"));
        assert_eq!(snapshot.field("outline_open"), Some("true"));
        assert_eq!(snapshot.field("readings_open"), Some("true"));
    }

    #[test]
    fn two_pinned_previews_keep_their_own_ids() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "# A\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("New")));
        let b = host.state().focused_key().unwrap();
        host.update(|state| {
            state
                .docs
                .open_reading(ReadingKind::Preview, Some(a), "Preview");
            state
                .docs
                .open_reading(ReadingKind::Preview, Some(b), "Preview");
        });
        let pinned_to = |host: &DesktopHarness, key: DocKey| {
            host.state()
                .docs
                .readings()
                .find(|(_, kind, pin)| *kind == ReadingKind::Preview && *pin == Some(key))
                .map(|(tile, _, _)| tile)
                .expect("a preview pinned to the document")
        };
        let (first, second) = (pinned_to(&host, a), pinned_to(&host, b));
        let preview_id = |host: &mut DesktopHarness, tile: workbench::TileId| {
            host.update(|state| state.docs.activate(tile));
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let preview = class_node(&dom, dom.document(), "knot-document-preview")
                .expect("the preview renders");
            dom.attribute(preview, &Namespace::from(""), &LocalName::from("id"))
                .map(str::to_owned)
        };
        let first_id = preview_id(&mut host, first).expect("an id");
        let second_id = preview_id(&mut host, second).expect("an id");
        assert_eq!(first_id, format!("knot-document-preview-{}", first.0));
        assert_eq!(second_id, format!("knot-document-preview-{}", second.0));
        assert_eq!(host.state().docs.document_for(first), Some(a));
        assert_eq!(host.state().docs.document_for(second), Some(b));
    }

    #[test]
    fn a_pinned_outline_row_selects_in_its_own_document() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "# First\n\n## Second\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert_ne!(host.state().focused_key(), Some(a));
        let outline = reading_tile(&host, ReadingKind::Outline, true);
        host.update(|state| state.docs.activate(outline));
        assert!(host.click_on(&Selector::role("button").containing("Second")));
        assert_eq!(
            host.state().focused_key(),
            Some(a),
            "the row focuses its document"
        );
        let snapshot = host.state().document().snapshot();
        let selected =
            &snapshot.text[snapshot.selection.anchor.byte..snapshot.selection.focus.byte];
        assert!(selected.contains("Second"), "selected {selected:?}");
    }

    #[test]
    fn a_pinned_preview_heading_selects_in_its_own_document() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "# First\n\n## Second\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert_ne!(host.state().focused_key(), Some(a));
        assert!(host.click_on(&Selector::role("button").containing("Second")));
        assert_eq!(
            host.state().focused_key(),
            Some(a),
            "the heading focuses its document"
        );
        let snapshot = host.state().document().snapshot();
        let selected =
            &snapshot.text[snapshot.selection.anchor.byte..snapshot.selection.focus.byte];
        assert!(selected.contains("Second"), "selected {selected:?}");
    }

    /// A reading script that lists every heading as a row over its span.
    const HEADING_ROWS: &str =
        "let out = [];\nfor h in outline() { out.push(row(h.label, h.span)); }\nout\n";

    /// A document `a.djot` with two headings and a readings folder holding
    /// `scripts`, open in a laid-out harness.
    fn readings_host(scripts: &[&str]) -> (tempfile::TempDir, DesktopHarness) {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "# First\n\n## Second\n").unwrap();
        let folder = temp.path().join("readings");
        std::fs::create_dir(&folder).unwrap();
        for name in scripts {
            std::fs::write(folder.join(name), HEADING_ROWS).unwrap();
        }
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.update(|state| state.set_readings_root(Some(folder)));
        host.layout_at(1100.0, 700.0);
        (temp, host)
    }

    #[test]
    fn a_pinned_readings_tile_runs_over_its_own_document() {
        let (_temp, mut host) = readings_host(&["headings.rhai"]);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Readings")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        let b = host.state().focused_key().unwrap();
        assert_ne!(a, b);
        assert!(host.click_on(&Selector::role("button").with_attr("data-reading-index", "0")));
        assert!(host.click_on(&Selector::role("button").containing("Run reading")));
        let ran = |key| {
            host.state()
                .docs
                .doc(key)
                .and_then(|entry| entry.reading_result.as_ref())
                .map(|result| result.provenance.source.address.clone())
        };
        assert!(ran(a).is_some_and(|address| address.ends_with("a.djot")));
        assert_eq!(ran(b), None, "the focused document was not read");

        assert!(host.click_on(&Selector::role("button").with_attr("data-reading-row", "1")));
        assert_eq!(
            host.state().focused_key(),
            Some(a),
            "the row focuses its document"
        );
        let snapshot = host.state().document().snapshot();
        let selected =
            &snapshot.text[snapshot.selection.anchor.byte..snapshot.selection.focus.byte];
        assert!(selected.contains("Second"), "selected {selected:?}");
    }

    #[test]
    fn each_readings_tile_keeps_its_own_script_and_id() {
        let (_temp, mut host) = readings_host(&["first.rhai", "second.rhai"]);
        assert!(host.click_on(&Selector::role("button").containing("Readings")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        let pinned = reading_tile(&host, ReadingKind::Readings, true);
        assert!(host.click_on(&Selector::role("button").containing("Readings")));
        let following = reading_tile(&host, ReadingKind::Readings, false);
        host.update(|state| {
            state.select_reading(pinned, 0);
            state.select_reading(following, 1);
        });
        let chosen = |host: &DesktopHarness, tile| {
            host.state()
                .reading_script(tile)
                .map(|script| script.name.clone())
        };
        assert_eq!(chosen(&host, pinned).as_deref(), Some("first.rhai"));
        assert_eq!(chosen(&host, following).as_deref(), Some("second.rhai"));
        for tile in [pinned, following] {
            host.update(|state| state.docs.activate(tile));
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let body = class_node(&dom, dom.document(), "knot-readings").expect("the body");
            assert_eq!(
                dom.attribute(body, &Namespace::from(""), &LocalName::from("id")),
                Some(format!("knot-readings-{}", tile.0).as_str()),
            );
        }
        host.update(|state| {
            state.docs.close(pinned);
        });
        host.after_dispatch();
        assert!(
            !host.state().reading_scripts.contains_key(&pinned),
            "a closed tile's choice goes with it"
        );
    }

    /// D2: a long document name gives way before the Pin button.
    #[test]
    fn a_long_document_name_stops_short_of_the_pin_button() {
        let temp = tempdir().unwrap();
        let path = temp
            .path()
            .join("a_document_name_far_too_long_for_the_header_of_a_narrow_reading_tile.djot");
        std::fs::write(&path, "# A\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(640.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        let (header, name, pin) = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            (
                class_node(&dom, dom.document(), "knot-reading-header").expect("header"),
                class_node(&dom, dom.document(), "knot-reading-document").expect("name"),
                class_node(&dom, dom.document(), "knot-reading-pin").expect("pin"),
            )
        };
        let (header_x, _, header_width, _) = host.painted_rect(header).expect("header layout");
        let (name_x, _, name_width, _) = host.painted_rect(name).expect("name layout");
        let (pin_x, _, pin_width, _) = host.painted_rect(pin).expect("pin layout");
        assert!(
            name_x + name_width <= pin_x + 0.5
                && pin_x + pin_width <= header_x + header_width + 0.5,
            "name {name_x} + {name_width}, pin {pin_x} + {pin_width}, header {header_x} + {header_width}",
        );
    }

    #[test]
    fn opening_a_path_popover_leaves_the_command_row_in_place() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.layout_at(1100.0, 700.0);
        let row = |host: &DesktopHarness| {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let toolbar = class_node(&dom, dom.document(), "knot-workspace-toolbar")
                .expect("the command row");
            let children: Vec<_> = dom.dom_children(toolbar).collect();
            drop(dom);
            children
                .into_iter()
                .map(|child| host.painted_rect(child))
                .collect::<Vec<_>>()
        };
        let closed = row(&host);
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-open")));
        assert!(host.state().open_popover.open);
        assert_eq!(
            row(&host),
            closed,
            "the open popover moves nothing in the row"
        );
    }

    #[test]
    fn appearance_controls_preserve_source_selection_and_clean_baseline() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# First\n\n## Second\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        assert!(host.click_on(&Selector::role("button").containing("Second")));
        let before = host.state().document().snapshot();
        assert!(!before.dirty);
        assert_ne!(before.selection.anchor.byte, before.selection.focus.byte);
        assert!(host.click_on(&Selector::role("button").containing("Appearance")));
        assert!(host.click_on(&Selector::role("button").containing("Dark")));
        assert!(host.click_on(&Selector::role("button").containing("Highlight")));
        assert!(host.click_on(&Selector::role("button").containing("Wide")));
        assert!(host.click_on(&Selector::role("button").containing("Relaxed")));
        let after = host.state().document().snapshot();
        assert_eq!(after.text, before.text);
        assert_eq!(after.selection, before.selection);
        assert_eq!(after.dirty, before.dirty);
        assert!(host.state().appearance.dark);
        assert!(!host.state().appearance.highlight);
        assert_eq!(host.state().appearance.measure, Measure::Wide);
        assert!(host.state().appearance.relaxed);
    }

    #[test]
    fn typography_choices_preserve_preedit_selection_and_saved_baseline() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("typography.djot");
        let source = "# First\n\n## Second\n\nCommitted Unicode: 本文.\n";
        std::fs::write(&path, source).unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 800.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        assert!(host.click_on(&Selector::role("button").containing("Second")));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .set_preedit("仮入力")
        });
        let before = host.state().document().snapshot();
        let baseline = host.state().document().session().compare_disk().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Appearance")));
        for label in [
            "System monospace",
            "Narrow",
            "Full",
            "Follow hard wrap",
            "Larger",
            "Compact",
            "IBM Plex Mono",
            "Medium",
        ] {
            assert!(
                host.click_on(&Selector::role("button").containing(label)),
                "{label}"
            );
            assert_eq!(host.state().document().snapshot(), before, "{label}");
            assert_eq!(
                host.state().document().session().input().preedit(),
                "仮入力",
                "{label}"
            );
            assert_eq!(
                host.state().document().session().compare_disk().unwrap(),
                baseline,
                "{label}"
            );
            assert_eq!(std::fs::read_to_string(&path).unwrap(), source);
        }
    }

    #[test]
    fn ordinary_document_preview_is_hidden_by_default_and_toggle_preserves_source() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Héading\n\nBody",
        ));
        host.layout_at(900.0, 640.0);
        let before = host.state().document().snapshot();
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .set_preedit("仮入力");
        });
        let dom = host.runner().dom();
        let dom = dom.borrow();
        assert!(class_node(&dom, dom.document(), "knot-document-preview").is_none());
        drop(dom);
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        let after = host.state().document().snapshot();
        assert_eq!(after.text, before.text);
        assert_eq!(after.selection, before.selection);
        assert_eq!(after.dirty, before.dirty);
        assert_eq!(
            host.state().document().session().input().preedit(),
            "仮入力"
        );
        let dom = host.runner().dom();
        let dom = dom.borrow();
        assert!(class_node(&dom, dom.document(), "knot-document-preview").is_some());
        let reading = class_node(&dom, dom.document(), "knot-reading").unwrap();
        let reading_text = text_content(&dom, reading);
        assert!(
            reading_text.contains("scratch:untitled"),
            "the header names the document"
        );
        assert!(reading_text.contains("Diagnostics: none"));
        assert!(!reading_text.contains("仮入力"));
    }

    #[test]
    fn folded_source_is_a_tile_that_leaves_the_source_alone() {
        let source = "# α\n\n## 二\nbody\n\n- first\n- second\n";
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, source));
        host.layout_at(900.0, 640.0);
        let before = host.state().document().snapshot();
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            assert!(class_node(&dom, dom.document(), "knot-folding").is_none());
            assert!(!text_content(&dom, dom.document()).contains("Folded source"));
        }
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .set_preedit("仮入力");
        });
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        let after_show = host.state().document().snapshot();
        assert_eq!(after_show, before);
        assert_eq!(
            host.state().document().session().input().preedit(),
            "仮入力"
        );
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let folding = class_node(&dom, dom.document(), "knot-folding").unwrap();
            let folded_text = text_content(&dom, folding);
            assert!(folded_text.contains("# α"));
            assert!(!folded_text.contains("仮入力"));
        }
        assert!(
            host.click_on(&Selector::role("button").with_attr("aria-label", "Collapse all folds"))
        );
        let after_collapse = host.state().document().snapshot();
        assert_eq!(after_collapse, before);
        assert!(
            !host.state().entry().collapsed_folds.is_empty(),
            "fold error: {:?}; snapshot: {:?}",
            host.state().entry().fold_error,
            host.state().entry().fold_snapshot
        );
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            assert!(count_class(&dom, dom.document(), "fold-marker") > 0);
            assert!(attr_node(&dom, dom.document(), "aria-label", "Folded content").is_some());
        }
        assert!(
            host.click_on(&Selector::role("button").with_attr("aria-label", "Expand all folds"))
        );
        assert!(host.state().entry().collapsed_folds.is_empty());
        assert_eq!(host.state().document().snapshot(), before);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let folding = class_node(&dom, dom.document(), "knot-folding").unwrap();
        assert!(text_content(&dom, folding).contains("body"));
        drop(dom);
        assert!(host.click_on(&Selector::role("button").containing("Edit source")));
        assert!(
            host.state()
                .docs
                .following_reading(ReadingKind::Folded)
                .is_some(),
            "Edit source leaves the tile open"
        );
        let dom = host.runner().dom();
        let dom = dom.borrow();
        assert!(class_node(&dom, dom.document(), "knot-document-body").is_some());
        assert!(class_node(&dom, dom.document(), "knot-folding").is_some());
    }

    /// The visible rows of the folded source: each row's source line and
    /// its text, gutter and line together.
    fn folded_rows(host: &DesktopHarness) -> Vec<(String, String)> {
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let Some(source) = class_node(&dom, dom.document(), "knot-folded-source") else {
            return Vec::new();
        };
        dom.dom_children(source)
            .map(|row| {
                let line = dom
                    .attribute(row, &Namespace::from(""), &LocalName::from("data-line"))
                    .unwrap_or_default()
                    .to_owned();
                (line, text_content(&dom, row))
            })
            .collect()
    }

    const TWO_SECTIONS: &str = "# First\n\n- one\n- two\n\n# Second\n\nbody\n";

    /// D4: a fold's control sits in the gutter of the line it starts on,
    /// and collapsing it ends that line with the marker.
    #[test]
    fn a_gutter_toggle_folds_its_section_beside_its_heading() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, TWO_SECTIONS));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        let lines = |rows: &[(String, String)]| {
            rows.iter()
                .map(|(line, _)| line.clone())
                .collect::<Vec<_>>()
        };
        assert_eq!(
            lines(&folded_rows(&host)),
            ["1", "2", "3", "4", "5", "6", "7", "8"]
        );
        assert!(
            host.click_on(
                &Selector::role("button")
                    .with_attr("aria-label", "Collapse Section · line 1 · # First")
            )
        );
        let rows = folded_rows(&host);
        assert_eq!(
            lines(&rows),
            ["1", "6", "7", "8"],
            "the section's lines hide"
        );
        assert!(
            rows[0].1.contains("# First") && rows[0].1.contains('…'),
            "the marker ends the heading's own row: {:?}",
            rows[0].1
        );
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let toggle = attr_node(
            &dom,
            dom.document(),
            "aria-label",
            "Expand Section · line 1 · # First",
        )
        .expect("the toggle now expands");
        assert_eq!(
            dom.attribute(
                toggle,
                &Namespace::from(""),
                &LocalName::from("aria-expanded")
            ),
            Some("false")
        );
        let gutter = dom.parent(toggle).expect("the toggle's cell");
        assert!(
            dom.has_class(gutter, "fold-gutter"),
            "the control sits in the gutter"
        );
    }

    #[test]
    fn the_folded_tile_follows_an_edit_and_keeps_its_folds() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, TWO_SECTIONS));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        assert!(
            host.click_on(
                &Selector::role("button")
                    .with_attr("aria-label", "Collapse Section · line 6 · # Second")
            )
        );
        let edited = format!("# Zero\n\nintro\n\n{TWO_SECTIONS}");
        host.update(|state| {
            state
                .document_mut()
                .apply(knot_document::KnotDocumentIntentV1::Edit(
                    cambium::TextCommand::SelectAll,
                ))
                .unwrap();
            state
                .document_mut()
                .apply(knot_document::KnotDocumentIntentV1::Edit(
                    cambium::TextCommand::Insert(edited.clone()),
                ))
                .unwrap();
        });
        host.after_dispatch();
        assert!(
            host.state()
                .docs
                .following_reading(ReadingKind::Folded)
                .is_some(),
            "an edit leaves the tile open"
        );
        let entry = host.state().entry();
        let snapshot = entry.fold_snapshot.as_ref().expect("a fresh snapshot");
        assert_eq!(snapshot.source_text, edited);
        let collapsed = crate::document_folding::normalized_folds(snapshot)
            .into_iter()
            .filter(|fold| entry.collapsed_folds.contains(&fold.source_index))
            .map(|fold| {
                snapshot.source_text[fold.start..fold.end]
                    .lines()
                    .next()
                    .unwrap_or_default()
                    .to_owned()
            })
            .collect::<Vec<_>>();
        assert_eq!(collapsed, ["# Second"], "the same section stays collapsed");
        let rows = folded_rows(&host);
        assert!(rows.iter().any(|(_, text)| text.contains("# Zero")));
        assert!(!rows.iter().any(|(_, text)| text.contains("body")));
    }

    #[test]
    fn an_outline_selection_leaves_the_folded_tile_open() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# First\n\n## Second\n\nbody\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        assert!(host.click_on(
            &Selector::role("button").with_attr("aria-label", "Heading level 2: Second")
        ));

        let snapshot = host.state().document().snapshot();
        assert_eq!(
            &snapshot.text[snapshot.selection.anchor.byte..snapshot.selection.focus.byte],
            "## Second\n"
        );
        assert!(
            host.state()
                .docs
                .following_reading(ReadingKind::Folded)
                .is_some()
        );
        assert!(host.focus().is_some());
    }

    #[test]
    fn a_pinned_folded_tile_folds_its_own_document() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, TWO_SECTIONS).unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        let pinned = reading_tile(&host, ReadingKind::Folded, true);
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert_ne!(host.state().focused_key(), Some(a));
        assert!(
            host.click_on(&Selector::role("button").with_attr("aria-label", "Collapse all folds"))
        );
        let collapsed = |key| {
            host.state()
                .docs
                .doc(key)
                .map_or(0, |entry| entry.collapsed_folds.len())
        };
        assert!(collapsed(a) > 0, "the pinned document folds");
        assert_eq!(collapsed(host.state().focused_key().unwrap()), 0);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let body = class_node(&dom, dom.document(), "knot-folding").expect("the tile body");
        assert_eq!(
            dom.attribute(body, &Namespace::from(""), &LocalName::from("id")),
            Some(format!("knot-document-folding-{}", pinned.0).as_str()),
        );
    }

    #[test]
    fn folded_row_action_rejects_a_stale_full_snapshot() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# First\n\n## Second\nbody\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show folds")));
        let stale = host.state().entry().fold_snapshot.clone().unwrap();
        host.update(|state| {
            state
                .document_mut()
                .apply(knot_document::KnotDocumentIntentV1::Edit(
                    cambium::TextCommand::SelectAll,
                ))
                .unwrap();
            state
                .document_mut()
                .apply(knot_document::KnotDocumentIntentV1::Edit(
                    cambium::TextCommand::Insert("# New\n\nchanged\n".into()),
                ))
                .unwrap();
        });
        let key = host.state().focused_key().unwrap();
        host.update(|state| state.toggle_fold(key, stale, 0));
        assert!(host.state().entry().collapsed_folds.is_empty());
        assert!(
            host.state()
                .entry()
                .fold_error
                .as_deref()
                .is_some_and(|error| error.contains("stale"))
        );
    }

    #[test]
    fn ordinary_preview_heading_selects_source_and_returns_focus() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Héading\n\nBody",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        assert!(host.click_on(
            &Selector::role("button").with_attr("aria-label", "Select source heading: Héading")
        ));
        let snapshot = host.state().document().snapshot();
        assert_eq!(
            &snapshot.text[snapshot.selection.anchor.byte..snapshot.selection.focus.byte],
            "# Héading\n"
        );
        assert!(host.focus().is_some());
    }

    #[test]
    fn ordinary_preview_renders_current_unicode_edit() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# Start\n"));
        host.layout_at(900.0, 640.0);
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("\n本文")
        });
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let preview = class_node(&dom, dom.document(), "knot-document-preview").unwrap();
        assert!(text_content(&dom, preview).contains("本文"));
    }

    #[test]
    fn ordinary_preview_tracks_new_open_and_reload() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("preview-transitions.djot");
        std::fs::write(&path, "# Opened preview\n").unwrap();
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Initial preview\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert!(
            host.state()
                .docs
                .following_reading(ReadingKind::Preview)
                .is_some()
        );
        open_through_path(&mut host, &path);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let preview = class_node(&dom, dom.document(), "knot-document-preview").unwrap();
        assert!(text_content(&dom, preview).contains("Opened preview"));
        drop(dom);
        std::fs::write(&path, "# Reloaded preview\n").unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Reload")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let preview = class_node(&dom, dom.document(), "knot-document-preview").unwrap();
        assert!(text_content(&dom, preview).contains("Reloaded preview"));
        assert!(!text_content(&dom, preview).contains("Opened preview"));
    }

    #[test]
    fn native_formats_use_the_standard_preview_tile() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("native.gmi");
        std::fs::write(&path, "# Native\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(900.0, 640.0);
        assert!(
            host.resolve(&Selector::role("button").containing("Show Preview"))
                .is_some()
        );
        let dom = host.runner().dom();
        let dom = dom.borrow();
        assert!(class_node(&dom, dom.document(), "knot-document-preview").is_none());
        drop(dom);
        assert!(host.click_on(&Selector::role("button").containing("Show Preview")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let native_preview = class_node(&dom, dom.document(), "knot-document-preview").unwrap();
        assert!(text_content(&dom, native_preview).contains("Native"));
        assert!(class_node(&dom, dom.document(), "knot-scroll-preview").is_some());
        assert!(!text_content(&dom, dom.document()).contains("Show folds"));
        assert!(host.state().entry().fold_snapshot.is_none());
    }

    #[test]
    fn appearance_settings_persist_through_new_open_and_reload() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("appearance.djot");
        std::fs::write(&path, "# Opened\n").unwrap();
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "draft"));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Appearance")));
        assert!(host.click_on(&Selector::role("button").containing("Dark")));
        assert!(host.click_on(&Selector::role("button").containing("Highlight")));
        assert!(host.click_on(&Selector::role("button").containing("Wide")));
        assert!(host.click_on(&Selector::role("button").containing("Compact")));
        assert!(host.click_on(&Selector::role("button").containing("Larger")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert_eq!(host.state().document().snapshot().text, "");
        assert_eq!(host.state().document().session().source_path(), None);
        open_through_path(&mut host, &path);
        assert_eq!(host.state().document().snapshot().text, "# Opened\n");
        assert_eq!(
            host.state().document().session().source_path(),
            Some(path.canonicalize().unwrap().as_path())
        );
        std::fs::write(&path, "# Reloaded\n").unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Reload")));
        assert_eq!(host.state().document().snapshot().text, "# Reloaded\n");
        let appearance = &host.state().appearance;
        assert!(appearance.dark);
        assert!(!appearance.highlight);
        assert_eq!(appearance.font_size, 17);
        assert_eq!(appearance.measure, Measure::Wide);
        assert!(!appearance.relaxed);
    }

    #[test]
    fn highlighting_toggle_keeps_preedit_unicode_input_and_saved_bytes() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("ime.djot");
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Appearance")));
        assert!(host.click_on(&Selector::role("button").containing("Highlight")));
        host.update(|state| {
            let input = state.document_mut().session_mut().input_mut().unwrap();
            input.set_preedit("仮入力");
        });
        assert_eq!(
            host.state().document().session().input().preedit(),
            "仮入力"
        );
        assert!(host.click_on(&Selector::role("button").containing("Highlight")));
        assert_eq!(
            host.state().document().session().input().preedit(),
            "仮入力"
        );
        assert!(host.click_on(&Selector::role("textbox").with_attr("aria-label", "Document text")));
        host.key_injected("確定");
        assert_eq!(host.state().document().snapshot().text, "確定");
        assert!(save_as_through(&mut host, &path));
        assert_eq!(std::fs::read(&path).unwrap(), "確定".as_bytes());
    }

    fn text_content(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
    ) -> String {
        let own = dom.text(node).unwrap_or_default();
        let children = dom
            .dom_children(node)
            .map(|child| text_content(dom, child))
            .collect::<String>();
        format!("{own}{children}")
    }

    fn count_class(
        dom: &genet_scripted_dom::ScriptedDom,
        node: genet_scripted_dom::NodeId,
        class: &str,
    ) -> usize {
        usize::from(dom.has_class(node, class))
            + dom
                .dom_children(node)
                .map(|child| count_class(dom, child, class))
                .sum::<usize>()
    }

    fn request_native_close(
        host: &mut Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>,
    ) {
        host.request_close(CloseRequest::Native);
        // KeepVisible requests a native redraw. Supply that frame explicitly
        // before resolving newly created prompt controls in the windowless host.
        host.layout_at(900.0, 640.0);
    }

    #[test]
    fn save_as_takes_its_path_from_a_focused_popover_field() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("saved.djot");
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# Draft\n"));
        host.layout_at(1000.0, 720.0);
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-save-as")));
        assert!(
            focus_inside(&host, "knot-save-as-field"),
            "the field takes focus"
        );
        host.key_injected(&path.to_string_lossy());
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-save-as-confirm")));
        assert!(path.exists());
        assert!(
            !host.state().save_as_popover.open,
            "it closes once it saved"
        );
    }

    #[test]
    fn save_as_starts_from_the_documents_own_path() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("own.djot");
        std::fs::write(&path, "own\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1000.0, 720.0);
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-save-as")));
        let prefilled = host.state().save_as_path.text().to_owned();
        assert!(prefilled.ends_with("own.djot"), "{prefilled}");
        assert!(
            !prefilled.starts_with(r"\\?\"),
            "no verbatim prefix: {prefilled}"
        );
    }

    #[test]
    fn display_paths_strip_drive_and_unc_verbatim_prefixes() {
        assert_eq!(
            display_path(Path::new(r"\\?\C:\sites\field-notes")),
            r"C:\sites\field-notes"
        );
        assert_eq!(
            display_path(Path::new(r"\\?\UNC\server\share\field-notes")),
            r"\\server\share\field-notes"
        );
        assert_eq!(
            display_path(Path::new(r"\\server\share\field-notes")),
            r"\\server\share\field-notes"
        );
    }

    #[test]
    fn the_open_popover_keeps_a_long_path_on_one_line() {
        const LONG: &str = "C:/Users/someone/AppData/Local/Temp/a/very/long/folder/structure/that/keeps/going/and/going/document.djot";
        for width in [1100.0, 640.0] {
            let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
            host.layout_at(width, 700.0);
            assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-open")));
            let size = |host: &DesktopHarness| {
                let dom = host.runner().dom();
                let dom = dom.borrow();
                let field = attr_node(&dom, dom.document(), "id", "knot-path-field")
                    .and_then(|label| input_node(&dom, label))
                    .expect("the Open field");
                let panel = class_node(&dom, dom.document(), "knot-path-popover").expect("panel");
                drop(dom);
                (
                    host.painted_rect(field).expect("field layout"),
                    host.painted_rect(panel).expect("panel layout"),
                )
            };
            host.update(|state| state.path = TextInput::new("notes.djot"));
            let ((_, _, short_width, short_height), _) = size(&host);
            host.update(|state| state.path = TextInput::new(LONG));
            let ((x, _, long_width, long_height), (panel_x, _, panel_width, _)) = size(&host);
            assert_eq!(long_height, short_height, "one line at {width}px");
            assert_eq!(long_width, short_width, "the path does not widen the field");
            assert!(
                x >= panel_x && x + long_width <= panel_x + panel_width,
                "the field stays inside its popover at {width}px",
            );
        }
    }

    #[test]
    fn dirty_native_close_stays_open_until_discard_and_clean_close_exits() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.layout_at(900.0, 640.0);
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("edit");
        });
        request_native_close(&mut host);
        assert!(!host.close_requested());
        assert!(host.click_on(&Selector::role("button").containing("Discard")));
        assert!(host.close_requested());
    }

    #[test]
    fn dirty_native_close_save_writes_and_accepts_queued_close() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("close-save.djot");
        std::fs::write(&path, "# Original\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("draft");
        });
        host.layout_at(900.0, 640.0);
        request_native_close(&mut host);
        assert!(!host.close_requested());
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(host.close_requested());
        assert!(std::fs::read_to_string(&path).unwrap().contains("draft"));
        assert!(!host.state().document().snapshot().dirty);
    }

    #[test]
    fn canceled_dirty_close_preserves_the_document() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "draft"));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" edit");
        });
        host.layout_at(900.0, 640.0);
        request_native_close(&mut host);
        assert!(host.click_on(&Selector::role("button").containing("Cancel")));
        assert!(!host.close_requested());
        assert!(
            host.state()
                .document()
                .snapshot()
                .text
                .contains("draft edit")
        );
        assert!(host.state().document().snapshot().dirty);
    }

    #[test]
    fn open_adds_a_tab_beside_the_dirty_document() {
        let temp = tempdir().unwrap();
        let replacement = temp.path().join("replacement.djot");
        std::fs::write(&replacement, "replacement").unwrap();
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "draft"));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" edit");
            state.path = TextInput::new(replacement.to_string_lossy().into_owned());
        });
        host.layout_at(900.0, 640.0);
        let draft = host.state().focused_key().unwrap();
        assert!(confirm_open(&mut host));
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().docs.len(), 2);
        assert_eq!(host.state().document().snapshot().text, "replacement");
        let kept = &host.state().docs.doc(draft).unwrap().document;
        assert_eq!(kept.snapshot().text, "draft edit");
        assert!(kept.snapshot().dirty);
    }

    type DesktopHarness = Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>;

    fn insert(host: &mut DesktopHarness, text: &str) {
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    text.to_owned(),
                )))
                .unwrap();
        });
    }

    /// Run Open on what the Open popover's field holds, opening the popover
    /// unless a failed open left it open.
    fn confirm_open(host: &mut DesktopHarness) -> bool {
        (host.state().open_popover.open
            || host.click_on(&Selector::role("button").with_attr("id", "knot-open")))
            && host.click_on(&Selector::role("button").with_attr("id", "knot-open-confirm"))
    }

    fn open_through_path(host: &mut DesktopHarness, path: &Path) {
        host.update(|state| state.path = TextInput::new(path.to_string_lossy()));
        assert!(confirm_open(host));
    }

    /// Save the focused document as `path` through the Save As popover.
    fn save_as_through(host: &mut DesktopHarness, path: &Path) -> bool {
        if !host.state().save_as_popover.open
            && !host.click_on(&Selector::role("button").with_attr("id", "knot-save-as"))
        {
            return false;
        }
        host.update(|state| state.save_as_path = TextInput::new(path.to_string_lossy()));
        host.click_on(&Selector::role("button").with_attr("id", "knot-save-as-confirm"))
    }

    /// Whether keyboard focus sits inside the element with `id`.
    fn focus_inside(host: &DesktopHarness, id: &str) -> bool {
        let Some(focused) = host.focus() else {
            return false;
        };
        let dom = host.runner().dom();
        let dom = dom.borrow();
        ancestor_has_id(&*dom, focused, id)
    }

    fn close_tab(host: &mut DesktopHarness, label: &str) -> bool {
        host.click_on(&Selector::role("button").with_attr("aria-label", format!("Close {label}")))
    }

    fn confirm_text(host: &DesktopHarness) -> String {
        let dom = host.runner().dom();
        let dom = dom.borrow();
        class_node(&dom, dom.document(), "knot-confirm")
            .map(|node| text_content(&dom, node))
            .unwrap_or_default()
    }

    fn document_fixture() -> (tempfile::TempDir, PathBuf, PathBuf) {
        let temp = tempdir().unwrap();
        let first = temp.path().join("first.djot");
        let second = temp.path().join("second.djot");
        std::fs::write(&first, "first\n").unwrap();
        std::fs::write(&second, "second\n").unwrap();
        (temp, first, second)
    }

    #[test]
    fn two_files_and_a_scratch_keep_their_state_across_activation() {
        let (_temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        insert(&mut host, "one ");
        let first_key = host.state().focused_key().unwrap();
        let selection = host.state().document().snapshot().selection;
        open_through_path(&mut host, &second);
        assert!(host.click_on(&Selector::role("button").containing("New")));
        insert(&mut host, "draft");
        assert_eq!(host.state().docs.len(), 3);
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            assert_eq!(count_class(&dom, dom.document(), "frisket-tab"), 3);
            // The edited file and the draft carry the unsaved mark; the
            // untouched file does not.
            assert_eq!(count_class(&dom, dom.document(), "tab-mark"), 2);
            let marked = attr_node(&dom, dom.document(), "data-mark", "modified");
            assert!(marked.is_some());
        }

        assert!(host.click_on(&Selector::role("tab").containing("first.djot")));
        assert_eq!(host.state().focused_key(), Some(first_key));
        let snapshot = host.state().document().snapshot();
        assert_eq!(snapshot.text, "first\none ");
        assert_eq!(snapshot.selection, selection);
        assert!(snapshot.dirty);
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let tile = attr_node(
                &dom,
                dom.document(),
                "data-knot-document",
                &first_key.0.to_string(),
            );
            assert!(tile.is_some(), "the tile in view carries its document key");
        }
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Undo))
                .unwrap();
        });
        assert_eq!(host.state().document().snapshot().text, "first\n");

        assert!(host.click_on(&Selector::role("tab").containing("second.djot")));
        assert_eq!(host.state().document().snapshot().text, "second\n");
        assert!(!host.state().document().snapshot().dirty);
        assert!(host.click_on(&Selector::role("tab").containing(SCRATCH_ADDRESS)));
        assert_eq!(host.state().document().snapshot().text, "draft");
        assert!(host.state().document().snapshot().dirty);
    }

    #[test]
    fn typing_after_switching_tabs_edits_the_shown_document() {
        let (_temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        open_through_path(&mut host, &second);
        let second_key = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("tab").containing("first.djot")));
        assert!(host.click_on(&Selector::role("tab").containing("second.djot")));
        let editor = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let tile = attr_node(
                &dom,
                dom.document(),
                "data-knot-document",
                &second_key.0.to_string(),
            )
            .expect("second tile");
            named_node(&dom, tile, "textarea").expect("second editor")
        };
        let (x, y, width, height) = host.painted_rect(editor).expect("editor layout");
        host.click_at(x + width / 2.0, y + height / 2.0);
        host.key_injected("typed ");
        let second_text = &host.state().docs.doc(second_key).unwrap().document;
        assert!(second_text.snapshot().text.contains("typed "));
        let first_text = host
            .state()
            .docs
            .docs()
            .find(|(key, _)| *key != second_key)
            .map(|(_, entry)| entry.document.snapshot().text)
            .unwrap();
        assert_eq!(first_text, "first\n");
    }

    #[test]
    fn a_duplicate_open_activates_the_existing_tab() {
        let (temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        let first_key = host.state().focused_key().unwrap();
        open_through_path(&mut host, &second);
        open_through_path(&mut host, &temp.path().join(".").join("first.djot"));
        assert_eq!(host.state().docs.len(), 2);
        assert_eq!(host.state().focused_key(), Some(first_key));
        assert!(
            host.state()
                .message
                .as_deref()
                .is_some_and(|message| message.contains("first.djot is already open"))
        );
    }

    #[test]
    fn a_clean_tab_closes_at_once_and_a_dirty_one_asks() {
        let (_temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        let first_key = host.state().focused_key().unwrap();
        open_through_path(&mut host, &second);
        assert!(close_tab(&mut host, "second.djot"));
        assert_eq!(host.state().docs.len(), 1);
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().message.as_deref(), Some("Closed second.djot."));

        insert(&mut host, "unsaved ");
        assert!(close_tab(&mut host, "first.djot"));
        assert_eq!(
            host.state().pending,
            Some(PendingAction::CloseDocument(first_key))
        );
        assert_eq!(host.state().docs.len(), 1);
        assert!(confirm_text(&host).contains("first.djot has unsaved changes."));
        assert!(host.click_on(&Selector::role("button").containing("Cancel")));
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().docs.len(), 1);
        assert!(host.state().document().snapshot().dirty);

        // A refused save keeps both the prompt and the tab.
        std::fs::write(&first, "external\n").unwrap();
        assert!(close_tab(&mut host, "first.djot"));
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert_eq!(
            host.state().pending,
            Some(PendingAction::CloseDocument(first_key))
        );
        assert_eq!(host.state().docs.len(), 1);
        assert!(
            host.state()
                .message
                .as_deref()
                .is_some_and(|message| message.contains("changed on disk"))
        );

        assert!(host.click_on(&Selector::role("button").containing("Discard")));
        assert!(host.state().docs.is_empty());
        assert_eq!(std::fs::read_to_string(&first).unwrap(), "external\n");
    }

    #[test]
    fn saving_a_dirty_tab_on_close_writes_it_and_closes_it() {
        let (_temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        open_through_path(&mut host, &second);
        insert(&mut host, "kept ");
        assert!(close_tab(&mut host, "second.djot"));
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().docs.len(), 1);
        assert_eq!(std::fs::read_to_string(&second).unwrap(), "second\nkept ");
        assert_eq!(
            host.state().document().snapshot().display_label,
            "first.djot"
        );
    }

    #[test]
    fn closing_the_last_tab_shows_the_graph_and_new_refills_the_document_stack() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.layout_at(900.0, 640.0);
        assert!(close_tab(&mut host, SCRATCH_ADDRESS));
        assert!(host.state().docs.is_empty());
        {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            let frame = class_node(&dom, dom.document(), "knot-frame").expect("frame");
            assert!(text_content(&dom, frame).contains("No catalog is configured"));
            assert_eq!(count_class(&dom, dom.document(), "frisket-tab"), 1);
        }
        assert!(host.click_on(&Selector::role("button").containing("Save")));
        assert_eq!(
            host.state().message.as_deref(),
            Some("No document is open.")
        );
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert_eq!(host.state().docs.len(), 1);
    }

    #[test]
    fn quitting_asks_once_for_every_dirty_document() {
        let (_temp, first, second) = document_fixture();
        let mut host = harness(KnotDocumentSession::open(&first).unwrap());
        host.layout_at(900.0, 640.0);
        insert(&mut host, "a ");
        open_through_path(&mut host, &second);
        insert(&mut host, "b ");
        assert!(host.click_on(&Selector::role("button").containing("New")));
        insert(&mut host, "scratch");
        let scratch = host.state().focused_key().unwrap();

        request_native_close(&mut host);
        assert_eq!(host.state().pending, Some(PendingAction::Quit));
        let prompt = confirm_text(&host);
        assert!(prompt.contains("3 documents have unsaved changes."));
        for label in ["first.djot", "second.djot", SCRATCH_ADDRESS] {
            assert!(prompt.contains(label), "{label} is listed");
        }

        // Cancel changes nothing.
        assert!(host.click_on(&Selector::role("button").containing("Cancel")));
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().dirty_documents().len(), 3);

        // Save all writes the files; the scratch stays listed and the window stays.
        request_native_close(&mut host);
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(!host.close_requested());
        assert_eq!(std::fs::read_to_string(&first).unwrap(), "first\na ");
        assert_eq!(std::fs::read_to_string(&second).unwrap(), "second\nb ");
        assert_eq!(host.state().dirty_documents(), vec![scratch]);
        assert_eq!(host.state().pending, Some(PendingAction::Quit));
        assert!(confirm_text(&host).contains(&format!("{SCRATCH_ADDRESS} has unsaved changes.")));

        // Review shows the first listed document and dismisses the prompt.
        assert!(host.click_on(&Selector::role("tab").containing("first.djot")));
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-review")));
        assert!(host.state().pending.is_none());
        assert_eq!(host.state().focused_key(), Some(scratch));

        // Discard all closes the window over the remaining scratch.
        request_native_close(&mut host);
        assert!(host.click_on(&Selector::role("button").containing("Discard all")));
        assert!(host.close_requested());
    }

    #[test]
    fn outline_rows_select_unicode_source_and_return_focus_for_repeat_clicks() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# Café\n\n## Second heading\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        assert!(host.click_on(&Selector::role("button").containing("Café")));
        let snapshot = host.state().document().session().outline_snapshot();
        let item = snapshot
            .items
            .iter()
            .find(|item| item.label == "Café")
            .expect("unicode heading");
        assert_eq!(
            host.state().document().snapshot().selection.anchor.byte,
            item.start
        );
        assert_eq!(
            host.state().document().snapshot().selection.focus.byte,
            item.end
        );
        let textarea = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            named_node(&dom, dom.document(), "textarea").expect("document textarea")
        };
        assert_eq!(host.focus(), Some(textarea));

        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-site")));
        let folder_input = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            attr_node(&dom, dom.document(), "id", "knot-scroll-folder")
                .and_then(|label| input_node(&dom, label))
                .expect("site folder input")
        };
        let (x, y, width, height) = host.painted_rect(folder_input).expect("folder layout");
        host.click_at(x + width / 2.0, y + height / 2.0);
        assert_eq!(host.focus(), Some(folder_input));
        // The folder field sits in the Site popover: a click outside closes it
        // first, and the next reaches the outline.
        assert!(host.click_on(&Selector::role("button").containing("Second heading")));
        assert!(!host.state().scroll.popover.open);
        assert!(host.click_on(&Selector::role("button").containing("Second heading")));
        let textarea = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            named_node(&dom, dom.document(), "textarea").expect("document textarea")
        };
        assert_eq!(host.focus(), Some(textarea));
        host.key_injected("!");
        assert_eq!(host.state().scroll.folder.text(), "");
        assert_eq!(host.state().document().snapshot().text, "# Café\n\n!");
    }

    #[test]
    fn outline_tracks_direct_committed_edits_and_excludes_ime_preedit() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, "# First\n"));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("\n## Direct edit\n");
        });
        host.after_dispatch();
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let outline = class_node(&dom, dom.document(), "knot-outline").expect("outline panel");
        assert!(text_content(&dom, outline).contains("Direct edit"));
        drop(dom);

        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .set_preedit("仮入力");
        });
        host.after_dispatch();
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let outline = class_node(&dom, dom.document(), "knot-outline").expect("outline panel");
        assert!(!text_content(&dom, outline).contains("仮入力"));
    }

    #[test]
    fn stale_outline_activation_reports_refusal_without_changing_selection() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "# First\n\n## Second\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("changed");
        });
        let before = host.state().document().snapshot();
        // Deliberately omit the normal after-dispatch refresh: this click uses
        // the old retained row and exercises the exact-source guard.
        assert!(host.click_on(&Selector::role("button").containing("First")));
        assert_eq!(host.state().document().snapshot(), before);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let workspace = class_node(&dom, dom.document(), "knot-workspace").expect("workspace");
        assert!(text_content(&dom, workspace).contains("Outline selection failed:"));
    }

    #[test]
    fn empty_outline_has_an_accessible_empty_state() {
        let mut host = harness(KnotDocumentSession::scratch(
            SCRATCH_ADDRESS,
            "plain text\n",
        ));
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let outline = class_node(&dom, dom.document(), "knot-outline").expect("outline panel");
        assert!(text_content(&dom, outline).contains("No headings in this document."));
    }

    #[test]
    #[ignore = "diagnostic timing receipt; run with --ignored --nocapture"]
    fn outline_long_document_probe() {
        use std::time::Instant;

        let mut source = String::new();
        for index in 0..200 {
            source.push_str(&format!("# Heading {index}\n\n"));
            source
                .push_str(&"A long writing paragraph keeps the layout representative. ".repeat(10));
            source.push_str("\n\n");
        }
        let source_bytes = source.len();
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, source));
        host.layout_at(1100.0, 700.0);
        let show_started = Instant::now();
        assert!(host.click_on(&Selector::role("button").containing("Show Outline")));
        host.layout_at(1100.0, 700.0);
        let show_layout_us = show_started.elapsed().as_micros();
        let row_count = {
            let dom = host.runner().dom();
            let dom = dom.borrow();
            count_class(&dom, dom.document(), "knot-outline-row")
        };
        let edit_started = Instant::now();
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("\n## Appended heading\n");
        });
        host.after_dispatch();
        host.layout_at(1100.0, 700.0);
        let edit_layout_us = edit_started.elapsed().as_micros();
        println!(
            "outline_probe source_bytes={source_bytes} heading_rows={row_count} show_layout_us={show_layout_us} edit_layout_us={edit_layout_us}"
        );
        assert_eq!(row_count, 200);
    }

    #[test]
    fn command_shortcuts_reach_save_and_save_as() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("shortcut.djot");
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.layout_at(900.0, 640.0);
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("edit");
        });
        host.set_modifiers(Modifiers {
            ctrl: true,
            shift: true,
            ..Modifiers::NONE
        });
        host.key_char("s");
        host.set_modifiers(Modifiers::NONE);
        assert!(
            host.state().save_as_popover.open,
            "Save As asks for its path"
        );
        assert!(focus_inside(&host, "knot-save-as-field"));
        host.key_injected(&path.to_string_lossy());
        host.press_key(&KeyPress::named(NamedKey::Enter));
        assert!(path.exists());
        assert!(std::fs::read_to_string(&path).unwrap().contains("edit"));
        assert!(!host.state().document().snapshot().dirty);
        assert!(!host.state().save_as_popover.open);

        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" again");
        });
        host.set_modifiers(Modifiers {
            ctrl: true,
            ..Modifiers::NONE
        });
        host.key_char("s");
        host.set_modifiers(Modifiers::NONE);
        assert!(!host.state().document().snapshot().dirty);
        assert!(std::fs::read_to_string(&path).unwrap().contains("again"));

        host.set_modifiers(Modifiers {
            ctrl: true,
            ..Modifiers::NONE
        });
        host.key_char("o");
        host.set_modifiers(Modifiers::NONE);
        assert!(
            host.state().open_popover.open,
            "Ctrl+O asks for a path to open"
        );
        assert!(focus_inside(&host, "knot-path-field"));
    }

    #[test]
    fn menu_edit_and_escape_restore_source_focus() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.update(|state| state.set_command_chrome(CommandChrome::ClientTitlebar));
        host.layout_at(1000.0, 640.0);
        assert!(host.click_on(&Selector::role("textbox").with_attr("aria-label", "Document text")));
        host.key_injected("draft");
        assert!(source_is_focused(host.runner()));

        host.press_key(&KeyPress::named(NamedKey::F10));
        assert!(host.click_on(&Selector::role("menuitem").with_attr("data-key", "group.edit")));
        assert!(host.click_on(&Selector::role("menuitem").with_attr("data-key", commands::UNDO)));
        assert!(source_is_focused(host.runner()));
        assert_eq!(host.state().document().snapshot().text, "");
        host.key_injected("after");
        assert_eq!(host.state().document().snapshot().text, "after");

        host.press_key(&KeyPress::named(NamedKey::F10));
        host.press_key(&KeyPress::named(NamedKey::Escape));
        assert!(source_is_focused(host.runner()));
        host.key_injected(" escape");
        assert_eq!(host.state().document().snapshot().text, "after escape");
    }

    #[test]
    fn client_menu_save_as_opens_focused_path_and_escape_returns_to_source() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        host.update(|state| state.set_command_chrome(CommandChrome::ClientTitlebar));
        host.layout_at(1000.0, 640.0);
        assert!(host.click_on(&Selector::role("textbox").with_attr("aria-label", "Document text")));
        host.key_injected("draft");
        assert!(host.click_on(&Selector::role("menuitem").with_attr("data-key", "group.file")));
        assert!(
            host.click_on(&Selector::role("menuitem").with_attr("data-key", commands::SAVE_AS))
        );
        assert!(host.state().save_as_popover.open);
        assert!(focus_inside(&host, "knot-save-as-field"));
        host.press_key(&KeyPress::named(NamedKey::Escape));
        assert!(!host.state().save_as_popover.open);
        assert!(source_is_focused(host.runner()));
        assert_eq!(host.state().document().snapshot().text, "draft");
    }

    #[test]
    fn failed_save_keeps_native_close_prompt_open() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("changed.djot");
        std::fs::write(&path, "# Original\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(900.0, 640.0);
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("draft");
        });
        std::fs::write(&path, "# External\n").unwrap();
        request_native_close(&mut host);
        assert!(!host.close_requested());
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(!host.close_requested());
        assert!(
            host.state()
                .message
                .as_deref()
                .unwrap()
                .contains("changed on disk")
        );
    }

    #[test]
    fn compare_captures_disk_and_buffer_without_writing_or_mutating_source() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("compare.djot");
        std::fs::write(&path, "buffer\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" edited");
        });
        let buffer_before = host.state().document().snapshot();
        std::fs::write(&path, "disk\n").unwrap();
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        let comparison = host
            .state()
            .entry()
            .comparison
            .as_ref()
            .expect("comparison snapshot");
        assert_eq!(comparison.buffer_text, buffer_before.text);
        assert_eq!(comparison.disk_text, "disk\n");
        assert!(comparison.disk_changed_since_baseline);
        assert_eq!(host.state().document().snapshot().text, buffer_before.text);
        assert_eq!(
            host.state().document().snapshot().selection,
            buffer_before.selection
        );
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "disk\n");

        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" later");
        });
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let panel = class_node(&dom, dom.document(), "knot-comparison").expect("comparison panel");
        assert!(text_content(&dom, panel).contains("Snapshot: stale"));
        drop(dom);
        assert!(host.click_on(&Selector::role("button").containing("Refresh comparison")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let panel = class_node(&dom, dom.document(), "knot-comparison").expect("comparison panel");
        assert!(text_content(&dom, panel).contains("Buffer snapshot matches current source"));
    }

    #[test]
    fn comparison_refreshes_explicitly_and_stays_with_its_document() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("refresh.djot");
        std::fs::write(&path, "first\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        std::fs::write(&path, "second\n").unwrap();
        assert_eq!(
            host.state().entry().comparison.as_ref().unwrap().disk_text,
            "first\n"
        );
        assert!(host.click_on(&Selector::role("button").containing("Refresh comparison")));
        assert_eq!(
            host.state().entry().comparison.as_ref().unwrap().disk_text,
            "second\n"
        );
        let compared = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert!(host.state().entry().comparison.is_none());
        assert!(host.state().entry().comparison_error.is_none());
        assert_eq!(
            host.state()
                .docs
                .doc(compared)
                .and_then(|entry| entry.comparison.as_ref())
                .map(|comparison| comparison.disk_text.as_str()),
            Some("second\n")
        );
    }

    #[test]
    fn missing_disk_replaces_the_old_comparison_with_an_error() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("missing.djot");
        std::fs::write(&path, "source\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        std::fs::remove_file(&path).unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        assert!(host.state().entry().comparison.is_none());
        assert!(
            host.state()
                .entry()
                .comparison_error
                .as_deref()
                .is_some_and(|error| error.contains("read"))
        );
    }

    #[test]
    fn comparison_renders_markup_as_plain_source_text() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("markup.djot");
        std::fs::write(&path, "<script>alert(1)</script>\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let pre = named_node(&dom, dom.document(), "pre").expect("comparison pre");
        assert!(text_content(&dom, pre).contains("<script>alert(1)</script>"));
        assert!(named_node(&dom, pre, "script").is_none());
    }

    #[test]
    fn compare_leaves_a_pending_dirty_close_untouched() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("pending-compare.djot");
        std::fs::write(&path, "source\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" edited");
        });
        host.layout_at(900.0, 640.0);
        request_native_close(&mut host);
        let before = host.state().document().snapshot();
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        assert_eq!(host.state().pending, Some(PendingAction::Quit));
        assert_eq!(host.state().document().snapshot().text, before.text);
        assert_eq!(
            host.state().document().snapshot().selection,
            before.selection
        );
    }

    #[test]
    fn inner_save_keeps_comparison_disk_text_historical() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("historical.djot");
        std::fs::write(&path, "original\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str(" edited");
        });
        host.layout_at(900.0, 640.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        assert!(host.click_on(&Selector::role("button").containing("Save")));
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "original\n edited");
        assert!(!host.state().document().snapshot().dirty);
        assert_eq!(
            host.state().entry().comparison.as_ref().unwrap().disk_text,
            "original\n"
        );
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let panel = class_node(&dom, dom.document(), "knot-comparison").expect("comparison panel");
        let rendered = text_content(&dom, panel);
        assert!(rendered.contains("Disk text was read when compared; refresh to read it again."));
        assert!(rendered.contains("Buffer snapshot matches current source"));
    }

    /// Compare shows its result in a Changes tile beside the documents,
    /// never inside the document's own tile.
    #[test]
    fn compare_shows_its_result_in_a_changes_tile() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("changes.djot");
        std::fs::write(&path, "source\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        assert!(host.click_on(&Selector::role("button").containing("Compare")));
        let tile = reading_tile(&host, ReadingKind::Changes, false);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let changes = class_node(&dom, dom.document(), "knot-changes").expect("the Changes tile");
        assert!(class_node(&dom, changes, "knot-comparison").is_some());
        assert_eq!(
            dom.attribute(changes, &Namespace::from(""), &LocalName::from("id")),
            Some(format!("knot-changes-{}", tile.0).as_str()),
        );
        let document =
            class_node(&dom, dom.document(), "knot-document-tile").expect("the document tile");
        assert!(
            class_node(&dom, document, "knot-comparison").is_none(),
            "the document tile holds no comparison"
        );
    }

    #[test]
    fn a_pinned_changes_tile_compares_its_own_document() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("a.djot");
        std::fs::write(&path, "a\n").unwrap();
        let mut host = harness(KnotDocumentSession::open(&path).unwrap());
        host.layout_at(1100.0, 700.0);
        let a = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Show changes")));
        assert!(host.click_on(&Selector::role("button").containing("Pin")));
        assert!(host.click_on(&Selector::role("button").containing("New")));
        let b = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Compare with disk")));
        let compared = |key| {
            host.state()
                .docs
                .doc(key)
                .is_some_and(|entry| entry.comparison.is_some())
        };
        assert!(compared(a), "the pinned tile compares its own document");
        assert!(!compared(b));
    }

    #[test]
    fn read_only_save_as_refusal_is_visible_and_does_not_write() {
        let temp = tempdir().unwrap();
        let path = temp.path().join("read-only.djot");
        let mut host = harness(KnotDocumentSession::read_only(SCRATCH_ADDRESS, "read only"));
        host.layout_at(900.0, 640.0);
        assert!(commands::disabled_reason(host.state(), commands::SAVE_AS).is_some());
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-save-as")));
        assert!(!host.state().save_as_popover.open);
        host.update(|state| {
            state.save_as_path = TextInput::new(path.to_string_lossy());
            assert!(
                !state.save_as(),
                "the lower-level write guard still refuses"
            );
        });
        assert!(!path.exists());
        assert_eq!(
            host.state().document().snapshot().write_posture,
            knot_document::KnotDocumentWritePostureV1::ReadOnly
        );
        assert!(host.state().message.as_deref().unwrap().contains("refused"));
    }

    #[test]
    fn catalog_status_uses_source_path_and_save_as_gets_a_new_id() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("documents");
        let catalog_root = temp.path().join("catalog");
        std::fs::create_dir(&root).unwrap();
        std::fs::create_dir(&catalog_root).unwrap();
        let original = root.join("original.djot");
        let saved_as = root.join("saved-as.djot");
        std::fs::write(&original, "source\n").unwrap();
        let catalog = KnotFileCatalog::open(&root, catalog_root.join("catalog.redb")).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&original).unwrap(), Some(catalog));
        host.layout_at(900.0, 640.0);
        let original_id = host
            .state()
            .entry()
            .catalog_id
            .clone()
            .expect("initial catalog id");

        host.update(|state| state.path = TextInput::new("path field edit"));
        host.after_dispatch();
        assert_eq!(
            host.state().entry().catalog_id.as_deref(),
            Some(original_id.as_str())
        );

        assert!(save_as_through(&mut host, &saved_as));
        let saved_id = host
            .state()
            .entry()
            .catalog_id
            .clone()
            .expect("Save As catalog id");
        assert_ne!(saved_id, original_id);
        assert_eq!(
            host.state().document().session().source_path(),
            Some(std::fs::canonicalize(&saved_as).unwrap().as_path())
        );
        assert!(saved_as.exists());
        assert!(
            host.state().entry().catalog_error.is_none(),
            "successful in-root Save As must not report a catalog error"
        );

        open_chip(&mut host, crate::status::CATALOG);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let workspace = class_node(&dom, dom.document(), "knot-workspace").expect("workspace");
        assert!(text_content(&dom, workspace).contains(&format!("Document ID: {saved_id}")));
        drop(dom);
        // Close the popover first: a click outside it only dismisses it.
        host.press_key(&KeyPress::named(NamedKey::Escape));
        assert_eq!(host.state().status_bar.open, None);
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert!(host.state().entry().catalog_id.is_none());
        assert!(host.state().entry().catalog_error.is_none());
    }

    #[test]
    fn catalog_failure_does_not_block_outside_save_or_dirty_close() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("documents");
        let catalog_root = temp.path().join("catalog");
        std::fs::create_dir(&root).unwrap();
        std::fs::create_dir(&catalog_root).unwrap();
        let outside = temp.path().join("outside.djot");
        std::fs::write(&outside, "").unwrap();
        let catalog = KnotFileCatalog::open(&root, catalog_root.join("catalog.redb")).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&outside).unwrap(), Some(catalog));
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("draft");
        });
        assert!(host.state().document().snapshot().dirty);
        host.layout_at(900.0, 640.0);
        request_native_close(&mut host);
        assert!(host.click_on(&Selector::role("button").with_attr("id", "knot-confirm-save")));
        assert!(host.close_requested());
        assert_eq!(std::fs::read_to_string(&outside).unwrap(), "draft");
        assert!(host.state().entry().catalog_id.is_none());
        assert!(
            host.state()
                .entry()
                .catalog_error
                .as_deref()
                .is_some_and(|error| error.contains("outside catalog root"))
        );
        open_chip(&mut host, crate::status::CATALOG);
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let workspace = class_node(&dom, dom.document(), "knot-workspace").expect("workspace");
        assert!(text_content(&dom, workspace).contains("Not catalogued:"));
    }

    #[test]
    fn retry_catalog_recovers_an_in_root_file_without_mutating_document_state() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("documents");
        let catalog_root = temp.path().join("catalog");
        std::fs::create_dir(&root).unwrap();
        std::fs::create_dir(&catalog_root).unwrap();
        let path = root.join("recover.djot");
        std::fs::write(&path, "recover me\n").unwrap();
        let session = KnotDocumentSession::open(&path).unwrap();
        std::fs::remove_file(&path).unwrap();
        let catalog = KnotFileCatalog::open(&root, catalog_root.join("catalog.redb")).unwrap();
        let mut host = harness_with_catalog(session, Some(catalog));
        assert!(host.state().entry().catalog_id.is_none());
        assert!(host.state().entry().catalog_error.is_some());
        let before = host.state().document().snapshot();

        host.update(|state| state.path = TextInput::new("temporary path edit"));
        host.after_dispatch();
        assert!(host.state().entry().catalog_id.is_none());
        assert_eq!(host.state().document().snapshot(), before);

        std::fs::write(&path, "recover me\n").unwrap();
        host.layout_at(900.0, 640.0);
        open_chip(&mut host, crate::status::CATALOG);
        assert!(host.click_on(&Selector::role("button").containing("Retry catalog")));
        assert!(host.state().entry().catalog_id.is_some());
        assert!(host.state().entry().catalog_error.is_none());
        assert_eq!(host.state().document().snapshot(), before);
    }

    #[test]
    fn opening_a_site_at_startup_uses_its_format_and_default_port() {
        let temp = tempdir().unwrap();
        let root = temp.path().join("gemini");
        let site = knot_site::Site::create_for(&root, knot_site::SiteFormat::Gemini).unwrap();
        let index = site.page_path(site.config.format.index_file()).unwrap();
        let state = DesktopState::with_catalog(
            KnotDocumentSession::open(index).unwrap(),
            WindowCommands::new(),
            Some(root),
            None,
        );

        assert_eq!(state.scroll.format, knot_site::SiteFormat::Gemini);
        assert_eq!(state.scroll.port.text(), "1965");
        assert_eq!(
            state.scroll.current_site().unwrap().site.config.format,
            knot_site::SiteFormat::Gemini
        );
    }

    type ReviewHarness = Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>;

    fn review_fixture(source: &str) -> (tempfile::TempDir, PathBuf, ReviewHarness) {
        let temp = tempdir().unwrap();
        let root = temp.path().join("notes");
        std::fs::create_dir(&root).unwrap();
        let path = root.join("review.djot");
        std::fs::write(&path, source).unwrap();
        let catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let mut host =
            harness_with_catalog(KnotDocumentSession::open(&path).unwrap(), Some(catalog));
        host.layout_at(1000.0, 800.0);
        assert!(host.click_on(&Selector::role("button").containing("Show changes")));
        (temp, path, host)
    }

    fn review_text(host: &ReviewHarness) -> String {
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let panel = class_node(&dom, dom.document(), "knot-review").expect("review panel");
        text_content(&dom, panel)
    }

    #[test]
    fn saved_revision_review_excludes_dirty_edits_and_survives_inner_save_until_refresh() {
        let source = "<script>saved α</script>\n";
        let (_temp, path, mut host) = review_fixture(source);
        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("UNSAVED");
            state.path = TextInput::new("unrelated future target");
        });
        let before = host.state().document().snapshot();
        assert!(before.dirty);
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        assert_eq!(
            host.state().entry().prepared_capture.as_ref().unwrap().body,
            source.as_bytes()
        );
        assert_eq!(
            host.state().entry().prepared_capture_source_path.as_deref(),
            Some(std::fs::canonicalize(&path).unwrap().as_path())
        );
        assert_eq!(host.state().document().snapshot(), before);
        assert_eq!(std::fs::read_to_string(&path).unwrap(), source);
        let rendered = review_text(&host);
        assert!(rendered.contains(source));
        assert!(!rendered.contains("UNSAVED"));
        assert!(rendered.contains("Unsaved changes are excluded"));
        assert!(rendered.contains("Reviewing does not store or share bytes."));
        host.update(|state| {
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Save)
                .unwrap();
        });
        host.after_dispatch();
        assert_eq!(
            host.state().entry().prepared_capture.as_ref().unwrap().body,
            source.as_bytes()
        );
        assert!(review_text(&host).contains("Editor differs"));
        assert!(host.click_on(&Selector::role("button").containing("Refresh saved revision")));
        assert_eq!(
            host.state().entry().prepared_capture.as_ref().unwrap().body,
            std::fs::read(&path).unwrap()
        );
        assert!(review_text(&host).contains("UNSAVED"));
        assert!(host.click_on(&Selector::role("button").containing("Discard saved revision")));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(host.state().entry().prepared_capture_error.is_none());
    }

    #[test]
    fn saved_revision_failed_refresh_replaces_old_bytes_and_preserves_document() {
        let (_temp, path, mut host) = review_fixture("old reading");
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        let before = host.state().document().snapshot();
        for bytes in [vec![0xff, 0xfe], b"larger than the cap".to_vec()] {
            std::fs::write(&path, &bytes).unwrap();
            host.update(|state| state.set_capture_limit(4));
            assert!(host.click_on(&Selector::role("button").containing("Refresh saved revision")));
            assert!(host.state().entry().prepared_capture.is_none());
            assert!(host.state().entry().prepared_capture_source_path.is_none());
            assert!(host.state().entry().prepared_capture_error.is_some());
            assert!(!review_text(&host).contains("old reading"));
            assert_eq!(host.state().document().snapshot(), before);
            assert_eq!(std::fs::read(&path).unwrap(), bytes);
        }
        std::fs::remove_file(&path).unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Refresh saved revision")));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(
            host.state()
                .entry()
                .prepared_capture_error
                .as_deref()
                .unwrap()
                .contains("unavailable")
        );
        assert_eq!(host.state().document().snapshot(), before);
    }

    #[test]
    fn saved_revision_clears_only_after_successful_source_transitions() {
        let (_temp, path, mut host) = review_fixture("saved");
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        let saved_as = path.with_file_name("copy.djot");
        assert!(save_as_through(&mut host, &saved_as));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        host.update(|state| {
            state.path = TextInput::new(path.with_file_name("absent.djot").to_string_lossy())
        });
        assert!(confirm_open(&mut host));
        assert!(host.state().entry().prepared_capture.is_some());
        let copy = host.state().focused_key().unwrap();
        open_through_path(&mut host, &path);
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(
            host.state()
                .docs
                .doc(copy)
                .is_some_and(|entry| entry.prepared_capture.is_some())
        );
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        assert!(host.click_on(&Selector::role("button").containing("Reload")));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        let reviewed = host.state().focused_key().unwrap();
        assert!(host.click_on(&Selector::role("button").containing("New")));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(!host.click_on(&Selector::role("button").containing("Review saved revision")));
        assert!(
            host.state()
                .docs
                .doc(reviewed)
                .is_some_and(|entry| entry.prepared_capture.is_some())
        );
    }

    #[test]
    fn saved_revision_refuses_a_binding_rebound_away_from_the_session_source() {
        let (_temp, path, mut host) = review_fixture("original");
        let moved = path.with_file_name("moved.djot");
        std::fs::rename(&path, &moved).unwrap();
        host.update(|state| {
            let id = state.entry().catalog_id.clone().unwrap();
            state.catalog.as_mut().unwrap().rebind(&id, &moved).unwrap();
        });
        std::fs::write(&path, "replacement").unwrap();
        assert!(host.click_on(&Selector::role("button").containing("Review saved revision")));
        assert!(host.state().entry().prepared_capture.is_none());
        assert!(
            host.state()
                .entry()
                .prepared_capture_error
                .as_deref()
                .unwrap()
                .contains("no longer matches")
        );
        assert_eq!(host.state().catalog.as_ref().unwrap().records().len(), 1);
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "replacement");
        assert_eq!(std::fs::read_to_string(&moved).unwrap(), "original");
    }

    struct GatePort {
        target: KnotRetainTargetV1,
        calls: AtomicUsize,
        entered: mpsc::Sender<()>,
        replies: Mutex<mpsc::Receiver<Result<KnotRetainReceiptV1, KnotRetainError>>>,
        seen: Mutex<Vec<KnotFileRevisionV1>>,
    }

    impl KnotRetainPort for GatePort {
        fn target(&self) -> &KnotRetainTargetV1 {
            &self.target
        }

        fn retain_reviewed(
            &self,
            expected_target: &KnotRetainTargetV1,
            revision: KnotFileRevisionV1,
        ) -> Result<KnotRetainReceiptV1, KnotRetainError> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            if expected_target != &self.target {
                return Err(KnotRetainError("wrong target".into()));
            }
            self.seen.lock().unwrap().push(revision);
            let _ = self.entered.send(());
            self.replies
                .lock()
                .unwrap()
                .recv()
                .unwrap_or_else(|_| Err(KnotRetainError("reply channel disconnected".into())))
        }
    }

    fn target(label: &str, byte: u8) -> KnotRetainTargetV1 {
        KnotRetainTargetV1 {
            persona: knot_capture::KnotPersonaDisplayV1 {
                stable_id: format!("persona:{byte}"),
                label: label.into(),
            },
            space_id: [byte; 32],
            writer: [byte + 1; 32],
            encryption: knot_capture::KnotRetainEncryptionV1::PersonalVaultV1,
        }
    }

    #[test]
    fn background_busy_includes_both_retention_states() {
        let mut state = DesktopState::new(
            KnotDocumentSession::scratch("scratch:retention-busy", ""),
            WindowCommands::new(),
        );
        assert!(!state.background_busy());

        let (_sender, receiver) = mpsc::channel();
        state.retention_receiver = Some(receiver);
        assert!(
            state.background_busy(),
            "a pending receiver keeps wait armed"
        );

        state.retention_receiver = None;
        state.retention_busy = Some(RetentionRequest {
            target: target("Busy persona", 3),
            document_id: "file:busy".into(),
        });
        assert!(
            state.background_busy(),
            "an active request keeps wait armed"
        );
    }

    fn revision(id: &str, body: &[u8]) -> KnotFileRevisionV1 {
        KnotFileRevisionV1 {
            document_id: id.into(),
            title: id.into(),
            media_type: "text/x-djot".into(),
            body: body.to_vec(),
        }
    }

    fn gated_port(
        target: KnotRetainTargetV1,
    ) -> (
        Arc<GatePort>,
        mpsc::Receiver<()>,
        mpsc::Sender<Result<KnotRetainReceiptV1, KnotRetainError>>,
    ) {
        let (entered_send, entered) = mpsc::channel();
        let (reply, replies) = mpsc::channel();
        (
            Arc::new(GatePort {
                target,
                calls: AtomicUsize::new(0),
                entered: entered_send,
                replies: Mutex::new(replies),
                seen: Mutex::new(Vec::new()),
            }),
            entered,
            reply,
        )
    }

    fn retention_harness(
        ports: Vec<Arc<dyn KnotRetainPort>>,
        reviewed: KnotFileRevisionV1,
    ) -> Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView> {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_retention_targets(ports, wake);
            state.entry_mut().prepared_capture = Some(reviewed);
            state.retention_selected = Some(0);
        });
        host
    }

    /// The text of the open chip's popover.
    fn popover_text(host: &DesktopHarness) -> String {
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let detail = class_node(&dom, dom.document(), "knot-status-detail").expect("a popover");
        text_content(&dom, detail)
    }

    /// Step 5d: everything the retention and catalog blocks showed is in the
    /// retention and catalog chips' popovers.
    #[test]
    fn every_fact_the_retention_and_catalog_blocks_showed_is_in_a_popover() {
        let chosen = target("Facts persona", 1);
        let (port, _, _) = gated_port(chosen.clone());
        let mut host = retention_harness(vec![port], revision("file:facts", b"exact bytes"));
        host.update(|state| {
            state.retention_busy = Some(RetentionRequest {
                target: chosen.clone(),
                document_id: "file:facts".into(),
            });
            state.retention_error = Some("the grant was revoked".into());
            state.retention_receipt = Some(KnotRetainReceiptV1 {
                target: chosen.clone(),
                document_id: "file:facts".into(),
                operation: [7; 32],
                already_retained: true,
            });
        });
        host.layout_at(1100.0, 700.0);
        open_chip(&mut host, crate::status::RETENTION);
        let (space, writer) = (hex32(&chosen.space_id), hex32(&chosen.writer));
        let (label, stable) = (&chosen.persona.label, &chosen.persona.stable_id);
        let facts = [
            "Retain reviewed revision".to_owned(),
            "Choose a persona and space".to_owned(),
            retention_target_label(&chosen, &host.state().retention_targets),
            format!("Persona: {label}"),
            format!("Persona stable ID: {stable}"),
            format!("Space ID: {space}"),
            format!("Writer ID: {writer}"),
            format!("Encryption: {}", encryption_label(chosen.encryption)),
            format!("Retaining file:facts in {label} ({stable}, space {space}, writer {writer})…"),
            "the grant was revoked".to_owned(),
            format!(
                "Last confirmed retention: file:facts in {label} ({stable}, {}, space {space}, \
                 writer {writer}, operation {}); already retained",
                encryption_label(chosen.encryption),
                hex32(&[7; 32])
            ),
        ];
        let text = popover_text(&host);
        for fact in facts {
            assert!(
                text.contains(&fact),
                "{fact:?} is not in the retention popover: {text}"
            );
        }

        // The empty states: no destinations, none chosen.
        let mut empty = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = empty.wake();
        empty.update(|state| state.set_retention_targets(vec![], wake));
        empty.layout_at(1100.0, 700.0);
        open_chip(&mut empty, crate::status::RETENTION);
        let text = popover_text(&empty);
        assert!(
            text.contains("No storage destinations available."),
            "{text}"
        );
        assert!(text.contains("No destination selected."), "{text}");

        // A catalog with a document it cannot bind yet.
        let temp = tempdir().unwrap();
        let root = temp.path().join("documents");
        std::fs::create_dir(&root).unwrap();
        let catalog = KnotFileCatalog::open(&root, temp.path().join("catalog.redb")).unwrap();
        let mut unsaved = harness_with_catalog(
            KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""),
            Some(catalog),
        );
        unsaved.layout_at(1100.0, 700.0);
        open_chip(&mut unsaved, crate::status::CATALOG);
        assert!(popover_text(&unsaved).contains("Not catalogued: unsaved document"));
    }

    fn drain_wake(host: &mut Harness<DesktopState, fn(&DesktopState) -> DesktopView, DesktopView>) {
        for _ in 0..1_000 {
            if host.process_wake() {
                return;
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        panic!("retention worker did not wake the harness");
    }

    #[test]
    fn retention_worker_freezes_the_review_refuses_duplicates_and_preserves_original_receipts() {
        let original = revision("file:original", b"saved bytes");
        let first_target = target("First", 1);
        let second_target = target("Second", 3);
        let (first, entered, reply) = gated_port(first_target.clone());
        let (second, _, _) = gated_port(second_target.clone());
        let mut host = retention_harness(vec![first.clone(), second], original.clone());
        let wake = host.wake();

        host.update(|state| state.retain_reviewed(wake));
        entered
            .recv_timeout(std::time::Duration::from_secs(1))
            .unwrap();
        let duplicate_wake = host.wake();
        host.update(|state| {
            state.retain_reviewed(duplicate_wake);
            state.retention_selected = Some(1);
            state.entry_mut().prepared_capture = Some(revision("file:replacement", b"new review"));
        });
        assert_eq!(first.calls.load(Ordering::SeqCst), 1);
        assert!(
            host.state()
                .retention_error
                .as_deref()
                .unwrap()
                .contains("already")
        );
        assert_eq!(first.seen.lock().unwrap().as_slice(), &[original.clone()]);

        host.update(|state| {
            state
                .document_mut()
                .session_mut()
                .input_mut()
                .unwrap()
                .insert_str("unsaved");
            state.discard_close = true;
        });
        host.request_close(CloseRequest::Native);
        assert!(!host.state().discard_close);
        assert!(!host.hidden());
        assert!(!host.close_requested());
        assert!(
            host.state()
                .message
                .as_deref()
                .unwrap()
                .contains("retention")
        );

        reply
            .send(Ok(KnotRetainReceiptV1 {
                target: first_target.clone(),
                document_id: original.document_id.clone(),
                operation: [9; 32],
                already_retained: false,
            }))
            .unwrap();
        drain_wake(&mut host);
        assert_eq!(
            Arc::strong_count(&first),
            2,
            "worker released its owner handle"
        );
        assert_eq!(host.state().retention_selected, Some(1));
        assert_eq!(
            host.state()
                .entry()
                .prepared_capture
                .as_ref()
                .unwrap()
                .document_id,
            "file:replacement"
        );
        assert_eq!(
            host.state().retention_receipt.as_ref().unwrap().target,
            first_target
        );
        assert_eq!(
            host.state().retention_receipt.as_ref().unwrap().document_id,
            "file:original"
        );
        host.request_close(CloseRequest::Native);
        assert!(!host.close_requested());
        assert!(matches!(host.state().pending, Some(PendingAction::Quit)));
    }

    #[test]
    fn retention_failure_and_disconnect_clear_busy_state_for_an_explicit_retry() {
        let reviewed = revision("file:retry", b"exact bytes");
        let selected = target("Retry", 5);
        let (port, entered, reply) = gated_port(selected);
        let mut host = retention_harness(vec![port.clone()], reviewed);
        let wake = host.wake();

        host.update(|state| state.retain_reviewed(wake));
        entered
            .recv_timeout(std::time::Duration::from_secs(1))
            .unwrap();
        reply.send(Err(KnotRetainError("denied".into()))).unwrap();
        drain_wake(&mut host);
        assert!(host.state().retention_busy.is_none());
        assert!(
            host.state()
                .retention_error
                .as_deref()
                .unwrap()
                .contains("denied")
        );

        let wake = host.wake();
        host.update(|state| state.retain_reviewed(wake));
        entered
            .recv_timeout(std::time::Duration::from_secs(1))
            .unwrap();
        drop(reply);
        drain_wake(&mut host);
        assert!(host.state().retention_busy.is_none());
        assert!(
            host.state()
                .retention_error
                .as_deref()
                .unwrap()
                .contains("could not be confirmed")
        );
        assert_eq!(port.calls.load(Ordering::SeqCst), 2);
    }

    #[test]
    fn retention_rejects_a_mismatched_receipt_without_creating_a_confirmed_result() {
        let reviewed = revision("file:expected", b"exact bytes");
        let selected = target("Expected", 7);
        let (port, entered, reply) = gated_port(selected);
        let mut host = retention_harness(vec![port], reviewed);
        let wake = host.wake();
        host.update(|state| state.retain_reviewed(wake));
        entered
            .recv_timeout(std::time::Duration::from_secs(1))
            .unwrap();
        reply
            .send(Ok(KnotRetainReceiptV1 {
                target: target("Wrong", 8),
                document_id: "file:other".into(),
                operation: [8; 32],
                already_retained: false,
            }))
            .unwrap();
        drain_wake(&mut host);
        assert!(host.state().retention_receipt.is_none());
        assert!(
            host.state()
                .retention_error
                .as_deref()
                .unwrap()
                .contains("identity changed")
        );
    }

    #[test]
    fn retention_never_auto_selects_or_starts_a_write() {
        let reviewed = revision("file:manual", b"exact bytes");
        let (port, _entered, _reply) = gated_port(target("Manual", 11));
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_retention_targets(vec![port.clone()], wake.clone());
            state.entry_mut().prepared_capture = Some(reviewed);
            state.retain_reviewed(wake);
        });
        assert!(host.state().retention_selected.is_none());
        assert!(
            host.state()
                .retention_error
                .as_deref()
                .unwrap()
                .contains("Choose a persona")
        );
        assert_eq!(port.calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn retention_target_rows_select_the_matching_same_persona_space_and_show_full_detail() {
        let reviewed = revision("file:targets", b"exact bytes");
        let first_target = target("Shared persona", 1);
        let mut second_target = target("Shared persona", 3);
        second_target.persona.stable_id = first_target.persona.stable_id.clone();
        let mut third_target = target("Shared persona", 9);
        third_target.persona.stable_id = first_target.persona.stable_id.clone();
        third_target.space_id = second_target.space_id;
        third_target.writer = [5; 32];
        let (first, _, _) = gated_port(first_target);
        let (second, _, _) = gated_port(second_target.clone());
        let (third, _, _) = gated_port(third_target);
        let mut host = retention_harness(vec![first, second, third], reviewed);
        host.update(|state| state.retention_selected = None);
        host.layout_at(900.0, 640.0);

        open_chip(&mut host, crate::status::RETENTION);
        assert!(host.click_on(&Selector::role("button").with_attr("data-retention-target", "1")));
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let detail = class_node(&dom, dom.document(), "knot-retention-selected").unwrap();
        let detail_text = text_content(&dom, detail);
        assert!(detail_text.contains("Persona stable ID: persona:1"));
        assert!(detail_text.contains(&format!("Space ID: {}", hex32(&second_target.space_id))));
        assert!(detail_text.contains(&format!("Writer ID: {}", hex32(&second_target.writer))));
        assert!(detail_text.contains("Encryption: Personal vault encryption"));
        let selected = attr_node(&dom, dom.document(), "data-retention-target", "1").unwrap();
        assert_eq!(
            dom.attribute(
                selected,
                &Namespace::from(""),
                &LocalName::from("aria-pressed")
            ),
            Some("true".into())
        );
        let unselected = attr_node(&dom, dom.document(), "data-retention-target", "0").unwrap();
        assert_eq!(
            dom.attribute(
                unselected,
                &Namespace::from(""),
                &LocalName::from("aria-pressed")
            ),
            Some("false".into())
        );
        let targets = class_node(&dom, dom.document(), "knot-retention-targets").unwrap();
        let targets_text = text_content(&dom, targets);
        assert!(targets_text.contains("writer 04040404"));
        assert!(targets_text.contains("writer 05050505"));
    }

    #[test]
    fn retention_without_destinations_offers_no_action() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_retention_targets(vec![], wake);
            state.entry_mut().prepared_capture = Some(revision("file:manual", b"saved"));
        });
        host.layout_at(900.0, 640.0);
        // With the popover open, a missing action is really missing.
        open_chip(&mut host, crate::status::RETENTION);
        assert!(!host.click_on(&Selector::role("button").containing("Retain reviewed revision")));
        assert!(host.state().retention_busy.is_none());
        assert!(host.state().retention_selected.is_none());
        let dom = host.runner().dom();
        let dom = dom.borrow();
        let detail = class_node(&dom, dom.document(), "knot-retention-selected").unwrap();
        assert!(text_content(&dom, detail).contains("No destination selected."));
    }

    #[test]
    fn disconnected_worker_completion_releases_the_close_guard() {
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let (sender, receiver) = mpsc::channel();
        drop(sender);
        host.update(|state| {
            state.retention_receiver = Some(receiver);
            state.retention_busy = Some(RetentionRequest {
                target: target("Disconnected", 12),
                document_id: "file:manual".into(),
            });
            state.drain_retention();
        });
        assert!(host.state().retention_busy.is_none());
        assert!(
            host.state()
                .retention_error
                .as_ref()
                .unwrap()
                .contains("uncertain")
        );
        host.request_close(CloseRequest::Native);
        assert!(host.close_requested());
    }

    #[test]
    fn restart_restores_exact_document_candidate_without_changing_original() {
        let temp = tempdir().unwrap();
        let original = temp.path().join("original.djot");
        std::fs::write(&original, "aéz").unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let mut first = harness(KnotDocumentSession::open(&original).unwrap());
        let wake = first.wake();
        first.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert("!".into())))
                .unwrap();
            let selection = cambium::CaretSelection {
                anchor: cambium::CaretPosition {
                    byte: 4,
                    affinity: cambium::CaretAffinity::Upstream,
                },
                focus: cambium::CaretPosition {
                    byte: 1,
                    affinity: cambium::CaretAffinity::Downstream,
                },
            };
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::SetSelection(
                    selection,
                )))
                .unwrap();
            state.sync_recovery();
            state.recovery.take().unwrap().shutdown().unwrap();
        });
        let wanted = first.state().document().snapshot();
        assert_eq!(std::fs::read_to_string(&original).unwrap(), "aéz");
        drop(first);

        let mut second = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = second.wake();
        second.update(|state| state.set_recovery_path(Some(root), wake));
        let item = second.state().recovery.as_ref().unwrap().records[0].clone();
        let first_key = second.state().focused_key().unwrap();
        second.layout_at(900.0, 640.0);
        open_chip(&mut second, crate::status::RECOVERY);
        assert!(second.click_on(&Selector::role("button").containing("Restore")));
        let candidate_key = second.state().focused_key().unwrap();
        assert_ne!(first_key, candidate_key);
        let recovered = second.state().document().snapshot();
        assert_eq!(recovered.text, wanted.text);
        assert_eq!(recovered.selection, wanted.selection);
        assert_eq!(
            recovered.write_posture,
            knot_document::KnotDocumentWritePostureV1::Scratch
        );
        second.update(|state| state.restore_recovery(item.id));
        assert_eq!(second.state().focused_key(), Some(candidate_key));
        second.update(|state| state.compare_recovery(item.id));
        let compared = second
            .state()
            .docs
            .doc(candidate_key)
            .unwrap()
            .comparison
            .as_ref()
            .unwrap();
        assert_eq!(compared.buffer_text, wanted.text);
        assert_eq!(compared.disk_text, "aéz");
        assert_eq!(std::fs::read_to_string(&original).unwrap(), "aéz");
        let destination = temp.path().join("saved-copy.djot");
        second.update(|state| {
            state.save_as_path = TextInput::new(destination.to_string_lossy());
            assert!(state.save_as());
        });
        assert_eq!(std::fs::read_to_string(&destination).unwrap(), wanted.text);
        assert_eq!(std::fs::read_to_string(&original).unwrap(), "aéz");
        assert!(second.state().recovery.as_ref().unwrap().records.is_empty());
    }

    #[test]
    fn discard_one_dirty_tab_keeps_other_document_recovery() {
        let temp = tempdir().unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "first".into(),
                )))
                .unwrap();
            state.sync_recovery();
            state.new_document();
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "second".into(),
                )))
                .unwrap();
            state.sync_recovery();
            state.recovery.as_mut().unwrap().flush().unwrap();
            let second = state.focused_key().unwrap();
            state.pending = Some(PendingAction::CloseDocument(second));
            state.confirm_discard();
            state.recovery.as_mut().unwrap().flush().unwrap();
            assert_eq!(state.dirty_documents().len(), 1);
        });
        let store =
            crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
        let records = store.list().records;
        assert_eq!(records.len(), 1);
        assert_eq!(records[0].source_text, "first");
    }

    #[test]
    fn failed_save_and_canceled_close_keep_the_recovery_copy() {
        let temp = tempdir().unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    "unsaved".into(),
                )))
                .unwrap();
            state.sync_recovery();
            state.recovery.as_mut().unwrap().flush().unwrap();
            state.save_as_path = TextInput::new(
                temp.path()
                    .join("missing")
                    .join("bad.djot")
                    .to_string_lossy(),
            );
            assert!(!state.save_as());
            let key = state.focused_key().unwrap();
            state.pending = Some(PendingAction::CloseDocument(key));
            state.cancel_pending();
            assert_eq!(state.focused_key(), Some(key));
        });
        let store =
            crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
        let records = store.list().records;
        assert_eq!(records.len(), 1);
        assert_eq!(records[0].source_text, "unsaved");
    }

    #[test]
    fn undo_to_clean_resolves_stale_file_and_scratch_recovery() {
        for file_backed in [false, true] {
            let temp = tempdir().unwrap();
            let root = temp.path().canonicalize().unwrap().join("recovery");
            let session = if file_backed {
                let path = temp.path().join("source.djot");
                std::fs::write(&path, "base").unwrap();
                KnotDocumentSession::open(path).unwrap()
            } else {
                KnotDocumentSession::scratch(SCRATCH_ADDRESS, "")
            };
            let mut host = harness(session);
            let wake = host.wake();
            host.update(|state| {
                state.set_recovery_path(Some(root.clone()), wake);
                state
                    .document_mut()
                    .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                        "edit".into(),
                    )))
                    .unwrap();
                state.sync_recovery();
                state.recovery.as_mut().unwrap().flush().unwrap();
                state
                    .document_mut()
                    .apply(KnotDocumentIntentV1::Edit(TextCommand::Undo))
                    .unwrap();
                assert!(!state.document().snapshot().dirty);
                state.sync_recovery();
                state.recovery.as_mut().unwrap().flush().unwrap();
            });
            let store =
                crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
            assert!(store.list().records.is_empty());
        }
    }

    #[test]
    fn sealed_style_scratch_and_read_only_projection_are_not_copied() {
        let temp = tempdir().unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let mut host = harness(KnotDocumentSession::read_only(
            "scratch:untitled",
            "read only",
        ));
        let wake = host.wake();
        host.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state.open_entry(DocumentEntry::new(KnotDocumentSession::scratch(
                "vault:sealed-note",
                "private",
            )));
            state
                .document_mut()
                .apply(KnotDocumentIntentV1::Edit(TextCommand::Insert(
                    " edit".into(),
                )))
                .unwrap();
            state.sync_recovery();
            state.recovery.as_mut().unwrap().flush().unwrap();
            assert!(
                state
                    .docs
                    .docs()
                    .all(|(_, entry)| entry.recovery_id.is_none())
            );
        });
        let store =
            crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
        assert!(store.list().records.is_empty());
    }

    #[test]
    fn empty_restored_candidate_still_requires_explicit_discard() {
        let temp = tempdir().unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let id = RecoveryId::new();
        {
            let store =
                crate::recovery::RecoveryStore::open(&root, RecoveryRetention::default()).unwrap();
            store
                .upsert(RecoveryRecord::new(id, String::new(), "Djot"))
                .unwrap();
        }
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state.restore_recovery(id);
            let key = state.focused_key().unwrap();
            assert!(state.entry().recovery_candidate);
            assert_eq!(state.dirty_documents(), vec![key]);
            state.pending = Some(PendingAction::CloseDocument(key));
            state.cancel_pending();
            assert!(state.docs.doc(key).is_some());
            state.pending = Some(PendingAction::CloseDocument(key));
            state.confirm_discard();
            assert!(state.docs.doc(key).is_none());
        });
        let store =
            crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
        assert!(store.list().records.is_empty());
    }

    #[test]
    fn reload_after_explicit_discard_opens_original_without_writing_it() {
        let temp = tempdir().unwrap();
        let root = temp.path().canonicalize().unwrap().join("recovery");
        let original = temp.path().join("original.djot");
        std::fs::write(&original, "disk text").unwrap();
        let id = RecoveryId::new();
        {
            let store =
                crate::recovery::RecoveryStore::open(&root, RecoveryRetention::default()).unwrap();
            let mut record = RecoveryRecord::new(id, "recovered text".into(), "Djot");
            record.original_path = Some(original.clone());
            store.upsert(record).unwrap();
        }
        let mut host = harness(KnotDocumentSession::scratch(SCRATCH_ADDRESS, ""));
        let wake = host.wake();
        host.update(|state| {
            state.set_recovery_path(Some(root.clone()), wake);
            state.restore_recovery(id);
            let candidate = state.focused_key().unwrap();
            state.pending = Some(PendingAction::Reload);
            state.confirm_discard();
            assert!(state.docs.doc(candidate).is_none());
            assert_eq!(state.document().snapshot().text, "disk text");
            assert!(!state.entry().recovery_candidate);
        });
        assert_eq!(std::fs::read_to_string(&original).unwrap(), "disk text");
        let store =
            crate::recovery::RecoveryStore::open(root, RecoveryRetention::default()).unwrap();
        assert!(store.list().records.is_empty());
    }
}
