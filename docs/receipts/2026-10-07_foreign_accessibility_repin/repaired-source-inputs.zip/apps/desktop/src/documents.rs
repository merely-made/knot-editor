// Copyright 2026 Mark Alan Boykin
// SPDX-License-Identifier: MPL-2.0

//! The desktop's open documents and the tiles that show them.
//!
//! An entry is keyed by a runtime [`DocKey`] that no Save As changes, and a
//! tile names what it shows by its [`TileRole`]. The Workbench tree is only
//! presentation: it holds tiles, never documents, so closing a document's
//! tile and dropping its entry happen together here, never through the tree
//! alone. A duplicate open resolves by [`DocIdentity`] (the catalog id when
//! the file is bound, else its canonical path) and activates the open entry
//! instead of making a second writable session. A scratch document has no
//! identity to collide on.
//!
//! The payload `D` is whatever the application keeps per document; the
//! bookkeeping here does not look inside it, which is what lets it be tested
//! alone.

use std::collections::{BTreeMap, HashMap};
use std::path::PathBuf;

use workbench::{
    ContentSource, Edge, Tile, TileEvent, TileId, TileTree, Workspace, WorkspaceEvent,
};

/// The runtime key of one open document.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct DocKey(pub u64);

/// The runtime key of one open site. It names the site's entry, not its
/// folder, so a folder opened again gets a new key.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct SiteKey(pub u64);

/// What makes two opens the same document.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DocIdentity {
    Catalog(String),
    Path(PathBuf),
    Scratch,
}

/// Which reading a reading tile shows.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ReadingKind {
    Outline,
    Preview,
    Folded,
    Readings,
    Changes,
    /// Outgoing links and backlinks from documents currently open in this window.
    Links,
    /// The Titan or Spartan composer of its document.
    Submit,
}

/// What a tile shows.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum TileRole {
    Document(DocKey),
    /// A reading follows the focused document unless pinned to one.
    Reading {
        kind: ReadingKind,
        pinned: Option<DocKey>,
    },
    Navigator,
    /// The shared Mere graph view over this host's catalog and open documents.
    Graph,
    /// A site page's metadata form. Its draft lives with the site, so the
    /// tile needs no tab of the page's source.
    Metadata {
        site: SiteKey,
        page: String,
    },
    /// An open site: its pages, publishing and serving.
    Site(SiteKey),
}

/// The Workbench lane every Knot tile rides in.
pub const TILE_KIND: &str = "knot";

/// The singleton Graph's reserved tile identity. Knot uses its stable
/// `data-tile` value to exempt only that Workbench content slot from the
/// renderer-hostile overflow topology around the shared Mere view.
const GRAPH_TILE_ID: TileId = TileId(u64::MAX);
pub(crate) const GRAPH_TILE_ID_ATTR: &str = "18446744073709551615";

/// The share of its split the Navigator opens at: about a quarter, the rest
/// going to the documents (Mark's ruling, 2026-09-26). The divider moves it.
pub const NAVIGATOR_SHARE: f32 = 0.25;

struct Entry<D> {
    identity: DocIdentity,
    tile: TileId,
    doc: D,
}

/// Open documents, their tiles, and which document has the focus.
pub struct DocumentWorkspace<D> {
    entries: BTreeMap<DocKey, Entry<D>>,
    roles: HashMap<TileId, TileRole>,
    workspace: Workspace,
    focused: Option<DocKey>,
    /// The reading tile activated or opened last, whose stack the next
    /// reading joins.
    last_reading: Option<TileId>,
    next_doc: u64,
    next_tile: u64,
}

impl<D> Default for DocumentWorkspace<D> {
    fn default() -> Self {
        Self::new()
    }
}

impl<D> DocumentWorkspace<D> {
    pub fn new() -> Self {
        Self {
            entries: BTreeMap::new(),
            roles: HashMap::new(),
            workspace: Workspace::new(TileTree::stack(Vec::new(), 0)),
            focused: None,
            last_reading: None,
            next_doc: 1,
            next_tile: 1,
        }
    }

    /// The tree a frame renders.
    pub fn workspace(&self) -> &Workspace {
        &self.workspace
    }

    /// Open a document, or activate the open entry with the same identity.
    /// Returns its key and whether a new entry was made; when an existing
    /// entry is reused, `doc` is dropped.
    pub fn open(
        &mut self,
        identity: DocIdentity,
        title: impl Into<String>,
        doc: D,
    ) -> (DocKey, bool) {
        if let Some(key) = self.find(&identity) {
            self.focus(key);
            return (key, false);
        }
        let key = DocKey(self.next_doc);
        self.next_doc += 1;
        let tile = self.mint_tile(title.into(), TileRole::Document(key));
        let id = tile.id;
        self.place_document_tile(tile);
        self.entries.insert(
            key,
            Entry {
                identity,
                tile: id,
                doc,
            },
        );
        self.focus(key);
        (key, true)
    }

    /// The open entry with `identity`, if any. Scratch never matches.
    pub fn find(&self, identity: &DocIdentity) -> Option<DocKey> {
        if *identity == DocIdentity::Scratch {
            return None;
        }
        self.entries
            .iter()
            .find(|(_, entry)| entry.identity == *identity)
            .map(|(key, _)| *key)
    }

    /// Make `key` the focused document and its tile the active tab.
    pub fn focus(&mut self, key: DocKey) {
        if let Some(entry) = self.entries.get(&key) {
            self.workspace
                .apply(&WorkspaceEvent::Tile(TileEvent::Activated(entry.tile)));
            self.focused = Some(key);
        }
    }

    /// The focused document.
    pub fn focused(&self) -> Option<DocKey> {
        self.focused
    }

    pub fn doc(&self, key: DocKey) -> Option<&D> {
        self.entries.get(&key).map(|entry| &entry.doc)
    }

    pub fn doc_mut(&mut self, key: DocKey) -> Option<&mut D> {
        self.entries.get_mut(&key).map(|entry| &mut entry.doc)
    }

    /// Every open document, in the order they were opened.
    pub fn docs(&self) -> impl Iterator<Item = (DocKey, &D)> {
        self.entries.iter().map(|(key, entry)| (*key, &entry.doc))
    }

    pub fn docs_mut(&mut self) -> impl Iterator<Item = (DocKey, &mut D)> {
        self.entries
            .iter_mut()
            .map(|(key, entry)| (*key, &mut entry.doc))
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn identity(&self, key: DocKey) -> Option<&DocIdentity> {
        self.entries.get(&key).map(|entry| &entry.identity)
    }

    /// Record a new identity after Save As or a catalog binding.
    pub fn set_identity(&mut self, key: DocKey, identity: DocIdentity) {
        if let Some(entry) = self.entries.get_mut(&key) {
            entry.identity = identity;
        }
    }

    /// Rename a document's tab.
    pub fn set_title(&mut self, key: DocKey, title: impl Into<String>) {
        if let Some(tile) = self.tile_of(key)
            && let Some(tile) = self.workspace.tiled_mut().tile_mut(tile)
        {
            tile.title = title.into();
        }
    }

    pub fn tile_of(&self, key: DocKey) -> Option<TileId> {
        self.entries.get(&key).map(|entry| entry.tile)
    }

    pub fn role(&self, tile: TileId) -> Option<&TileRole> {
        self.roles.get(&tile)
    }

    /// The document a tile shows: its own for a document tile, the pinned or
    /// the focused one for a reading.
    pub fn document_for(&self, tile: TileId) -> Option<DocKey> {
        match self.roles.get(&tile)? {
            TileRole::Document(key) => Some(*key),
            TileRole::Reading { pinned, .. } => pinned.or(self.focused),
            TileRole::Navigator
            | TileRole::Graph
            | TileRole::Metadata { .. }
            | TileRole::Site(_) => None,
        }
    }

    /// Open the metadata tile of `page` in `site`, or activate the open one.
    /// It joins the focused document's stack, as a document would.
    pub fn open_metadata(&mut self, site: SiteKey, page: &str, title: impl Into<String>) -> TileId {
        if let Some(tile) = self.metadata_tile(site, page) {
            self.activate(tile);
            return tile;
        }
        let role = TileRole::Metadata {
            site,
            page: page.to_owned(),
        };
        let tile = self.mint_tile(title.into(), role);
        let id = tile.id;
        self.place_document_tile(tile);
        self.activate(id);
        id
    }

    /// The open metadata tile of `page` in `site`, if any.
    pub fn metadata_tile(&self, site: SiteKey, page: &str) -> Option<TileId> {
        self.metadata_tiles(site).into_iter().find(|tile| {
            matches!(self.roles.get(tile), Some(TileRole::Metadata { page: open, .. }) if open == page)
        })
    }

    /// Every open metadata tile of `site`, in tile order.
    pub fn metadata_tiles(&self, site: SiteKey) -> Vec<TileId> {
        let mut tiles: Vec<TileId> = self
            .roles
            .iter()
            .filter(
                |(_, role)| matches!(role, TileRole::Metadata { site: open, .. } if *open == site),
            )
            .map(|(tile, _)| *tile)
            .collect();
        tiles.sort_by_key(|tile| tile.0);
        tiles
    }

    /// Activate a tile, focusing its document when it has one.
    pub fn activate(&mut self, tile: TileId) {
        self.workspace
            .apply(&WorkspaceEvent::Tile(TileEvent::Activated(tile)));
        match self.roles.get(&tile) {
            Some(TileRole::Document(key)) => self.focused = Some(*key),
            Some(TileRole::Reading { .. }) => self.last_reading = Some(tile),
            _ => {},
        }
    }

    /// Open a reading tile of `kind`, following the focused document or
    /// pinned to one. It joins the stack of the reading activated last, else
    /// takes a new stack right of the focused document's.
    pub fn open_reading(
        &mut self,
        kind: ReadingKind,
        pinned: Option<DocKey>,
        title: impl Into<String>,
    ) -> TileId {
        let beside_reading = self
            .last_reading
            .filter(|tile| self.workspace.tiled().find(*tile).is_some());
        let beside_document = self
            .focused
            .or_else(|| self.entries.keys().next().copied())
            .and_then(|key| self.tile_of(key));
        let tile = self.mint_tile(title.into(), TileRole::Reading { kind, pinned });
        let id = tile.id;
        let tree = self.workspace.tiled_mut();
        let placed = beside_reading.is_some_and(|last| tree.insert_tab_after(last, tile.clone()))
            || beside_document
                .is_some_and(|document| tree.split_beside(document, Edge::Right, tile.clone()));
        if !placed {
            match tree {
                TileTree::Stack(stack) => {
                    stack.tabs.push(tile);
                    stack.active = stack.tabs.len() - 1;
                },
                _ => *tree = TileTree::stack(vec![tile], 0),
            }
        }
        self.workspace
            .apply(&WorkspaceEvent::Tile(TileEvent::Activated(id)));
        self.last_reading = Some(id);
        id
    }

    /// The open Navigator tile, if any.
    pub fn navigator(&self) -> Option<TileId> {
        self.roles
            .iter()
            .find(|(_, role)| **role == TileRole::Navigator)
            .map(|(tile, _)| *tile)
    }

    /// Open the Navigator, once, in a new stack left of the documents taking
    /// [`NAVIGATOR_SHARE`] of the split; with no document open it joins the
    /// frame's stack.
    pub fn open_navigator(&mut self, title: impl Into<String>) -> TileId {
        if let Some(tile) = self.navigator() {
            return tile;
        }
        self.open_left(title.into(), TileRole::Navigator)
    }

    pub fn graph(&self) -> Option<TileId> {
        self.roles
            .iter()
            .find(|(_, role)| **role == TileRole::Graph)
            .map(|(tile, _)| *tile)
    }

    /// Open the singleton graph in the document stack.
    pub fn open_graph(&mut self, title: impl Into<String>) -> TileId {
        if let Some(tile) = self.graph() {
            self.activate(tile);
            return tile;
        }
        let tile = self.mint_tile(title.into(), TileRole::Graph);
        let id = tile.id;
        self.place_document_tile(tile);
        self.activate(id);
        id
    }

    /// Put the singleton Graph beside the last document before that document
    /// leaves. Closing the document then preserves its stack and every other
    /// workspace branch.
    pub fn prepare_last_document_close(
        &mut self,
        document: DocKey,
        title: impl Into<String>,
    ) -> Option<TileId> {
        if self.entries.len() != 1 || !self.entries.contains_key(&document) {
            return None;
        }
        if let Some(graph) = self.graph() {
            self.activate(graph);
            return Some(graph);
        }
        let document_tile = self.tile_of(document)?;
        let tile = self.mint_tile(title.into(), TileRole::Graph);
        let graph = tile.id;
        if !self
            .workspace
            .tiled_mut()
            .insert_tab_after(document_tile, tile)
        {
            self.roles.remove(&graph);
            return None;
        }
        self.activate(graph);
        Some(graph)
    }

    /// The open site tile of `site`, if any.
    pub fn site_tile(&self, site: SiteKey) -> Option<TileId> {
        self.roles
            .iter()
            .find(|(_, role)| **role == TileRole::Site(site))
            .map(|(tile, _)| *tile)
    }

    /// Open `site`'s tile, or activate the open one. It joins the Navigator's
    /// stack or another site's, else takes a new stack left of the documents
    /// at the Navigator's share.
    pub fn open_site_tile(&mut self, site: SiteKey, title: impl Into<String>) -> TileId {
        if let Some(tile) = self.site_tile(site) {
            self.activate(tile);
            return tile;
        }
        let tile = self.open_left(title.into(), TileRole::Site(site));
        self.activate(tile);
        tile
    }

    /// Place a left-stack tile: beside an open Navigator or site tile, else
    /// in a new stack left of the documents taking [`NAVIGATOR_SHARE`] of the
    /// split; with no document open it joins the frame's stack.
    fn open_left(&mut self, title: String, role: TileRole) -> TileId {
        let beside_left = self
            .roles
            .iter()
            .filter(|(_, role)| matches!(role, TileRole::Navigator | TileRole::Site(_)))
            .map(|(tile, _)| *tile)
            .min_by_key(|tile| tile.0)
            .filter(|tile| self.workspace.tiled().find(*tile).is_some());
        let beside_document = self
            .focused
            .or_else(|| self.entries.keys().next().copied())
            .and_then(|key| self.tile_of(key));
        let tile = self.mint_tile(title, role);
        let id = tile.id;
        let tree = self.workspace.tiled_mut();
        if let Some(left) = beside_left
            && tree.insert_tab_after(left, tile.clone())
        {
            return id;
        }
        let placed = beside_document
            .is_some_and(|document| tree.split_beside(document, Edge::Left, tile.clone()));
        if placed {
            set_stack_share(tree, id, NAVIGATOR_SHARE);
        } else {
            match tree {
                TileTree::Stack(stack) => {
                    stack.tabs.push(tile);
                    stack.active = stack.tabs.len() - 1;
                },
                _ => *tree = TileTree::stack(vec![tile], 0),
            }
        }
        id
    }

    /// The open reading tile of `kind` that follows the focus, if any.
    pub fn following_reading(&self, kind: ReadingKind) -> Option<TileId> {
        self.readings()
            .find(|(_, open, pinned)| *open == kind && pinned.is_none())
            .map(|(tile, _, _)| tile)
    }

    /// Every open reading tile: its id, kind and pin, in tile order.
    pub fn readings(&self) -> impl Iterator<Item = (TileId, ReadingKind, Option<DocKey>)> + '_ {
        let mut tiles: Vec<_> = self
            .roles
            .iter()
            .filter_map(|(tile, role)| match role {
                TileRole::Reading { kind, pinned } => Some((*tile, *kind, *pinned)),
                _ => None,
            })
            .collect();
        tiles.sort_by_key(|(tile, _, _)| tile.0);
        tiles.into_iter()
    }

    /// Pin a reading tile to `pinned`, or let it follow the focus again.
    pub fn set_pinned(&mut self, tile: TileId, pinned: Option<DocKey>) {
        if let Some(TileRole::Reading {
            pinned: current, ..
        }) = self.roles.get_mut(&tile)
        {
            *current = pinned;
        }
    }

    /// Rename any tile's tab.
    pub fn set_tile_title(&mut self, tile: TileId, title: impl Into<String>) {
        if let Some(tile) = self.workspace.tiled_mut().tile_mut(tile) {
            tile.title = title.into();
        }
    }

    /// Apply a divider move. Drags, floats and tearouts are not adopted yet
    /// and return `false`, leaving the tree unchanged.
    pub fn apply_layout(&mut self, event: &WorkspaceEvent) -> bool {
        match event {
            WorkspaceEvent::Tile(TileEvent::DividerMoved { .. }) => {
                self.workspace.apply(event).changed()
            },
            _ => false,
        }
    }

    /// Remove a tile, and with a document tile its entry, returning the
    /// document it showed. The focus moves to the document now active in the
    /// same stack, else to any open document. The caller preflights a dirty
    /// document first; this never asks.
    pub fn close(&mut self, tile: TileId) -> Option<(DocKey, D)> {
        let role = self.roles.remove(&tile)?;
        self.workspace
            .apply(&WorkspaceEvent::Tile(TileEvent::Closed(tile)));
        if self.last_reading == Some(tile) {
            self.last_reading = self.readings().map(|(tile, _, _)| tile).last();
        }
        let closed = match role {
            TileRole::Document(key) => self.entries.remove(&key).map(|entry| (key, entry.doc)),
            _ => None,
        };
        // A reading pinned to a closed document has nothing left to show.
        if let Some((key, _)) = &closed {
            let pinned: Vec<TileId> = self
                .readings()
                .filter(|(_, _, pinned)| *pinned == Some(*key))
                .map(|(tile, _, _)| tile)
                .collect();
            for reading in pinned {
                self.close(reading);
            }
        }
        if let Some((key, _)) = &closed
            && self.focused == Some(*key)
        {
            self.focused = self
                .active_document()
                .or_else(|| self.entries.keys().next().copied());
        }
        closed
    }

    fn active_document(&self) -> Option<DocKey> {
        fn active(tree: &TileTree) -> Vec<TileId> {
            match tree {
                TileTree::Stack(stack) => stack
                    .tabs
                    .get(stack.active)
                    .map(|tile| tile.id)
                    .into_iter()
                    .collect(),
                TileTree::Split { children, .. } => children
                    .iter()
                    .flat_map(|branch| active(&branch.tree))
                    .collect(),
            }
        }
        active(self.workspace.tiled())
            .into_iter()
            .find_map(|tile| match self.roles.get(&tile) {
                Some(TileRole::Document(key)) => Some(*key),
                _ => None,
            })
    }

    fn mint_tile(&mut self, title: String, role: TileRole) -> Tile {
        let id = if role == TileRole::Graph {
            GRAPH_TILE_ID
        } else {
            let id = TileId(self.next_tile);
            self.next_tile += 1;
            id
        };
        debug_assert_eq!(GRAPH_TILE_ID.0.to_string(), GRAPH_TILE_ID_ATTR);
        debug_assert!(!self.roles.contains_key(&id));
        self.roles.insert(id, role);
        Tile {
            id,
            title,
            content: ContentSource::Open {
                kind: TILE_KIND.to_string(),
                id: id.0.to_string(),
            },
            accent: None,
        }
    }

    /// A new document goes into the existing document/Graph stack. If that
    /// centre stack was explicitly closed while side stacks survived, rebuild
    /// it immediately left of a reading stack or right of the left stack;
    /// never turn a Navigator, site, or reading into a document stack.
    fn place_document_tile(&mut self, tile: Tile) {
        let beside = self
            .focused
            .and_then(|key| self.entries.get(&key))
            .map(|entry| entry.tile)
            .or_else(|| self.entries.values().map(|entry| entry.tile).next())
            .or_else(|| self.graph())
            .or_else(|| {
                self.roles
                    .iter()
                    .filter(|(_, role)| matches!(role, TileRole::Metadata { .. }))
                    .map(|(tile, _)| *tile)
                    .filter(|tile| self.workspace.tiled().find(*tile).is_some())
                    .min_by_key(|tile| tile.0)
            });
        let reading = self
            .roles
            .iter()
            .filter(|(_, role)| matches!(role, TileRole::Reading { .. }))
            .map(|(tile, _)| *tile)
            .filter(|tile| self.workspace.tiled().find(*tile).is_some())
            .min_by_key(|tile| tile.0);
        let left = self
            .roles
            .iter()
            .filter(|(_, role)| matches!(role, TileRole::Navigator | TileRole::Site(_)))
            .map(|(tile, _)| *tile)
            .filter(|tile| self.workspace.tiled().find(*tile).is_some())
            .min_by_key(|tile| tile.0);
        let tree = self.workspace.tiled_mut();
        if let Some(target) = beside
            && tree.insert_tab_after(target, tile.clone())
        {
            return;
        }
        if let Some(target) = reading
            && tree.split_beside(target, Edge::Left, tile.clone())
        {
            return;
        }
        if let Some(target) = left
            && tree.split_beside(target, Edge::Right, tile.clone())
        {
            return;
        }
        match tree {
            TileTree::Stack(stack) if stack.tabs.is_empty() => {
                stack.tabs.push(tile);
                stack.active = 0;
            },
            _ => {
                // All retained tiles have a role, so this is only defensive:
                // preserve an unexpected survivor in a separate stack.
                let target = tree.tiles().first().map(|survivor| survivor.id);
                if !target
                    .is_some_and(|target| tree.split_beside(target, Edge::Right, tile.clone()))
                {
                    *tree = TileTree::stack(vec![tile], 0);
                }
            },
        }
    }
}

/// Give the stack holding `tile` `share` of its split, the rest going to its
/// siblings in proportion to what they had. `false` when no split holds it.
fn set_stack_share(tree: &mut TileTree, tile: TileId, share: f32) -> bool {
    let TileTree::Split { children, .. } = tree else {
        return false;
    };
    let holds = |branch: &workbench::TileBranch| matches!(&branch.tree, TileTree::Stack(stack) if stack.tabs.iter().any(|t| t.id == tile));
    let Some(index) = children.iter().position(holds) else {
        return children
            .iter_mut()
            .any(|branch| set_stack_share(&mut branch.tree, tile, share));
    };
    let rest: f32 = children
        .iter()
        .enumerate()
        .filter(|(i, _)| *i != index)
        .map(|(_, branch)| branch.fraction)
        .sum();
    let siblings = (children.len() - 1).max(1) as f32;
    for (i, branch) in children.iter_mut().enumerate() {
        branch.fraction = if i == index {
            share
        } else if rest > f32::EPSILON {
            branch.fraction / rest * (1.0 - share)
        } else {
            (1.0 - share) / siblings
        };
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    fn path(name: &str) -> DocIdentity {
        DocIdentity::Path(PathBuf::from(name))
    }

    fn tabs(space: &DocumentWorkspace<&'static str>) -> Vec<String> {
        space
            .workspace()
            .tiled()
            .tiles()
            .into_iter()
            .map(|tile| tile.title.clone())
            .collect()
    }

    #[test]
    fn two_files_and_a_scratch_coexist_in_one_stack() {
        let mut space = DocumentWorkspace::new();
        let (a, new_a) = space.open(path("a.djot"), "a.djot", "A");
        let (b, new_b) = space.open(path("b.djot"), "b.djot", "B");
        let (s, new_s) = space.open(DocIdentity::Scratch, "Untitled", "S");
        assert!(new_a && new_b && new_s);
        assert_eq!(space.len(), 3);
        assert_eq!(tabs(&space), ["a.djot", "b.djot", "Untitled"]);
        assert_eq!(space.focused(), Some(s));
        assert_eq!(space.doc(a), Some(&"A"));
        assert_eq!(space.doc(b), Some(&"B"));
        assert!(matches!(space.workspace().tiled(), TileTree::Stack(_)));
    }

    #[test]
    fn the_navigator_opens_once_in_a_stack_left_of_the_documents() {
        let mut space = DocumentWorkspace::new();
        space.open(path("a.djot"), "a.djot", "A");
        assert_eq!(space.navigator(), None);
        let navigator = space.open_navigator("Navigator");
        assert_eq!(
            space.open_navigator("Navigator"),
            navigator,
            "one Navigator"
        );
        assert_eq!(space.navigator(), Some(navigator));
        assert_eq!(space.document_for(navigator), None);
        assert_eq!(
            tabs(&space),
            ["Navigator", "a.djot"],
            "left of the documents"
        );
        let TileTree::Split { children, .. } = space.workspace().tiled() else {
            panic!("the Navigator splits the frame");
        };
        let shares: Vec<f32> = children.iter().map(|branch| branch.fraction).collect();
        assert_eq!(shares, [NAVIGATOR_SHARE, 1.0 - NAVIGATOR_SHARE]);
        space.close(navigator);
        assert_eq!(space.navigator(), None);
        assert_eq!(tabs(&space), ["a.djot"]);
    }

    #[test]
    fn a_duplicate_open_activates_the_existing_entry() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "first");
        space.open(path("b.djot"), "b.djot", "B");
        let (again, opened) = space.open(path("a.djot"), "a.djot", "second");
        assert_eq!(again, a);
        assert!(!opened);
        assert_eq!(space.doc(a), Some(&"first"), "the open session is kept");
        assert_eq!(space.len(), 2);
        assert_eq!(space.focused(), Some(a));
        let active = match space.workspace().tiled() {
            TileTree::Stack(stack) => stack.tabs[stack.active].id,
            _ => panic!("one stack"),
        };
        assert_eq!(Some(active), space.tile_of(a));
    }

    #[test]
    fn scratch_documents_never_collide() {
        let mut space = DocumentWorkspace::new();
        let (one, _) = space.open(DocIdentity::Scratch, "Untitled", "1");
        let (two, opened) = space.open(DocIdentity::Scratch, "Untitled", "2");
        assert!(opened);
        assert_ne!(one, two);
    }

    #[test]
    fn a_catalog_identity_outlives_a_rename() {
        let mut space = DocumentWorkspace::new();
        let (key, _) = space.open(
            DocIdentity::Catalog("knot:document:1".into()),
            "a.djot",
            "A",
        );
        space.set_identity(key, DocIdentity::Catalog("knot:document:1".into()));
        space.set_title(key, "b.djot");
        let (again, opened) = space.open(
            DocIdentity::Catalog("knot:document:1".into()),
            "b.djot",
            "dup",
        );
        assert_eq!((again, opened), (key, false));
        assert_eq!(tabs(&space), ["b.djot"]);
    }

    #[test]
    fn closing_a_tile_drops_its_entry_and_moves_the_focus() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        let (b, _) = space.open(path("b.djot"), "b.djot", "B");
        let tile = space.tile_of(b).unwrap();
        assert_eq!(space.close(tile), Some((b, "B")));
        assert_eq!(space.doc(b), None);
        assert_eq!(space.role(tile), None);
        assert_eq!(space.focused(), Some(a));
        assert_eq!(tabs(&space), ["a.djot"]);
        // The key is never reused.
        let (c, _) = space.open(path("c.djot"), "c.djot", "C");
        assert_ne!(c, b);
    }

    #[test]
    fn closing_the_last_document_leaves_an_empty_frame() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        space.close(space.tile_of(a).unwrap());
        assert!(space.is_empty());
        assert_eq!(space.focused(), None);
        assert!(tabs(&space).is_empty());
        let (b, _) = space.open(path("b.djot"), "b.djot", "B");
        assert_eq!(space.focused(), Some(b));
        assert_eq!(tabs(&space), ["b.djot"]);
    }

    #[test]
    fn graph_is_singleton_in_the_document_stack() {
        let mut space = DocumentWorkspace::new();
        let (document, _) = space.open(path("a.djot"), "a.djot", "A");
        let document_tile = space.tile_of(document).unwrap();
        let graph = space.open_graph("Graph");
        assert_eq!(graph, GRAPH_TILE_ID);
        assert_eq!(space.open_graph("Graph again"), graph);
        assert_eq!(space.graph(), Some(graph));
        assert_eq!(space.role(graph), Some(&TileRole::Graph));
        assert_eq!(tabs(&space), ["a.djot", "Graph"]);
        assert_eq!(space.focused(), Some(document));
        space.close(graph);
        assert_eq!(space.graph(), None);
        let (second, _) = space.open(path("b.djot"), "b.djot", "B");
        assert_eq!(space.tile_of(second), Some(TileId(document_tile.0 + 1)));
        assert_eq!(space.open_graph("Graph reopened"), GRAPH_TILE_ID);
    }

    #[test]
    fn activating_a_document_tile_focuses_it() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        space.open(path("b.djot"), "b.djot", "B");
        space.activate(space.tile_of(a).unwrap());
        assert_eq!(space.focused(), Some(a));
    }

    fn stacks(space: &DocumentWorkspace<&'static str>) -> Vec<Vec<TileId>> {
        fn collect(tree: &TileTree, stacks: &mut Vec<Vec<TileId>>) {
            match tree {
                TileTree::Stack(stack) => {
                    stacks.push(stack.tabs.iter().map(|tile| tile.id).collect())
                },
                TileTree::Split { children, .. } => {
                    for child in children {
                        collect(&child.tree, stacks);
                    }
                },
            }
        }
        let mut stacks = Vec::new();
        collect(space.workspace().tiled(), &mut stacks);
        stacks
    }

    #[test]
    fn metadata_keeps_the_centre_stack_for_new_after_graph_closes() {
        let mut space = DocumentWorkspace::new();
        let (source, _) = space.open(path("page.djot"), "page.djot", "source");
        let navigator = space.open_navigator("Navigator");
        let reading = space.open_reading(ReadingKind::Preview, None, "Preview");
        let metadata = space.open_metadata(SiteKey(1), "page.djot", "Metadata");

        let graph = space
            .prepare_last_document_close(source, "Graph")
            .expect("last source is replaced by Graph");
        space.close(space.tile_of(source).unwrap());
        space.close(graph);
        assert_eq!(
            stacks(&space),
            [vec![navigator], vec![metadata], vec![reading]]
        );

        let (new, inserted) = space.open(DocIdentity::Scratch, "Untitled", "new");
        assert!(inserted);
        assert_eq!(
            stacks(&space),
            [
                vec![navigator],
                vec![metadata, space.tile_of(new).unwrap()],
                vec![reading]
            ]
        );
    }

    #[test]
    fn readings_share_a_stack_right_of_the_documents() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        let outline = space.open_reading(ReadingKind::Outline, None, "Outline");
        let preview = space.open_reading(ReadingKind::Preview, None, "Preview");
        assert_eq!(
            stacks(&space),
            [vec![space.tile_of(a).unwrap()], vec![outline, preview]]
        );
        assert_eq!(space.document_for(outline), Some(a));
        assert_eq!(
            space.focused(),
            Some(a),
            "a reading takes no document focus"
        );
    }

    #[test]
    fn a_pinned_reading_keeps_its_document_as_the_focus_moves() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        let following = space.open_reading(ReadingKind::Preview, None, "Preview");
        let pinned = space.open_reading(ReadingKind::Preview, Some(a), "Preview");
        let (b, _) = space.open(path("b.djot"), "b.djot", "B");
        assert_eq!(space.document_for(following), Some(b));
        assert_eq!(space.document_for(pinned), Some(a));
        assert_eq!(
            space.following_reading(ReadingKind::Preview),
            Some(following)
        );
        space.set_pinned(pinned, None);
        assert_eq!(space.document_for(pinned), Some(b), "unpinned, it follows");
    }

    #[test]
    fn closing_a_document_closes_the_readings_pinned_to_it() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        space.open(path("b.djot"), "b.djot", "B");
        let pinned = space.open_reading(ReadingKind::Outline, Some(a), "Outline");
        let following = space.open_reading(ReadingKind::Preview, None, "Preview");
        space.close(space.tile_of(a).unwrap());
        assert_eq!(space.role(pinned), None);
        assert!(space.role(following).is_some());
    }

    #[test]
    fn the_last_reading_closes_its_stack_and_the_next_opens_another() {
        let mut space = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        let outline = space.open_reading(ReadingKind::Outline, None, "Outline");
        space.close(outline);
        assert_eq!(stacks(&space), [vec![space.tile_of(a).unwrap()]]);
        let again = space.open_reading(ReadingKind::Outline, None, "Outline");
        assert_eq!(
            stacks(&space),
            [vec![space.tile_of(a).unwrap()], vec![again]]
        );
    }

    #[test]
    fn drags_are_declined_until_adopted() {
        let mut space: DocumentWorkspace<&str> = DocumentWorkspace::new();
        let (a, _) = space.open(path("a.djot"), "a.djot", "A");
        let tile = space.tile_of(a).unwrap();
        let drag = WorkspaceEvent::Tile(TileEvent::Dragged {
            tile,
            to: workbench::DropTarget::Outside,
        });
        assert!(!space.apply_layout(&drag));
        assert_eq!(tabs(&space), ["a.djot"]);
    }
}
